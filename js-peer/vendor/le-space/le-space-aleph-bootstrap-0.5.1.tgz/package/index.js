// src/index.ts
import { bootstrap } from "@libp2p/bootstrap";
import { recoverMessageAddress } from "viem";
var DEFAULT_ALEPH_API_HOST = "https://api.aleph.im";
var DEFAULT_ALEPH_BOOTSTRAP_CHANNEL = "simple-todo";
var DEFAULT_ALEPH_BOOTSTRAP_REF = "simple-todo-bootstrap";
var DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE = "relay-bootstrap";
var DEFAULT_BOOTSTRAP_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
var DEFAULT_BOOTSTRAP_PAGINATION = 50;
var DEFAULT_BOOTSTRAP_MAX_PAGES = 5;
var RELAY_BOOTSTRAP_SIGNATURE_SCHEME = "personal_sign";
function serializeOwnerAuthorizationPayload(payload) {
  return JSON.stringify({
    ownerAddress: payload.ownerAddress,
    publisherAddress: payload.publisherAddress,
    peerId: payload.peerId,
    registrationId: payload.registrationId,
    profile: payload.profile,
    version: payload.version,
    instanceItemHash: payload.instanceItemHash,
    issuedAt: payload.issuedAt,
    expiresAt: payload.expiresAt
  });
}
function serializeRelayProofPayload(payload) {
  return JSON.stringify({
    peerId: payload.peerId,
    multiaddrs: dedupeMultiaddrs(payload.multiaddrs),
    browserMultiaddrs: payload.browserMultiaddrs ? dedupeMultiaddrs(payload.browserMultiaddrs) : void 0,
    registrationId: payload.registrationId,
    profile: payload.profile,
    version: payload.version,
    updatedAt: payload.updatedAt
  });
}
async function recoverAddressForSignature(payload, signature) {
  return recoverMessageAddress({
    message: payload,
    signature
  });
}
function asTrimmedString(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function asNumber(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function normalizeHost(host) {
  return host.trim().toLowerCase();
}
function normalizeAddress(address) {
  return address.trim().toLowerCase();
}
function normalizeSignature(signature) {
  const trimmed = signature.trim();
  return trimmed.startsWith("0x") ? trimmed : `0x${trimmed}`;
}
function splitMultiaddr(addr) {
  return addr.split("/").filter(Boolean);
}
function isPrivateIpv4(ip) {
  const parts = ip.split(".").map((part) => Number(part));
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) {
    return false;
  }
  if (parts[0] === 10) return true;
  if (parts[0] === 127) return true;
  if (parts[0] === 0) return true;
  if (parts[0] === 169 && parts[1] === 254) return true;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  if (parts[0] === 192 && parts[1] === 168) return true;
  if (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127) return true;
  return false;
}
function isPrivateIpv6(ip) {
  const normalized = ip.trim().toLowerCase();
  return normalized === "::1" || normalized.startsWith("fc") || normalized.startsWith("fd") || normalized.startsWith("fe8") || normalized.startsWith("fe9") || normalized.startsWith("fea") || normalized.startsWith("feb");
}
function isLocalHostname(host) {
  const normalized = normalizeHost(host);
  return normalized === "localhost" || normalized.endsWith(".localhost") || normalized.endsWith(".local");
}
function hasPeerId(addr) {
  return splitMultiaddr(addr).includes("p2p");
}
function isBrowserDialableMultiaddr(addr) {
  const normalized = addr.toLowerCase();
  return normalized.includes("/ws") || normalized.includes("/wss") || normalized.includes("/webtransport") || normalized.includes("/webrtc-direct");
}
function dedupeMultiaddrs(addrs) {
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const value of addrs) {
    const trimmed = value.trim();
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    result.push(trimmed);
  }
  return result;
}
function isPublicMultiaddr(addr) {
  const parts = splitMultiaddr(addr);
  for (let index = 0; index < parts.length; index += 1) {
    const protocol = parts[index];
    const value = parts[index + 1];
    if (protocol === "ip4" && value) {
      return !isPrivateIpv4(value);
    }
    if (protocol === "ip6" && value) {
      return !isPrivateIpv6(value);
    }
    if ((protocol === "dns4" || protocol === "dns6" || protocol === "dnsaddr") && value) {
      return !isLocalHostname(value);
    }
  }
  return false;
}
function filterPublicMultiaddrs(addrs, options = {}) {
  return dedupeMultiaddrs(addrs).filter((addr) => {
    if (!isPublicMultiaddr(addr)) return false;
    if (options.requirePeerId !== false && !hasPeerId(addr)) return false;
    if (options.browserDialableOnly && !isBrowserDialableMultiaddr(addr)) {
      return false;
    }
    return true;
  });
}
function normalizeRelayBootstrapContent(value) {
  if (!value || typeof value !== "object") return null;
  const content = value;
  const peerId = asTrimmedString(content.peerId);
  const updatedAt = asNumber(content.updatedAt);
  if (!peerId || updatedAt == null) return null;
  const multiaddrs = Array.isArray(content.multiaddrs) ? content.multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserMultiaddrs = Array.isArray(content.browserMultiaddrs) ? content.browserMultiaddrs.filter((entry) => typeof entry === "string") : void 0;
  return {
    peerId,
    multiaddrs: dedupeMultiaddrs(multiaddrs),
    browserMultiaddrs: browserMultiaddrs ? dedupeMultiaddrs(browserMultiaddrs) : void 0,
    registrationId: asTrimmedString(content.registrationId) ?? void 0,
    profile: asTrimmedString(content.profile) ?? void 0,
    version: asTrimmedString(content.version) ?? void 0,
    ownerAddress: asTrimmedString(content.ownerAddress) ?? void 0,
    publisherAddress: asTrimmedString(content.publisherAddress) ?? void 0,
    authorization: normalizeRelayBootstrapAuthorizationRecord(content.authorization) ?? void 0,
    relayProof: normalizeRelayBootstrapProofRecord(content.relayProof) ?? void 0,
    updatedAt
  };
}
function normalizeRelayBootstrapAuthorizationPayload(value) {
  if (!value || typeof value !== "object") return null;
  const payload = value;
  const ownerAddress = asTrimmedString(payload.ownerAddress);
  const publisherAddress = asTrimmedString(payload.publisherAddress);
  const peerId = asTrimmedString(payload.peerId);
  const issuedAt = asNumber(payload.issuedAt);
  const expiresAt = asNumber(payload.expiresAt) ?? void 0;
  if (!ownerAddress || !publisherAddress || !peerId || issuedAt == null) {
    return null;
  }
  return {
    ownerAddress,
    publisherAddress,
    peerId,
    registrationId: asTrimmedString(payload.registrationId) ?? void 0,
    profile: asTrimmedString(payload.profile) ?? void 0,
    version: asTrimmedString(payload.version) ?? void 0,
    instanceItemHash: asTrimmedString(payload.instanceItemHash) ?? void 0,
    issuedAt,
    expiresAt
  };
}
function normalizeRelayBootstrapAuthorizationRecord(value) {
  if (!value || typeof value !== "object") return null;
  const record = value;
  const scheme = asTrimmedString(record.scheme);
  const signature = asTrimmedString(record.signature);
  const payload = normalizeRelayBootstrapAuthorizationPayload(record.payload);
  if (!scheme || !signature || !payload) return null;
  return { scheme, signature, payload };
}
function normalizeRelayBootstrapProofPayload(value) {
  if (!value || typeof value !== "object") return null;
  const payload = value;
  const peerId = asTrimmedString(payload.peerId);
  const updatedAt = asNumber(payload.updatedAt);
  if (!peerId || updatedAt == null) return null;
  const multiaddrs = Array.isArray(payload.multiaddrs) ? payload.multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserMultiaddrs = Array.isArray(payload.browserMultiaddrs) ? payload.browserMultiaddrs.filter((entry) => typeof entry === "string") : void 0;
  return {
    peerId,
    multiaddrs: dedupeMultiaddrs(multiaddrs),
    browserMultiaddrs: browserMultiaddrs ? dedupeMultiaddrs(browserMultiaddrs) : void 0,
    registrationId: asTrimmedString(payload.registrationId) ?? void 0,
    profile: asTrimmedString(payload.profile) ?? void 0,
    version: asTrimmedString(payload.version) ?? void 0,
    updatedAt
  };
}
function normalizeRelayBootstrapProofRecord(value) {
  if (!value || typeof value !== "object") return null;
  const record = value;
  const scheme = asTrimmedString(record.scheme);
  const signature = asTrimmedString(record.signature);
  const payload = normalizeRelayBootstrapProofPayload(record.payload);
  if (!scheme || !signature || !payload) return null;
  return { scheme, signature, payload };
}
function normalizeRelayBootstrapPostRecord(value) {
  if (!value || typeof value !== "object") return null;
  const entry = value;
  return {
    hash: asTrimmedString(entry.hash),
    itemHash: asTrimmedString(entry.item_hash),
    address: asTrimmedString(entry.address),
    ref: asTrimmedString(entry.ref),
    type: asTrimmedString(entry.type),
    time: asNumber(entry.time),
    content: normalizeRelayBootstrapContent(entry.content)
  };
}
function buildRelayBootstrapPostContent(args) {
  const now = args.now ?? Date.now() / 1e3;
  const updatedAt = args.now ?? Date.now();
  return {
    type: args.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE,
    address: args.sender,
    ...args.ref ? { ref: args.ref } : {},
    content: {
      peerId: args.peerId,
      multiaddrs: filterPublicMultiaddrs(args.multiaddrs),
      browserMultiaddrs: args.browserMultiaddrs ? filterPublicMultiaddrs(args.browserMultiaddrs, {
        browserDialableOnly: true
      }) : void 0,
      registrationId: args.registrationId,
      profile: args.profile,
      version: args.version,
      ownerAddress: args.ownerAddress,
      publisherAddress: args.publisherAddress,
      authorization: args.authorization,
      relayProof: args.relayProof,
      updatedAt: Math.round(updatedAt)
    },
    time: now
  };
}
async function createRelayBootstrapPost(args) {
  const nowMillis = args.now ?? Date.now();
  const nowSeconds = nowMillis / 1e3;
  const itemContent = buildRelayBootstrapPostContent({
    sender: args.sender,
    peerId: args.peerId,
    multiaddrs: args.multiaddrs,
    browserMultiaddrs: args.browserMultiaddrs,
    registrationId: args.registrationId,
    ref: args.ref ?? DEFAULT_ALEPH_BOOTSTRAP_REF,
    postType: args.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE,
    profile: args.profile,
    version: args.version,
    ownerAddress: args.ownerAddress,
    publisherAddress: args.publisherAddress,
    authorization: args.authorization,
    relayProof: args.relayProof,
    now: nowMillis
  });
  itemContent.time = nowSeconds;
  const serialized = JSON.stringify(itemContent);
  const itemHash = await args.hasher(serialized);
  return {
    channel: args.channel ?? DEFAULT_ALEPH_BOOTSTRAP_CHANNEL,
    sender: args.sender,
    chain: "ETH",
    type: "POST",
    time: nowSeconds,
    item_type: "inline",
    item_content: serialized,
    item_hash: itemHash
  };
}
function relayBootstrapTrustMode(content) {
  if (content?.authorization && content?.relayProof && content.authorization.payload.publisherAddress && content.relayProof.payload.peerId) {
    return "dual-key-attested";
  }
  return "legacy-wallet-signed";
}
async function signRelayBootstrapAuthorization(args) {
  const payload = {
    ownerAddress: args.ownerAddress,
    publisherAddress: args.publisherAddress,
    peerId: args.peerId,
    registrationId: args.registrationId,
    profile: args.profile,
    version: args.version,
    instanceItemHash: args.instanceItemHash,
    issuedAt: args.issuedAt ?? Date.now(),
    expiresAt: args.expiresAt
  };
  const serialized = serializeOwnerAuthorizationPayload(payload);
  const signature = await args.signer(args.ownerAddress, serialized);
  return {
    scheme: RELAY_BOOTSTRAP_SIGNATURE_SCHEME,
    payload,
    signature: normalizeSignature(signature)
  };
}
async function signRelayBootstrapProof(args) {
  const payload = {
    peerId: args.peerId,
    multiaddrs: filterPublicMultiaddrs(args.multiaddrs),
    browserMultiaddrs: args.browserMultiaddrs ? filterPublicMultiaddrs(args.browserMultiaddrs, {
      browserDialableOnly: true
    }) : void 0,
    registrationId: args.registrationId,
    profile: args.profile,
    version: args.version,
    updatedAt: args.updatedAt ?? Date.now()
  };
  const serialized = serializeRelayProofPayload(payload);
  const signature = await args.signer(args.publisherAddress, serialized);
  return {
    scheme: RELAY_BOOTSTRAP_SIGNATURE_SCHEME,
    payload,
    signature: normalizeSignature(signature)
  };
}
async function verifyRelayBootstrapAuthorization(authorization, options = {}) {
  const errors = [];
  if (!authorization) {
    errors.push("Missing owner authorization.");
    return { ok: false, errors };
  }
  if (authorization.scheme !== RELAY_BOOTSTRAP_SIGNATURE_SCHEME) {
    errors.push(`Unsupported owner authorization scheme: ${authorization.scheme}`);
    return { ok: false, errors };
  }
  const payload = authorization.payload;
  const serialized = serializeOwnerAuthorizationPayload(payload);
  try {
    const recovered = await recoverAddressForSignature(
      serialized,
      authorization.signature
    );
    if (normalizeAddress(recovered) !== normalizeAddress(payload.ownerAddress)) {
      errors.push("Owner authorization signature does not recover the owner address.");
    }
  } catch (error) {
    errors.push(
      `Owner authorization signature could not be recovered: ${error instanceof Error ? error.message : String(error)}`
    );
  }
  const now = options.now ?? Date.now();
  if (payload.expiresAt != null && now > payload.expiresAt) {
    errors.push("Owner authorization has expired.");
  }
  return { ok: errors.length === 0, errors };
}
async function verifyRelayBootstrapProof(proof, options = {}) {
  const errors = [];
  if (!proof) {
    errors.push("Missing relay proof.");
    return { ok: false, errors };
  }
  if (proof.scheme !== RELAY_BOOTSTRAP_SIGNATURE_SCHEME) {
    errors.push(`Unsupported relay proof scheme: ${proof.scheme}`);
    return { ok: false, errors };
  }
  const payload = proof.payload;
  const serialized = serializeRelayProofPayload(payload);
  try {
    const recovered = await recoverAddressForSignature(serialized, proof.signature);
    if (options.expectedPublisherAddress && normalizeAddress(recovered) !== normalizeAddress(options.expectedPublisherAddress)) {
      errors.push("Relay proof signature does not recover the expected publisher address.");
    }
  } catch (error) {
    errors.push(
      `Relay proof signature could not be recovered: ${error instanceof Error ? error.message : String(error)}`
    );
  }
  if (options.expectedPeerId && payload.peerId !== options.expectedPeerId) {
    errors.push("Relay proof peer ID does not match the expected peer ID.");
  }
  return { ok: errors.length === 0, errors };
}
async function verifyRelayBootstrapDualKeyContent(content, options = {}) {
  const errors = [];
  if (!content) {
    errors.push("Missing relay bootstrap content.");
    return { ok: false, errors };
  }
  const authorization = await verifyRelayBootstrapAuthorization(
    content.authorization,
    options
  );
  errors.push(...authorization.errors);
  const expectedPublisherAddress = content.publisherAddress ?? content.authorization?.payload.publisherAddress ?? void 0;
  const proof = await verifyRelayBootstrapProof(content.relayProof, {
    expectedPublisherAddress,
    expectedPeerId: content.peerId
  });
  errors.push(...proof.errors);
  if (content.ownerAddress && content.authorization) {
    if (normalizeAddress(content.ownerAddress) !== normalizeAddress(content.authorization.payload.ownerAddress)) {
      errors.push("Content ownerAddress does not match the owner authorization payload.");
    }
  }
  if (expectedPublisherAddress && content.authorization) {
    if (normalizeAddress(expectedPublisherAddress) !== normalizeAddress(content.authorization.payload.publisherAddress)) {
      errors.push(
        "Content publisherAddress does not match the owner authorization payload."
      );
    }
  }
  if (content.authorization && content.authorization.payload.peerId !== content.peerId) {
    errors.push("Owner authorization peer ID does not match the bootstrap content peer ID.");
  }
  const proofPayload = content.relayProof?.payload;
  if (proofPayload) {
    if (proofPayload.registrationId !== content.registrationId) {
      errors.push("Relay proof registrationId does not match the bootstrap content.");
    }
    if (proofPayload.profile !== content.profile) {
      errors.push("Relay proof profile does not match the bootstrap content.");
    }
    if (proofPayload.version !== content.version) {
      errors.push("Relay proof version does not match the bootstrap content.");
    }
    if (proofPayload.updatedAt !== content.updatedAt) {
      errors.push("Relay proof updatedAt does not match the bootstrap content.");
    }
    if (JSON.stringify(dedupeMultiaddrs(proofPayload.multiaddrs)) !== JSON.stringify(dedupeMultiaddrs(content.multiaddrs))) {
      errors.push("Relay proof multiaddrs do not match the bootstrap content.");
    }
    if (JSON.stringify(dedupeMultiaddrs(proofPayload.browserMultiaddrs ?? [])) !== JSON.stringify(dedupeMultiaddrs(content.browserMultiaddrs ?? []))) {
      errors.push("Relay proof browserMultiaddrs do not match the bootstrap content.");
    }
  }
  return { ok: errors.length === 0, errors };
}
async function fetchAlephBootstrapPosts(options = {}) {
  const fetchImpl = options.fetch ?? globalThis.fetch?.bind(globalThis);
  if (typeof fetchImpl !== "function") {
    throw new Error(
      "A fetch implementation is required to query Aleph bootstrap posts."
    );
  }
  const url = new URL(
    "/api/v0/posts.json",
    options.apiHost ?? DEFAULT_ALEPH_API_HOST
  );
  url.searchParams.set(
    "channels",
    options.channel ?? DEFAULT_ALEPH_BOOTSTRAP_CHANNEL
  );
  url.searchParams.set("refs", options.ref ?? DEFAULT_ALEPH_BOOTSTRAP_REF);
  url.searchParams.set(
    "types",
    options.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE
  );
  url.searchParams.set(
    "pagination",
    String(options.pagination ?? DEFAULT_BOOTSTRAP_PAGINATION)
  );
  url.searchParams.set("page", String(options.page ?? 1));
  const response = await fetchImpl(url.toString(), {
    method: "GET",
    headers: { accept: "application/json" }
  });
  if (!response.ok) {
    throw new Error(`Aleph bootstrap post lookup failed: ${response.status}`);
  }
  const payload = await response.json();
  return (payload.posts ?? []).map((entry) => normalizeRelayBootstrapPostRecord(entry)).filter((entry) => entry != null);
}
function compareRelayBootstrapPostRecency(left, right) {
  const leftUpdatedAt = left.content?.updatedAt ?? 0;
  const rightUpdatedAt = right.content?.updatedAt ?? 0;
  if (leftUpdatedAt !== rightUpdatedAt) return leftUpdatedAt - rightUpdatedAt;
  const leftTime = left.time ?? 0;
  const rightTime = right.time ?? 0;
  return leftTime - rightTime;
}
function relayBootstrapRecordIdentity(post) {
  const content = post.content;
  if (!content) return null;
  if (content.registrationId) return `registration:${content.registrationId}`;
  if (post.address) return `sender:${normalizeAddress(post.address)}`;
  return content.peerId ? `peer:${content.peerId}` : null;
}
function selectCurrentRelayBootstrapPosts(posts, options = {}) {
  const maxAgeMs = options.maxAgeMs ?? DEFAULT_BOOTSTRAP_MAX_AGE_MS;
  const now = options.now ?? Date.now();
  const selected = /* @__PURE__ */ new Map();
  for (const post of posts) {
    const content = post.content;
    if (!content) continue;
    if (now - content.updatedAt > maxAgeMs) continue;
    const identity = relayBootstrapRecordIdentity(post);
    if (!identity) continue;
    const previous = selected.get(identity);
    if (!previous || compareRelayBootstrapPostRecency(post, previous) > 0) {
      selected.set(identity, post);
    }
  }
  return [...selected.values()].sort(
    (left, right) => compareRelayBootstrapPostRecency(right, left)
  );
}
async function filterTrustedRelayBootstrapPosts(posts, options = {}) {
  const requireDualKeyAttestation = options.requireDualKeyAttestation ?? false;
  const verifyDualKeyAttestation = options.verifyDualKeyAttestation ?? true;
  const trusted = [];
  for (const post of posts) {
    const content = post.content;
    if (!content) continue;
    const trustMode = relayBootstrapTrustMode(content);
    if (trustMode === "legacy-wallet-signed") {
      if (!requireDualKeyAttestation) {
        trusted.push(post);
      }
      continue;
    }
    if (!verifyDualKeyAttestation) {
      trusted.push(post);
      continue;
    }
    const verification = await verifyRelayBootstrapDualKeyContent(content);
    if (verification.ok) {
      trusted.push(post);
    }
  }
  return trusted;
}
async function discoverAlephBootstrapMultiaddrs(options = {}) {
  const browserDialableOnly = options.browserDialableOnly ?? true;
  const pagination = options.pagination ?? DEFAULT_BOOTSTRAP_PAGINATION;
  const startPage = options.page ?? 1;
  const maxPages = Math.max(1, options.maxPages ?? DEFAULT_BOOTSTRAP_MAX_PAGES);
  const collectedPosts = [];
  for (let offset = 0; offset < maxPages; offset += 1) {
    const page = startPage + offset;
    const pagePosts = await fetchAlephBootstrapPosts({
      ...options,
      page,
      pagination
    });
    collectedPosts.push(...pagePosts);
    const selectedPosts = selectCurrentRelayBootstrapPosts(collectedPosts, {
      maxAgeMs: options.maxAgeMs
    });
    const trustedPosts = await filterTrustedRelayBootstrapPosts(selectedPosts, {
      requireDualKeyAttestation: options.requireDualKeyAttestation,
      verifyDualKeyAttestation: options.verifyDualKeyAttestation
    });
    const addrs = relayBootstrapPostsToMultiaddrs(
      trustedPosts,
      browserDialableOnly
    );
    if (addrs.length > 0) {
      return addrs;
    }
    if (pagePosts.length < pagination) {
      break;
    }
  }
  return [];
}
function relayBootstrapPostsToMultiaddrs(posts, browserDialableOnly) {
  const addrs = [];
  for (const post of posts) {
    const content = post.content;
    if (!content) continue;
    const candidates = browserDialableOnly && Array.isArray(content.browserMultiaddrs) && content.browserMultiaddrs.length > 0 ? content.browserMultiaddrs : content.multiaddrs;
    addrs.push(
      ...filterPublicMultiaddrs(candidates, {
        browserDialableOnly
      })
    );
  }
  return dedupeMultiaddrs(addrs);
}
async function createLibp2pAlephBootstrap(options = {}) {
  const list = await discoverAlephBootstrapMultiaddrs(options);
  return bootstrap({
    list,
    timeout: options.timeout,
    tagName: options.tagName
  });
}
export {
  DEFAULT_ALEPH_API_HOST,
  DEFAULT_ALEPH_BOOTSTRAP_CHANNEL,
  DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE,
  DEFAULT_ALEPH_BOOTSTRAP_REF,
  DEFAULT_BOOTSTRAP_MAX_AGE_MS,
  DEFAULT_BOOTSTRAP_MAX_PAGES,
  DEFAULT_BOOTSTRAP_PAGINATION,
  RELAY_BOOTSTRAP_SIGNATURE_SCHEME,
  buildRelayBootstrapPostContent,
  createLibp2pAlephBootstrap,
  createRelayBootstrapPost,
  dedupeMultiaddrs,
  discoverAlephBootstrapMultiaddrs,
  fetchAlephBootstrapPosts,
  filterPublicMultiaddrs,
  isPublicMultiaddr,
  relayBootstrapTrustMode,
  selectCurrentRelayBootstrapPosts,
  signRelayBootstrapAuthorization,
  signRelayBootstrapProof,
  verifyRelayBootstrapAuthorization,
  verifyRelayBootstrapDualKeyContent,
  verifyRelayBootstrapProof
};
