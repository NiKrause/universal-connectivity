import { bootstrap } from '@libp2p/bootstrap';

declare const DEFAULT_ALEPH_API_HOST = "https://api.aleph.im";
declare const DEFAULT_ALEPH_BOOTSTRAP_CHANNEL = "simple-todo";
declare const DEFAULT_ALEPH_BOOTSTRAP_REF = "simple-todo-bootstrap";
declare const DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE = "relay-bootstrap";
declare const DEFAULT_BOOTSTRAP_MAX_AGE_MS: number;
declare const DEFAULT_BOOTSTRAP_PAGINATION = 50;
declare const DEFAULT_BOOTSTRAP_MAX_PAGES = 5;
declare const RELAY_BOOTSTRAP_SIGNATURE_SCHEME = "personal_sign";
interface RelayBootstrapAuthorizationPayload {
    ownerAddress: string;
    publisherAddress: string;
    peerId: string;
    registrationId?: string;
    profile?: string;
    version?: string;
    instanceItemHash?: string;
    issuedAt: number;
    expiresAt?: number;
}
interface RelayBootstrapAuthorizationRecord {
    scheme: string;
    payload: RelayBootstrapAuthorizationPayload;
    signature: string;
}
interface RelayBootstrapProofPayload {
    peerId: string;
    multiaddrs: string[];
    browserMultiaddrs?: string[];
    registrationId?: string;
    profile?: string;
    version?: string;
    updatedAt: number;
}
interface RelayBootstrapProofRecord {
    scheme: string;
    payload: RelayBootstrapProofPayload;
    signature: string;
}
interface RelayBootstrapVerificationResult {
    ok: boolean;
    errors: string[];
}
type RelayBootstrapProofSigner = (address: string, payload: string) => Promise<string>;
interface RelayBootstrapContent {
    peerId: string;
    multiaddrs: string[];
    browserMultiaddrs?: string[];
    registrationId?: string;
    profile?: string;
    version?: string;
    ownerAddress?: string;
    publisherAddress?: string;
    authorization?: RelayBootstrapAuthorizationRecord;
    relayProof?: RelayBootstrapProofRecord;
    updatedAt: number;
}
interface RelayBootstrapPostContent {
    type: string;
    address: string;
    ref?: string;
    content: RelayBootstrapContent;
    time: number;
}
interface RelayBootstrapPostRecord {
    hash: string | null;
    itemHash: string | null;
    address: string | null;
    ref: string | null;
    type: string | null;
    time: number | null;
    content: RelayBootstrapContent | null;
}
interface DiscoverAlephBootstrapOptions {
    apiHost?: string;
    channel?: string;
    ref?: string;
    postType?: string;
    page?: number;
    pagination?: number;
    maxPages?: number;
    maxAgeMs?: number;
    browserDialableOnly?: boolean;
    requireDualKeyAttestation?: boolean;
    verifyDualKeyAttestation?: boolean;
    fetch?: typeof fetch;
}
interface FilterPublicMultiaddrsOptions {
    browserDialableOnly?: boolean;
    requirePeerId?: boolean;
}
interface CreateRelayBootstrapPostOptions {
    sender: string;
    peerId: string;
    multiaddrs: string[];
    browserMultiaddrs?: string[];
    registrationId?: string;
    ref?: string;
    channel?: string;
    postType?: string;
    profile?: string;
    version?: string;
    ownerAddress?: string;
    publisherAddress?: string;
    authorization?: RelayBootstrapAuthorizationRecord;
    relayProof?: RelayBootstrapProofRecord;
    now?: number;
    hasher: (payload: string) => Promise<string> | string;
}
type RelayBootstrapTrustMode = "legacy-wallet-signed" | "dual-key-attested";
declare function dedupeMultiaddrs(addrs: readonly string[]): string[];
declare function isPublicMultiaddr(addr: string): boolean;
declare function filterPublicMultiaddrs(addrs: readonly string[], options?: FilterPublicMultiaddrsOptions): string[];
declare function buildRelayBootstrapPostContent(args: {
    sender: string;
    peerId: string;
    multiaddrs: string[];
    browserMultiaddrs?: string[];
    registrationId?: string;
    ref?: string;
    postType?: string;
    profile?: string;
    version?: string;
    ownerAddress?: string;
    publisherAddress?: string;
    authorization?: RelayBootstrapAuthorizationRecord;
    relayProof?: RelayBootstrapProofRecord;
    now?: number;
}): RelayBootstrapPostContent;
declare function createRelayBootstrapPost(args: CreateRelayBootstrapPostOptions): Promise<{
    channel: string;
    sender: string;
    chain: "ETH";
    type: "POST";
    time: number;
    item_type: "inline";
    item_content: string;
    item_hash: string;
}>;
declare function relayBootstrapTrustMode(content: RelayBootstrapContent | null | undefined): RelayBootstrapTrustMode;
declare function signRelayBootstrapAuthorization(args: {
    ownerAddress: string;
    publisherAddress: string;
    peerId: string;
    registrationId?: string;
    profile?: string;
    version?: string;
    instanceItemHash?: string;
    issuedAt?: number;
    expiresAt?: number;
    signer: RelayBootstrapProofSigner;
}): Promise<RelayBootstrapAuthorizationRecord>;
declare function signRelayBootstrapProof(args: {
    publisherAddress: string;
    peerId: string;
    multiaddrs: string[];
    browserMultiaddrs?: string[];
    registrationId?: string;
    profile?: string;
    version?: string;
    updatedAt?: number;
    signer: RelayBootstrapProofSigner;
}): Promise<RelayBootstrapProofRecord>;
declare function verifyRelayBootstrapAuthorization(authorization: RelayBootstrapAuthorizationRecord | null | undefined, options?: {
    now?: number;
}): Promise<RelayBootstrapVerificationResult>;
declare function verifyRelayBootstrapProof(proof: RelayBootstrapProofRecord | null | undefined, options?: {
    expectedPublisherAddress?: string;
    expectedPeerId?: string;
}): Promise<RelayBootstrapVerificationResult>;
declare function verifyRelayBootstrapDualKeyContent(content: RelayBootstrapContent | null | undefined, options?: {
    now?: number;
}): Promise<RelayBootstrapVerificationResult>;
declare function fetchAlephBootstrapPosts(options?: DiscoverAlephBootstrapOptions): Promise<RelayBootstrapPostRecord[]>;
declare function selectCurrentRelayBootstrapPosts(posts: readonly RelayBootstrapPostRecord[], options?: Pick<DiscoverAlephBootstrapOptions, "maxAgeMs"> & {
    now?: number;
}): RelayBootstrapPostRecord[];
declare function discoverAlephBootstrapMultiaddrs(options?: DiscoverAlephBootstrapOptions): Promise<string[]>;
declare function createLibp2pAlephBootstrap(options?: DiscoverAlephBootstrapOptions & {
    timeout?: number;
    tagName?: string;
}): Promise<ReturnType<typeof bootstrap>>;

export { type CreateRelayBootstrapPostOptions, DEFAULT_ALEPH_API_HOST, DEFAULT_ALEPH_BOOTSTRAP_CHANNEL, DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE, DEFAULT_ALEPH_BOOTSTRAP_REF, DEFAULT_BOOTSTRAP_MAX_AGE_MS, DEFAULT_BOOTSTRAP_MAX_PAGES, DEFAULT_BOOTSTRAP_PAGINATION, type DiscoverAlephBootstrapOptions, type FilterPublicMultiaddrsOptions, RELAY_BOOTSTRAP_SIGNATURE_SCHEME, type RelayBootstrapAuthorizationPayload, type RelayBootstrapAuthorizationRecord, type RelayBootstrapContent, type RelayBootstrapPostContent, type RelayBootstrapPostRecord, type RelayBootstrapProofPayload, type RelayBootstrapProofRecord, type RelayBootstrapProofSigner, type RelayBootstrapTrustMode, type RelayBootstrapVerificationResult, buildRelayBootstrapPostContent, createLibp2pAlephBootstrap, createRelayBootstrapPost, dedupeMultiaddrs, discoverAlephBootstrapMultiaddrs, fetchAlephBootstrapPosts, filterPublicMultiaddrs, isPublicMultiaddr, relayBootstrapTrustMode, selectCurrentRelayBootstrapPosts, signRelayBootstrapAuthorization, signRelayBootstrapProof, verifyRelayBootstrapAuthorization, verifyRelayBootstrapDualKeyContent, verifyRelayBootstrapProof };
