import * as _le_space_shared_types from '@le-space/shared-types';
import { RootfsResolution, RootfsManifest, RootfsManifestState, CrnRecord, RootfsRequiredPortForward, PortForwardAggregate, PortForwardFlags, PortForwardAggregateEntry, MessageReference, InstanceExecution, MessageStatus, DeploymentInspectionResult, MessageInspectionResult, AlephBroadcastMessage, AlephBroadcastResponse, MessageSigner, MessageHasher, DeploymentProgressListener, AlephAggregateContent, AlephInstanceContent, DeploymentIntentEnvelope, DeploymentResult, InstanceAllocation, InstanceRuntimeDetails, InstanceWebAccess, RuntimeDiagnostics, PortMapping, VmBootstrapConfigRecord, VmBootstrapConfigAggregate, VmBootstrapConfigSignalRecord, VmBootstrapConfigSignalType } from '@le-space/shared-types';

declare const DEFAULT_ALEPH_CHANNEL = "TEST";

declare const ITEM_HASH_RE: RegExp;
declare const DEFAULT_ALEPH_API_HOST = "https://api.aleph.im";
declare const DEFAULT_IPFS_GATEWAY_BASE_URL = "https://ipfs.aleph.cloud/ipfs/";
interface FetchLikeResponse {
    ok: boolean;
    status: number;
    url?: string;
    json(): Promise<unknown>;
}
type FetchLike = (url: string, init?: RequestInit) => Promise<FetchLikeResponse>;
declare function validateRootfsManifest(manifest: RootfsManifest | null): RootfsManifestState;
declare function verifyRootfsExists(itemHash: string, options: {
    apiHost?: string;
    fetch: FetchLike;
}): Promise<boolean>;
declare function probeRootfsGateway(cid: string, options: {
    gatewayBaseUrl?: string;
    fetch: FetchLike;
}): Promise<Pick<RootfsResolution, 'gatewayStatus' | 'gatewayError' | 'gatewayUrl'>>;
declare function resolveRootfsReference(itemHash: string, options: {
    apiHost?: string;
    gatewayBaseUrl?: string;
    fetch: FetchLike;
}): Promise<RootfsResolution | null>;

declare const DEFAULT_CRN_LIST_URL = "https://crns-list.aleph.sh/crns.json";
declare const DEFAULT_COUNTRY_LOOKUP_BASE_URL = "https://api.country.is";
declare const DEFAULT_DNS_RESOLVE_URL = "https://dns.google/resolve";
interface CrnCapacitySpec {
    vcpus: number;
    memoryMiB: number;
    diskMiB: number;
}
declare function filterDeployableCrns<TCrn extends CrnRecord>(crns: ReadonlyArray<TCrn>, options?: {
    excludedHashes?: ReadonlyArray<string>;
    spec?: CrnCapacitySpec | null;
}): TCrn[];
declare function fetchCrns(options: {
    url?: string;
    fetch: FetchLike;
}): Promise<CrnRecord[]>;
declare function enrichCrnsWithGeo(crns: ReadonlyArray<CrnRecord>, options: {
    fetch: FetchLike;
    dnsResolveUrl?: string;
    countryLookupBaseUrl?: string;
}): Promise<CrnRecord[]>;
declare function listGeocodedCrns(options: {
    fetch: FetchLike;
    url?: string;
    limit?: number;
    dnsResolveUrl?: string;
    countryLookupBaseUrl?: string;
}): Promise<CrnRecord[]>;
declare function rankCandidateCrns(crns: ReadonlyArray<CrnRecord>, options: {
    fetch: FetchLike;
    preferredCountryCode?: string;
    geoLimit?: number;
    excludedHashes?: string[];
    dnsResolveUrl?: string;
    countryLookupBaseUrl?: string;
}): Promise<CrnRecord[]>;
declare function selectPreferredCrn(crns: ReadonlyArray<CrnRecord>, options: {
    fetch: FetchLike;
    preferredCountryCode?: string;
    geoLimit?: number;
    excludedHashes?: string[];
    dnsResolveUrl?: string;
    countryLookupBaseUrl?: string;
}): Promise<CrnRecord | null>;

declare const DEFAULT_INSTANCE_PORT_FORWARDS: RootfsRequiredPortForward[];
declare function normalizeExistingPortForwardEntry(entry: PortForwardAggregateEntry | null | undefined): Record<string, PortForwardFlags>;
declare function requestedPortFlags(portForwards: ReadonlyArray<RootfsRequiredPortForward>): Record<string, PortForwardFlags>;
declare function mergePortFlagMaps(existing: Record<string, PortForwardFlags>, requested: Record<string, PortForwardFlags>): Record<string, PortForwardFlags>;
declare function mergeRequiredPortForwards(...groups: Array<ReadonlyArray<RootfsRequiredPortForward> | undefined>): RootfsRequiredPortForward[];
declare function requiredInstancePortForwards(manifest: RootfsManifest | null): RootfsRequiredPortForward[];
declare function portForwardLabel(entry: RootfsRequiredPortForward): string;
declare function fetchPortForwardAggregate(address: string, options: {
    apiHost?: string;
    fetch: FetchLike;
}): Promise<PortForwardAggregate>;

type MessageEnvelope$1 = {
    status?: unknown;
    type?: unknown;
    error_code?: unknown;
    details?: unknown;
    message?: {
        type?: unknown;
    } | null;
    messages?: Array<{
        type?: unknown;
    }> | null;
};
type CrnExecutionV1Payload = {
    networking?: {
        ipv4?: unknown;
        ipv6?: unknown;
    } | null;
};
type CrnExecutionV2Payload = {
    networking?: {
        ipv4_network?: unknown;
        host_ipv4?: unknown;
        ipv6_network?: unknown;
        ipv6_ip?: unknown;
        ipv4_ip?: unknown;
        proxy_url?: unknown;
        proxyUrl?: unknown;
        web_access_url?: unknown;
        webAccessUrl?: unknown;
        proxy_hostname?: unknown;
        proxyHostname?: unknown;
        domain?: unknown;
        hostname?: unknown;
        mapped_ports?: Record<string, {
            host?: unknown;
            tcp?: unknown;
            udp?: unknown;
        }> | null;
    } | null;
    web_access?: {
        url?: unknown;
        proxy_url?: unknown;
        hostname?: unknown;
        domain?: unknown;
    } | null;
    webAccess?: {
        url?: unknown;
        proxy_url?: unknown;
        hostname?: unknown;
        domain?: unknown;
    } | null;
    status?: {
        defined_at?: unknown;
        preparing_at?: unknown;
        prepared_at?: unknown;
        starting_at?: unknown;
        started_at?: unknown;
        stopping_at?: unknown;
        stopped_at?: unknown;
    } | null;
    running?: unknown;
};
declare function normalizeMessageStatus(status: unknown): MessageStatus;
declare function normalizeProxyUrl(value: unknown): string | null;
declare function messageTypeFromEnvelope(payload: MessageEnvelope$1 | null): string | null;
declare function extractReferenceHashes(details: unknown): string[];
declare function extractInsufficientBalanceMessage(details: unknown): string | null;
declare function describeRejectedDeployment(payload: MessageEnvelope$1, references: MessageReference[], rootfsRef?: string): string;
declare function extractProxyUrl(item: CrnExecutionV2Payload, networking: CrnExecutionV2Payload['networking']): string | null;
declare function normalizeExecution(item: CrnExecutionV1Payload | CrnExecutionV2Payload, crnUrl: string): InstanceExecution;

type MessageEnvelope = {
    status?: unknown;
    type?: unknown;
    error_code?: unknown;
    details?: unknown;
    message?: {
        type?: unknown;
    } | null;
    messages?: Array<{
        type?: unknown;
    }> | null;
};
declare function fetchMessageEnvelope(itemHash: string, options: {
    apiHost?: string;
    fetch: FetchLike;
}): Promise<MessageEnvelope | null>;
declare function inspectMessageResult(itemHash: string, options: {
    apiHost?: string;
    fetch: FetchLike;
    label?: string;
}): Promise<MessageInspectionResult>;
declare function inspectDeploymentResult(itemHash: string, options: {
    rootfsRef?: string;
    apiHost?: string;
    fetch: FetchLike;
}): Promise<DeploymentInspectionResult>;
declare function waitForDeploymentResult(itemHash: string, options: {
    rootfsRef?: string;
    apiHost?: string;
    fetch: FetchLike;
    attempts?: number;
    delayMs?: number;
    sleep?: (ms: number) => Promise<void>;
    onAttempt?: (result: DeploymentInspectionResult, attempt: number, attempts: number) => void;
}): Promise<DeploymentInspectionResult>;

interface JsonFetchLikeResponse {
    ok: boolean;
    status: number;
    json(): Promise<unknown>;
}
type JsonFetchLike$1 = (url: string, init?: RequestInit) => Promise<JsonFetchLikeResponse>;
declare function signaturePayload(message: Pick<AlephBroadcastMessage, 'chain' | 'sender' | 'type' | 'item_hash'>): string;
declare function signAlephMessage(unsignedMessage: Omit<AlephBroadcastMessage, 'signature'>, signer: MessageSigner): Promise<AlephBroadcastMessage>;
declare function normalizeBroadcastStatus(httpStatus: number, responseStatus: unknown): MessageStatus;
declare function isInvalidMessageFormatResponse(response: {
    status: number;
}, payload: AlephBroadcastResponse): boolean;
declare function isRetryableBroadcastFailure(response: {
    status: number;
}, payload: AlephBroadcastResponse): boolean;
declare function postBroadcastPayload(body: Record<string, unknown>, options: {
    apiHost?: string;
    fetch: JsonFetchLike$1;
}): Promise<{
    response: AlephBroadcastResponse;
    httpStatus: number;
}>;
declare function broadcastAlephMessage(message: AlephBroadcastMessage, options: {
    apiHost?: string;
    sync?: boolean;
    fetch: JsonFetchLike$1;
}): Promise<{
    response: AlephBroadcastResponse;
    httpStatus: number;
}>;

interface CrnResolutionResult {
    crnUrl: string | null;
    crnHash: string | null;
    source: 'provided' | 'scheduler' | 'manual' | 'missing';
}
interface CrnEraseResult extends CrnResolutionResult {
    status: 'erased' | 'missing' | 'skipped';
}
declare function resolveInstanceCrn(args: {
    instanceHash: string;
    fetch: FetchLike;
    apiHost?: string;
    crnUrl?: string | null;
    crnHash?: string | null;
    crnListUrl?: string;
    schedulerAllocationUrl?: string;
}): Promise<CrnResolutionResult>;
declare function eraseInstanceOnCrn(args: {
    sender: string;
    signer: MessageSigner;
    instanceHash: string;
    fetch: FetchLike;
    apiHost?: string;
    crnUrl?: string | null;
    crnHash?: string | null;
    crnListUrl?: string;
    schedulerAllocationUrl?: string;
}): Promise<CrnEraseResult>;

declare function createUnsignedForgetMessage(args: {
    sender: string;
    hashes?: string[];
    aggregates?: string[];
    reason?: string;
    hasher: MessageHasher;
    channel?: string;
    now?: number;
}): Promise<Omit<AlephBroadcastMessage, 'signature'>>;
declare function forgetAlephMessages(args: {
    sender: string;
    hashes?: string[];
    aggregates?: string[];
    reason?: string;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    channel?: string;
    apiHost?: string;
    sync?: boolean;
    now?: number;
    onProgress?: DeploymentProgressListener;
}): Promise<{
    sender: string;
    itemHash: string;
    response: _le_space_shared_types.AlephBroadcastResponse;
    httpStatus: number;
    status: _le_space_shared_types.MessageStatus;
}>;
declare function cleanupFailedDeployment(args: {
    sender: string;
    instanceItemHash: string;
    reason?: string;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    channel?: string;
    apiHost?: string;
}): Promise<{
    sender: string;
    itemHash: string;
    response: _le_space_shared_types.AlephBroadcastResponse;
    httpStatus: number;
    status: _le_space_shared_types.MessageStatus;
} | {
    error: string;
}>;

declare const SUCCESSFUL_DEPLOYMENTS_AGGREGATE_KEY = "uc-go-peer-successful-deployments";
interface RetentionRecord {
    instance_item_hash: string;
    rootfs_item_hash: string;
    site_item_hash: string;
    rootfs_cid: string;
    site_url: string;
    relay_peer_id: string;
    rootfs_version: string;
    deployed_at: string;
    vm_name: string;
}
declare function fetchAggregateKey(args: {
    address: string;
    key: string;
    fetch: JsonFetchLike$1;
    apiHost?: string;
}): Promise<unknown>;
declare function publishAggregateKey(args: {
    sender: string;
    key: string;
    content: Record<string, unknown>;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    channel?: string;
    apiHost?: string;
    now?: number;
}): Promise<{
    itemHash: string;
    status: _le_space_shared_types.MessageStatus;
    response: _le_space_shared_types.AlephBroadcastResponse;
    httpStatus: number;
}>;
declare function retainSuccessfulDeployments(args: {
    sender: string;
    currentRecord: unknown;
    keepCount: number;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    aggregateKey?: string;
    extraForgetHashes?: string[];
    reason?: string;
    channel?: string;
    apiHost?: string;
    crnListUrl?: string;
    schedulerAllocationUrl?: string;
    now?: number;
}): Promise<{
    sender: string;
    aggregateKey: string;
    keepCount: number;
    aggregatePublication: {
        itemHash: string;
        status: _le_space_shared_types.MessageStatus;
        response: _le_space_shared_types.AlephBroadcastResponse;
        httpStatus: number;
    };
    retainedRecords: RetentionRecord[];
    prunedRecords: RetentionRecord[];
    forgetHashes: string[];
    forgottenHashes: string[];
    outstandingForgetHashes: string[];
    forgetStatuses: Record<string, string>;
    forgetResult: {
        sender: string;
        itemHash: string;
        response: _le_space_shared_types.AlephBroadcastResponse;
        httpStatus: number;
        status: _le_space_shared_types.MessageStatus;
    } | null;
    followUpForgetResults: {
        hash: string;
        result: Awaited<ReturnType<typeof forgetAlephMessages>>;
    }[];
    forgetStageResults: {
        stage: "instances" | "dependents";
        hashes: string[];
        eraseResults?: Array<{
            hash: string;
            status: "erased" | "missing" | "skipped";
            crnUrl: string | null;
            crnHash: string | null;
            source: "provided" | "scheduler" | "manual" | "missing";
        }>;
        skipped?: boolean;
        skippedReason?: string;
        forgottenHashes: string[];
        outstandingForgetHashes: string[];
        statuses: Record<string, string>;
        forgetResult: Awaited<ReturnType<typeof forgetAlephMessages>> | null;
        followUpForgetResults: Array<{
            hash: string;
            result: Awaited<ReturnType<typeof forgetAlephMessages>>;
        }>;
    }[];
}>;

declare function createPortForwardAggregateContent(args: {
    sender: string;
    instanceItemHash: string;
    requestedPorts: ReadonlyArray<RootfsRequiredPortForward>;
    existingAggregate?: PortForwardAggregate;
    now?: number;
}): AlephAggregateContent<PortForwardAggregate>;
declare function createUnsignedAggregateMessage(args: {
    sender: string;
    content: AlephAggregateContent<PortForwardAggregate>;
    hasher: MessageHasher;
    channel?: string;
    now?: number;
}): Promise<Omit<AlephBroadcastMessage, 'signature'>>;
declare function ensureInstancePortForwards(args: {
    sender: string;
    instanceItemHash: string;
    manifest: RootfsManifest | null;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    channel?: string;
    apiHost?: string;
    sync?: boolean;
}): Promise<{
    aggregateItemHash: string;
    aggregateStatus: MessageStatus;
    requestedPorts: RootfsRequiredPortForward[];
}>;

declare const SSH_PUBLIC_KEY_PATTERN: RegExp;
interface TierSpec {
    vcpus: number;
    memoryMiB: number;
    diskMiB: number;
}
interface PaymentQuote {
    required: number;
    available: number;
    computeUnits: number;
    unitPrice: number;
    label: 'credits';
}
declare function normalizeSshPublicKey(value: string): string;
declare function isValidSshPublicKey(value: string): boolean;
declare function createDeploymentToken(): string;
declare function appendDeploymentTokenToSshPublicKey(sshPublicKey: string, ownerAddress: string, deploymentToken: string): string;
declare function createReleaseMetadata(name: string, rootfsVersion: string, deployer?: string): {
    name: string;
    rootfs_version: string;
    deployer: string;
};
declare function selectedTier<TTier extends {
    id: string;
}>(pricing: {
    tiers: TTier[];
} | null, tierId: string): TTier | null;
declare function tierSpec<TTier extends {
    compute_units: number;
}>(pricing: {
    compute_unit: {
        vcpus: number;
        memory_mib: number;
        disk_mib: number;
    };
}, tier: TTier): TierSpec;
declare function buildPaymentQuote<TTier extends {
    compute_units: number;
}>(tier: TTier, pricing: {
    price: {
        compute_unit?: {
            credit?: string | number | null;
        } | null;
    };
}, balance: {
    credit_balance?: number | null;
}): PaymentQuote | null;
declare function quoteRequiredBudgetUnits(quote: PaymentQuote | null): bigint;
declare function createInstanceContent(args: {
    address: string;
    name: string;
    sshPublicKey: string;
    rootfsItemHash: string;
    rootfsSizeMiB: number;
    vcpus: number;
    memoryMiB: number;
    seconds?: number;
    rootfsVersion?: string;
    crnHash?: string;
    deployer?: string;
    now?: number;
}): AlephInstanceContent;
declare function createUnsignedInstanceMessage(args: {
    sender: string;
    content: AlephInstanceContent;
    hasher: MessageHasher;
    channel?: string;
    now?: number;
}): Promise<Omit<AlephBroadcastMessage, 'signature'>>;
declare function createDeploymentIntent(args: {
    sender: string;
    unsignedMessage: Omit<AlephBroadcastMessage, 'signature'>;
    content: AlephInstanceContent;
    computeUnits: number;
    expiresAt: number;
    maxCost: string;
    hasher: MessageHasher;
}): Promise<DeploymentIntentEnvelope>;
declare function deployInstance(args: {
    sender: string;
    content: AlephInstanceContent;
    hasher: MessageHasher;
    signer: MessageSigner;
    fetch: (url: string, init?: RequestInit) => Promise<{
        ok: boolean;
        status: number;
        json(): Promise<unknown>;
    }>;
    apiHost?: string;
    channel?: string;
    sync?: boolean;
    now?: number;
    onProgress?: DeploymentProgressListener;
}): Promise<DeploymentResult>;

declare const DEFAULT_SCHEDULER_ALLOCATION_URL = "https://scheduler.api.aleph.cloud/api/v0/allocation";
declare const DEFAULT_TWO_N_SIX_HASH_URL = "https://api.2n6.me/api/hash";
type CrnExecutionLookup = {
    version: 'v1' | 'v2';
    payload: Record<string, unknown> | null;
    requestUrl: string;
};
declare function findCrnByHash(crns: ReadonlyArray<CrnRecord>, crnHash: string): CrnRecord | null;
declare function fetchSchedulerAllocation(itemHash: string, options: {
    fetch: FetchLike;
    schedulerAllocationUrl?: string;
}): Promise<InstanceAllocation | null>;
declare function fetch2n6WebAccessUrl(itemHash: string, options: {
    fetch: FetchLike;
    twoN6HashUrl?: string;
}): Promise<InstanceWebAccess | null>;
declare function fetchCrnExecutionMap(crnUrl: string, options: {
    fetch: FetchLike;
}): Promise<CrnExecutionLookup>;
declare function describeRuntimeAvailability(runtime: {
    allocation?: InstanceAllocation | null;
    execution?: InstanceRuntimeDetails['execution'];
    webAccess?: InstanceWebAccess | null;
    hostIpv4?: string | null;
    ipv6?: string | null;
    proxyUrl?: string | null;
    mappedPorts?: Record<string, unknown>;
    requirePublicGuestIpv6ForProxy?: boolean;
}): RuntimeDiagnostics;
declare function fetchVmRuntime(args: {
    itemHash: string;
    fetch: FetchLike;
    crns?: CrnRecord[];
    crnHash?: string;
    crnListUrl?: string;
    schedulerAllocationUrl?: string;
    twoN6HashUrl?: string;
    requirePublicGuestIpv6ForProxy?: boolean;
}): Promise<Omit<InstanceRuntimeDetails, 'messageStatus'>>;
declare function waitForVmRuntime(args: {
    itemHash: string;
    fetch: FetchLike;
    crns?: CrnRecord[];
    crnHash?: string;
    crnListUrl?: string;
    schedulerAllocationUrl?: string;
    twoN6HashUrl?: string;
    requirePublicGuestIpv6ForProxy?: boolean;
    attempts?: number;
    delayMs?: number;
    sleep?: (ms: number) => Promise<void>;
    onAttempt?: (runtime: Omit<InstanceRuntimeDetails, 'messageStatus'>, attempt: number, attempts: number) => void;
}): Promise<Omit<InstanceRuntimeDetails, 'messageStatus'>>;

type TcpProbeResult = {
    ok: boolean | null;
    error?: string;
};
type HttpProbeResult = {
    ok: boolean;
    status?: number;
    url?: string;
    error?: string;
};
declare function notifyCrnAllocation(args: {
    crnUrl: string | null | undefined;
    itemHash: string;
    fetch: FetchLike;
}): Promise<{
    status: "confirmed" | "unconfirmed" | "skipped";
    reason?: string;
    payload?: unknown;
}>;
declare function notifyCrnAllocationWithRetry(args: {
    crnUrl: string | null | undefined;
    itemHash: string;
    fetch: FetchLike;
    attempts?: number;
    delayMs?: number;
    sleep?: (ms: number) => Promise<void>;
    onProgress?: DeploymentProgressListener;
}): Promise<{
    status: "confirmed" | "unconfirmed" | "skipped";
    reason?: string;
    payload?: unknown;
}>;
declare function waitForSetupEndpoint(args: {
    hostIpv4: string;
    setupPort: number;
    fetch: FetchLike;
    attempts?: number;
    delayMs?: number;
    httpTimeoutMs?: number;
    sleep?: (ms: number) => Promise<void>;
    onAttempt?: (result: HttpProbeResult, attempt: number, attempts: number) => void;
}): Promise<HttpProbeResult>;
declare function configureUcGoPeer(args: {
    hostIpv4: string;
    setupPort: number;
    publicIpv6?: string | null;
    tcpPort?: number | null;
    wsPort?: number | null;
    udpPort?: number | null;
    quicPort?: number | null;
    webrtcPort?: number | null;
    proxyUrl?: string | null;
    bootstrapPublisherPrivateKey?: string | null;
    bootstrapPublisherLibp2pIdentityBase64?: string | null;
    bootstrapOwnerPrivateKey?: string | null;
    bootstrapOwnerAuthorizationBase64?: string | null;
    bootstrapRegistrationId?: string | null;
    noStart?: boolean;
    fetch: FetchLike;
    timeoutMs?: number;
}): Promise<unknown>;
declare function configureOrbitdbRelaySetup(args: {
    hostIpv4: string;
    setupPort: number;
    publicIpv6?: string | null;
    tcpPort: number;
    wsPort: number;
    metricsPort?: number | null;
    metricsHttpsPort?: number | null;
    webrtcPort?: number | null;
    quicPort?: number | null;
    proxyUrl?: string | null;
    bootstrapPublisherPrivateKey?: string | null;
    bootstrapPublisherLibp2pIdentityHex?: string | null;
    bootstrapOwnerPrivateKey?: string | null;
    bootstrapOwnerAuthorizationBase64?: string | null;
    bootstrapRegistrationId?: string | null;
    noStart?: boolean;
    fetch: FetchLike;
    timeoutMs?: number;
}): Promise<unknown>;
declare function fetchUcGoPeerMetadata(args: {
    hostIpv4: string;
    setupPort: number;
    metadataUrl?: string | null;
    fetch: FetchLike;
    attempts?: number;
    delayMs?: number;
    timeoutMs?: number;
    sleep?: (ms: number) => Promise<void>;
    isReady?: (result: {
        payload: unknown;
        ok: boolean;
        status: number | null;
        requestUrl: string;
    }) => boolean;
    onAttempt?: (result: {
        payload: unknown;
        ready: boolean;
        attempt: number;
        attempts: number;
        requestUrl: string;
        ok: boolean;
        status: number | null;
        error?: string | null;
    }) => void;
}): Promise<unknown>;
declare function verifyUcGoPeerReachability(args: {
    hostIpv4?: string | null;
    mappedPorts?: Record<string, PortMapping>;
    proxyUrl?: string | null;
    verifyProxyHttp?: boolean;
    skipInternalPorts?: string[];
    tcpTimeoutMs?: number;
    httpTimeoutMs?: number;
    fetch: FetchLike;
    tcpProbe: (host: string, port: number, timeoutMs?: number) => Promise<TcpProbeResult>;
    httpProbe?: (url: string, timeoutMs?: number) => Promise<HttpProbeResult>;
}): Promise<{
    ok: boolean;
    checks: Record<string, Record<string, unknown>>;
}>;

interface RelayBootstrapAuthorizationPayload {
    ownerAddress: string;
    publisherAddress: string;
    peerId: string;
    registrationId?: string;
    profile?: string;
    version?: string;
    instanceItemHash?: string;
    issuedAt: number;
    expiresAt?: number;
}
interface RelayBootstrapAuthorizationRecord {
    scheme: string;
    payload: RelayBootstrapAuthorizationPayload;
    signature: string;
}
interface RelayBootstrapProofPayload {
    peerId: string;
    multiaddrs: string[];
    browserMultiaddrs?: string[];
    registrationId?: string;
    profile?: string;
    version?: string;
    updatedAt: number;
}
interface RelayBootstrapProofRecord {
    scheme: string;
    payload: RelayBootstrapProofPayload;
    signature: string;
}
type RelayBootstrapProofSigner = (address: string, payload: string) => Promise<string>;

interface RelayBootstrapPublicationResult {
    status: "published" | "skipped";
    reason?: string;
    itemHash?: string;
    message?: AlephBroadcastMessage;
    response?: AlephBroadcastResponse;
    httpStatus?: number;
    publishedMultiaddrs?: string[];
    publishedBrowserMultiaddrs?: string[];
    forgottenHashes?: string[];
    forgetResult?: Awaited<ReturnType<typeof forgetAlephMessages>>;
}
interface RelayBootstrapVisibilityResult {
    itemHash: string | null;
    hash: string | null;
    sender?: string | null;
    registrationId?: string;
    peerId?: string;
    multiaddrs: string[];
    browserMultiaddrs: string[];
}
declare function waitForRelayBootstrapRegistration(args: {
    sender?: string;
    fetch: JsonFetchLike$1;
    registrationId?: string;
    peerId?: string;
    apiHost?: string;
    channel?: string;
    ref?: string;
    postType?: string;
    attempts?: number;
    delayMs?: number;
    onAttempt?: (match: RelayBootstrapVisibilityResult | null, attempt: number, attempts: number) => void;
}): Promise<RelayBootstrapVisibilityResult | null>;
declare function publishRelayBootstrapRegistration(args: {
    sender: string;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    peerId: string;
    multiaddrs: string[];
    browserMultiaddrs?: string[];
    registrationId?: string;
    apiHost?: string;
    channel?: string;
    ref?: string;
    postType?: string;
    profile?: string;
    version?: string;
    ownerAddress?: string;
    publisherAddress?: string;
    ownerSigner?: RelayBootstrapProofSigner;
    publisherSigner?: RelayBootstrapProofSigner;
    ownerAuthorization?: RelayBootstrapAuthorizationRecord;
    relayProof?: RelayBootstrapProofRecord;
    authorizationIssuedAt?: number;
    authorizationExpiresAt?: number;
    instanceItemHash?: string;
    forgetPrevious?: boolean;
    forgetPreviousReason?: string;
    sync?: boolean;
    now?: number;
}): Promise<RelayBootstrapPublicationResult>;

declare const VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY = "vm-bootstrap-config";
declare const VM_BOOTSTRAP_CONFIG_SIGNAL_REF = "vm-bootstrap-config";
declare const VM_BOOTSTRAP_CONFIG_SIGNAL_POST_TYPE = "vm-bootstrap-config-status";
declare const VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS: number;
declare function fetchVmBootstrapConfigAggregate(address: string, options: {
    apiHost?: string;
    fetch: JsonFetchLike$1;
}): Promise<VmBootstrapConfigAggregate>;
declare function createVmBootstrapConfigAggregateContent(args: {
    sender: string;
    record: VmBootstrapConfigRecord;
    existingAggregate?: VmBootstrapConfigAggregate | null;
    now?: number;
    maxRecordAgeMs?: number;
}): AlephAggregateContent<VmBootstrapConfigAggregate>;
declare function listStaleVmBootstrapConfigAggregateMessageHashes(args: {
    address: string;
    currentAggregateItemHash?: string | null;
    olderThanMs?: number;
    fetch: JsonFetchLike$1;
    apiHost?: string;
    pagination?: number;
    maxPages?: number;
    nowMs?: number;
}): Promise<string[]>;
declare function publishVmBootstrapConfig(args: {
    sender: string;
    record: VmBootstrapConfigRecord;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    channel?: string;
    apiHost?: string;
    sync?: boolean;
}): Promise<{
    aggregateItemHash: string;
    aggregateStatus: MessageStatus;
    aggregate: VmBootstrapConfigAggregate;
}>;
declare function deleteVmBootstrapConfig(args: {
    sender: string;
    deploymentToken: string;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike$1;
    channel?: string;
    apiHost?: string;
    sync?: boolean;
}): Promise<{
    aggregateItemHash: string;
    aggregateStatus: MessageStatus;
    aggregate: VmBootstrapConfigAggregate;
}>;
declare function fetchVmBootstrapConfigSignals(args: {
    deploymentToken?: string;
    ownerAddress?: string;
    instanceItemHash?: string;
    fetch: JsonFetchLike$1;
    apiHost?: string;
    ref?: string;
    postType?: string;
    page?: number;
    pagination?: number;
}): Promise<VmBootstrapConfigSignalRecord[]>;
declare function waitForVmBootstrapConfigSignal(args: {
    deploymentToken: string;
    ownerAddress: string;
    instanceItemHash: string;
    expectedStatus?: VmBootstrapConfigSignalType;
    fetch: JsonFetchLike$1;
    apiHost?: string;
    ref?: string;
    postType?: string;
    attempts?: number;
    delayMs?: number;
    sleep?: (ms: number) => Promise<void>;
}): Promise<VmBootstrapConfigSignalRecord | null>;

type JsonFetchLike = FetchLike;
type RelayMetadataShape = {
    peerId: string;
    probeMultiaddrs: string[];
    browserBootstrapMultiaddrs: string[];
};
interface OwnerRelayBootstrapReconcileResult {
    refreshedRegistrations: string[];
    forgottenHashes: string[];
    skippedInstanceHashes: string[];
    errors: Array<{
        phase: string;
        itemHash?: string;
        registrationId?: string;
        message: string;
    }>;
}
declare function createRelayBootstrapRegistrationId(profile: string, instanceName: string | null | undefined, itemHash: string): string;
declare function fetchRelayMetadataForRuntime(args: {
    runtime: Awaited<ReturnType<typeof fetchVmRuntime>>;
    fetch: JsonFetchLike;
    preferSecureMetadata?: boolean;
    attempts?: number;
    delayMs?: number;
    timeoutMs?: number;
    onAttempt?: (result: {
        payload: unknown;
        ready: boolean;
        attempt: number;
        attempts: number;
        requestUrl: string;
        ok: boolean;
        status: number | null;
        error?: string | null;
        metadataUrl: string | null;
        hostIpv4: string | null;
        setupPort: number;
    }) => void;
}): Promise<RelayMetadataShape | null>;
declare function reconcileOwnerRelayBootstrapRegistrations(args: {
    instanceOwnerAddress: string;
    sender: string;
    signer: MessageSigner;
    hasher: MessageHasher;
    fetch: JsonFetchLike;
    profile: string;
    apiHost?: string;
    channel?: string;
    ref?: string;
    postType?: string;
    version?: string;
    ownerAddress?: string;
    ownerSigner?: MessageSigner;
    publisherAddress?: string;
    publisherSigner?: MessageSigner;
    crns?: CrnRecord[];
    crnListUrl?: string;
    preferSecureMetadata?: boolean;
    current?: {
        itemHash: string;
        registrationId: string;
        peerId: string;
        probeMultiaddrs: string[];
        browserBootstrapMultiaddrs?: string[];
    } | null;
}): Promise<OwnerRelayBootstrapReconcileResult>;

export { type CrnCapacitySpec, type CrnEraseResult, type CrnResolutionResult, DEFAULT_ALEPH_API_HOST, DEFAULT_ALEPH_CHANNEL, DEFAULT_COUNTRY_LOOKUP_BASE_URL, DEFAULT_CRN_LIST_URL, DEFAULT_DNS_RESOLVE_URL, DEFAULT_INSTANCE_PORT_FORWARDS, DEFAULT_IPFS_GATEWAY_BASE_URL, DEFAULT_SCHEDULER_ALLOCATION_URL, DEFAULT_TWO_N_SIX_HASH_URL, type FetchLike, type FetchLikeResponse, type HttpProbeResult, ITEM_HASH_RE, type JsonFetchLike$1 as JsonFetchLike, type JsonFetchLikeResponse, type OwnerRelayBootstrapReconcileResult, type PaymentQuote, type RelayBootstrapPublicationResult, type RelayBootstrapVisibilityResult, type RelayMetadataShape, type RetentionRecord, SSH_PUBLIC_KEY_PATTERN, SUCCESSFUL_DEPLOYMENTS_AGGREGATE_KEY, type TcpProbeResult, type TierSpec, VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY, VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS, VM_BOOTSTRAP_CONFIG_SIGNAL_POST_TYPE, VM_BOOTSTRAP_CONFIG_SIGNAL_REF, appendDeploymentTokenToSshPublicKey, broadcastAlephMessage, buildPaymentQuote, cleanupFailedDeployment, configureOrbitdbRelaySetup, configureUcGoPeer, createDeploymentIntent, createDeploymentToken, createInstanceContent, createPortForwardAggregateContent, createRelayBootstrapRegistrationId, createReleaseMetadata, createUnsignedAggregateMessage, createUnsignedForgetMessage, createUnsignedInstanceMessage, createVmBootstrapConfigAggregateContent, deleteVmBootstrapConfig, deployInstance, describeRejectedDeployment, describeRuntimeAvailability, enrichCrnsWithGeo, ensureInstancePortForwards, eraseInstanceOnCrn, extractInsufficientBalanceMessage, extractProxyUrl, extractReferenceHashes, fetch2n6WebAccessUrl, fetchAggregateKey, fetchCrnExecutionMap, fetchCrns, fetchMessageEnvelope, fetchPortForwardAggregate, fetchRelayMetadataForRuntime, fetchSchedulerAllocation, fetchUcGoPeerMetadata, fetchVmBootstrapConfigAggregate, fetchVmBootstrapConfigSignals, fetchVmRuntime, filterDeployableCrns, findCrnByHash, forgetAlephMessages, inspectDeploymentResult, inspectMessageResult, isInvalidMessageFormatResponse, isRetryableBroadcastFailure, isValidSshPublicKey, listGeocodedCrns, listStaleVmBootstrapConfigAggregateMessageHashes, mergePortFlagMaps, mergeRequiredPortForwards, messageTypeFromEnvelope, normalizeBroadcastStatus, normalizeExecution, normalizeExistingPortForwardEntry, normalizeMessageStatus, normalizeProxyUrl, normalizeSshPublicKey, notifyCrnAllocation, notifyCrnAllocationWithRetry, portForwardLabel, postBroadcastPayload, probeRootfsGateway, publishAggregateKey, publishRelayBootstrapRegistration, publishVmBootstrapConfig, quoteRequiredBudgetUnits, rankCandidateCrns, reconcileOwnerRelayBootstrapRegistrations, requestedPortFlags, requiredInstancePortForwards, resolveInstanceCrn, resolveRootfsReference, retainSuccessfulDeployments, selectPreferredCrn, selectedTier, signAlephMessage, signaturePayload, tierSpec, validateRootfsManifest, verifyRootfsExists, verifyUcGoPeerReachability, waitForDeploymentResult, waitForRelayBootstrapRegistration, waitForSetupEndpoint, waitForVmBootstrapConfigSignal, waitForVmRuntime };
