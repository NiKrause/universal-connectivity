import "./chunk-4VNS5WPM.js";

// src/constants.ts
var DEFAULT_ALEPH_CHANNEL = "TEST";

// src/manifests.ts
var ITEM_HASH_RE = /^[a-fA-F0-9]{64}$/;
var DEFAULT_ALEPH_API_HOST = "https://api.aleph.im";
var DEFAULT_IPFS_GATEWAY_BASE_URL = "https://ipfs.aleph.cloud/ipfs/";
function isValidDateString(value) {
  return value.trim().length > 0 && !Number.isNaN(new Date(value).getTime());
}
function validateRootfsManifest(manifest) {
  const errors = [];
  if (!manifest) {
    return { manifest, valid: false, errors: ["Rootfs manifest is missing."] };
  }
  if (!manifest.version || !manifest.version.trim()) {
    errors.push("Rootfs manifest version is missing.");
  }
  if (manifest.rootfsInstallStrategy != null && manifest.rootfsInstallStrategy !== "thin" && manifest.rootfsInstallStrategy !== "prebaked") {
    errors.push('Rootfs install strategy must be "thin" or "prebaked" when provided.');
  }
  if (manifest.requiresBootstrapNetwork != null && typeof manifest.requiresBootstrapNetwork !== "boolean") {
    errors.push("Rootfs bootstrap network flag must be a boolean when provided.");
  }
  if (manifest.bootstrapSummary != null && (typeof manifest.bootstrapSummary !== "string" || !manifest.bootstrapSummary.trim())) {
    errors.push("Rootfs bootstrap summary must be non-empty when provided.");
  }
  if (manifest.requiredPortForwards != null) {
    if (!Array.isArray(manifest.requiredPortForwards)) {
      errors.push("Rootfs required port forwards must be an array when provided.");
    } else {
      manifest.requiredPortForwards.forEach((entry, index) => {
        if (!entry || typeof entry !== "object") {
          errors.push(`Rootfs required port forward #${index + 1} must be an object.`);
          return;
        }
        if (!Number.isInteger(entry.port) || entry.port < 1 || entry.port > 65535) {
          errors.push(`Rootfs required port forward #${index + 1} must use a TCP/UDP port between 1 and 65535.`);
        }
        if (entry.tcp !== true && entry.udp !== true) {
          errors.push(`Rootfs required port forward #${index + 1} must enable TCP or UDP.`);
        }
        if (entry.purpose != null && (typeof entry.purpose !== "string" || !entry.purpose.trim())) {
          errors.push(`Rootfs required port forward #${index + 1} purpose must be non-empty when provided.`);
        }
      });
    }
  }
  if (manifest.rootfsItemHash != null && !ITEM_HASH_RE.test(manifest.rootfsItemHash)) {
    errors.push("Rootfs ItemHash must be a 64 character hex value when provided.");
  }
  if (manifest.rootfsCid != null && (typeof manifest.rootfsCid !== "string" || !manifest.rootfsCid.trim())) {
    errors.push("Rootfs CID must be a non-empty string when provided.");
  }
  if (!Number.isInteger(manifest.rootfsSizeMiB) || manifest.rootfsSizeMiB <= 0) {
    errors.push("Rootfs size must be a positive MiB integer.");
  }
  if (manifest.rootfsSourceSizeBytes != null && (!Number.isInteger(manifest.rootfsSourceSizeBytes) || manifest.rootfsSourceSizeBytes <= 0)) {
    errors.push("Rootfs source size must be a positive byte integer when provided.");
  }
  if (!isValidDateString(manifest.createdAt)) {
    errors.push("Rootfs creation date is missing or invalid.");
  }
  return { manifest, valid: errors.length === 0, errors };
}
function normalizeStatus(status) {
  if (typeof status !== "string") return "unknown";
  const normalized = status.toLowerCase();
  if (normalized === "processed" || normalized === "pending" || normalized === "rejected") {
    return normalized;
  }
  return "unknown";
}
function parseCidFromPayload(payload) {
  const firstMessage = Array.isArray(payload.messages) && payload.messages[0] && typeof payload.messages[0] === "object" ? payload.messages[0] : null;
  const directContent = firstMessage?.content && typeof firstMessage.content === "object" ? firstMessage.content : null;
  if (typeof directContent?.item_hash === "string") {
    return directContent.item_hash;
  }
  if (typeof firstMessage?.item_content === "string") {
    try {
      const itemContent = JSON.parse(firstMessage.item_content);
      if (typeof itemContent.item_hash === "string") {
        return itemContent.item_hash;
      }
    } catch {
      return null;
    }
  }
  return null;
}
function parseRejectionReason(payload) {
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  const rawErrors = Array.isArray(details?.errors) ? details.errors : [];
  const firstError = rawErrors[0] && typeof rawErrors[0] === "object" ? rawErrors[0] : null;
  if (firstError) {
    const accountBalance = Number(firstError.account_balance);
    const requiredBalance = Number(firstError.required_balance);
    if (Number.isFinite(accountBalance) && Number.isFinite(requiredBalance)) {
      const shortfall = requiredBalance - accountBalance;
      return {
        rejectionErrorCode: errorCode,
        rejectionReason: shortfall > 0 ? `Rejected by Aleph for insufficient hold balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required, ${shortfall.toFixed(3)} short.` : `Rejected by Aleph for insufficient hold balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required.`
      };
    }
  }
  return {
    rejectionErrorCode: errorCode,
    rejectionReason: errorCode != null ? `Rejected by Aleph (error code ${errorCode}).` : null
  };
}
async function verifyRootfsExists(itemHash, options) {
  if (!ITEM_HASH_RE.test(itemHash)) return false;
  const apiHost = options.apiHost ?? DEFAULT_ALEPH_API_HOST;
  const response = await options.fetch(`${apiHost}/api/v0/messages/${itemHash}`, {
    method: "GET",
    cache: "no-cache"
  });
  if (response.status === 404) return false;
  if (!response.ok) throw new Error(`Rootfs lookup failed: ${response.status}`);
  const payload = await response.json();
  const firstMessage = Array.isArray(payload.messages) ? payload.messages[0] : void 0;
  const type = String(payload.type || payload.message?.type || firstMessage?.type || "").toUpperCase();
  return type === "STORE";
}
async function probeRootfsGateway(cid, options) {
  const gatewayUrl = new URL(cid, options.gatewayBaseUrl ?? DEFAULT_IPFS_GATEWAY_BASE_URL).toString();
  try {
    const response = await options.fetch(gatewayUrl, { method: "HEAD", cache: "no-store" });
    return {
      gatewayUrl,
      gatewayStatus: response.ok ? "reachable" : "error",
      gatewayError: response.ok ? null : `Gateway responded with ${response.status}.`
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return {
      gatewayUrl,
      gatewayStatus: message.includes("timed out") ? "timeout" : "unavailable",
      gatewayError: message
    };
  }
}
async function resolveRootfsReference(itemHash, options) {
  if (!ITEM_HASH_RE.test(itemHash)) return null;
  const apiHost = options.apiHost ?? DEFAULT_ALEPH_API_HOST;
  const response = await options.fetch(`${apiHost}/api/v0/messages/${itemHash}`, {
    method: "GET",
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Rootfs lookup failed: ${response.status}`);
  const payload = await response.json();
  const firstMessage = Array.isArray(payload.messages) && payload.messages[0] && typeof payload.messages[0] === "object" ? payload.messages[0] : null;
  const messageObject = payload.message && typeof payload.message === "object" ? payload.message : null;
  const cid = parseCidFromPayload(payload);
  const rejection = normalizeStatus(payload.status) === "rejected" ? parseRejectionReason(payload) : { rejectionErrorCode: null, rejectionReason: null };
  const gateway = cid ? await probeRootfsGateway(cid, {
    gatewayBaseUrl: options.gatewayBaseUrl,
    fetch: options.fetch
  }) : { gatewayUrl: null, gatewayStatus: "unknown", gatewayError: null };
  return {
    itemHash,
    messageStatus: normalizeStatus(payload.status),
    messageType: String(payload.type || messageObject?.type || firstMessage?.type || "").toUpperCase() || null,
    cid,
    receptionTime: typeof payload.reception_time === "string" ? payload.reception_time : null,
    rejectionErrorCode: rejection.rejectionErrorCode,
    rejectionReason: rejection.rejectionReason,
    gatewayUrl: gateway.gatewayUrl,
    gatewayStatus: gateway.gatewayStatus,
    gatewayError: gateway.gatewayError
  };
}

// src/crns.ts
var DEFAULT_CRN_LIST_URL = "https://crns-list.aleph.sh/crns.json";
var DEFAULT_COUNTRY_LOOKUP_BASE_URL = "https://api.country.is";
var DEFAULT_DNS_RESOLVE_URL = "https://dns.google/resolve";
function asString(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function normalizeCountryCode(value) {
  const normalized = asString(value)?.toUpperCase() ?? null;
  return normalized && /^[A-Z]{2}$/.test(normalized) ? normalized : null;
}
function lookupHost(address) {
  try {
    return new URL(address ?? "").hostname.trim().toLowerCase();
  } catch {
    return String(address ?? "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/:\d+$/, "");
  }
}
function isIpAddress(host) {
  return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(":");
}
function countryNameFromCode(value) {
  if (!value) return null;
  try {
    const displayNames = new Intl.DisplayNames(["en"], { type: "region" });
    return displayNames.of(value) ?? value;
  } catch {
    return value;
  }
}
function compatibleCrns(crns, excludedHashes = []) {
  const excluded = new Set(excludedHashes.filter(Boolean));
  return [...crns].filter((crn) => {
    if (!crn?.hash || excluded.has(crn.hash)) return false;
    if (crn.qemu_support === false) return false;
    if (crn.system_usage?.active === false) return false;
    return true;
  });
}
function hasCrnCapacity(crn, spec) {
  if (!spec) return true;
  const usage = crn.system_usage;
  if (!usage) return true;
  const cpuOk = usage.cpu?.count == null || usage.cpu.count >= spec.vcpus;
  const memoryOk = usage.mem?.available_kB == null || usage.mem.available_kB >= spec.memoryMiB * 1024;
  const diskOk = usage.disk?.available_kB == null || usage.disk.available_kB >= spec.diskMiB * 1024;
  return cpuOk && memoryOk && diskOk;
}
function scoreSortedCrns(crns) {
  return [...crns].sort((left, right) => {
    const rightScore = typeof right.score === "number" ? right.score : Number(right.score ?? Number.NEGATIVE_INFINITY);
    const leftScore = typeof left.score === "number" ? left.score : Number(left.score ?? Number.NEGATIVE_INFINITY);
    if (rightScore !== leftScore) return rightScore - leftScore;
    const leftName = (left.name || left.address || left.hash).toLowerCase();
    const rightName = (right.name || right.address || right.hash).toLowerCase();
    return leftName.localeCompare(rightName);
  });
}
function filterDeployableCrns(crns, options = {}) {
  return scoreSortedCrns(
    compatibleCrns(crns, options.excludedHashes).filter((crn) => hasCrnCapacity(crn, options.spec))
  );
}
async function resolveHostIp(host, options) {
  if (!host) return null;
  if (isIpAddress(host)) return host;
  for (const type of ["A", "AAAA"]) {
    const url = new URL(options.dnsResolveUrl ?? DEFAULT_DNS_RESOLVE_URL);
    url.searchParams.set("name", host);
    url.searchParams.set("type", type);
    url.searchParams.set("edns_client_subnet", "0.0.0.0/0");
    const response = await options.fetch(url.toString(), {
      cache: "no-cache"
    });
    if (!response.ok) continue;
    const payload = await response.json();
    const record = Array.isArray(payload?.Answer) ? payload.Answer.find((entry) => typeof entry?.data === "string" && entry.data.trim()) : null;
    if (typeof record?.data === "string" && record.data.trim()) {
      return record.data.trim();
    }
  }
  return null;
}
async function lookupIpLocation(ip, options) {
  const url = new URL(`${options.countryLookupBaseUrl ?? DEFAULT_COUNTRY_LOOKUP_BASE_URL}/${encodeURIComponent(ip)}`);
  url.searchParams.set("fields", "city,subdivision");
  const response = await options.fetch(url.toString(), {
    cache: "no-cache"
  });
  if (!response.ok) {
    return {
      resolved_ip: ip,
      city: null,
      region: null,
      country: null,
      country_code: null,
      geo_source: null
    };
  }
  const payload = await response.json();
  const countryCode = normalizeCountryCode(payload?.country);
  return {
    resolved_ip: asString(payload?.ip) ?? ip,
    city: asString(payload?.city),
    region: asString(payload?.subdivision),
    country: countryNameFromCode(countryCode),
    country_code: countryCode,
    geo_source: "country.is"
  };
}
async function fetchCrns(options) {
  const requestUrl = new URL(options.url ?? DEFAULT_CRN_LIST_URL);
  requestUrl.searchParams.set("filter_inactive", "true");
  const response = await options.fetch(requestUrl.toString(), {
    cache: "no-cache"
  });
  if (!response.ok) {
    throw new Error(`CRN list request failed: ${response.status}`);
  }
  const payload = await response.json();
  return Array.isArray(payload?.crns) ? payload.crns : [];
}
async function enrichCrnsWithGeo(crns, options) {
  return Promise.all(
    crns.map(async (crn) => {
      if (crn.city || crn.region || crn.country || crn.country_code) {
        return crn;
      }
      try {
        const host = lookupHost(crn.address);
        const ip = await resolveHostIp(host, {
          fetch: options.fetch,
          dnsResolveUrl: options.dnsResolveUrl
        });
        if (!ip) return crn;
        return {
          ...crn,
          ...await lookupIpLocation(ip, {
            fetch: options.fetch,
            countryLookupBaseUrl: options.countryLookupBaseUrl
          })
        };
      } catch {
        return crn;
      }
    })
  );
}
async function listGeocodedCrns(options) {
  const sortedCrns = filterDeployableCrns(await fetchCrns({
    url: options.url,
    fetch: options.fetch
  }));
  const geocodedCrns = await enrichCrnsWithGeo(
    sortedCrns.slice(0, Math.max(1, Number(options.limit) || 30)),
    options
  );
  return geocodedCrns.filter((crn) => Boolean(crn.city || crn.region || crn.country || crn.country_code)).sort((left, right) => {
    const leftLabel = `${left.country ?? ""}/${left.region ?? ""}/${left.city ?? ""}/${left.name ?? left.hash}`.toLowerCase();
    const rightLabel = `${right.country ?? ""}/${right.region ?? ""}/${right.city ?? ""}/${right.name ?? right.hash}`.toLowerCase();
    return leftLabel.localeCompare(rightLabel);
  });
}
async function rankCandidateCrns(crns, options) {
  const preferredCountryCode = normalizeCountryCode(options.preferredCountryCode);
  const geoLimit = Math.max(1, Number(options.geoLimit) || 30);
  const sortedCrns = filterDeployableCrns(crns, {
    excludedHashes: options.excludedHashes
  });
  if (!preferredCountryCode || sortedCrns.length === 0) {
    return sortedCrns;
  }
  const enrichedTopCrns = await enrichCrnsWithGeo(sortedCrns.slice(0, geoLimit), options);
  const mergedByHash = new Map(enrichedTopCrns.map((crn) => [crn.hash, crn]));
  const mergedCrns = sortedCrns.map((crn) => mergedByHash.get(crn.hash) ?? crn);
  const originalIndex = new Map(mergedCrns.map((crn, index) => [crn.hash, index]));
  return [...mergedCrns].sort((left, right) => {
    const leftPreferred = normalizeCountryCode(left.country_code) === preferredCountryCode ? 1 : 0;
    const rightPreferred = normalizeCountryCode(right.country_code) === preferredCountryCode ? 1 : 0;
    if (leftPreferred !== rightPreferred) {
      return rightPreferred - leftPreferred;
    }
    return (originalIndex.get(left.hash) ?? Number.MAX_SAFE_INTEGER) - (originalIndex.get(right.hash) ?? Number.MAX_SAFE_INTEGER);
  });
}
async function selectPreferredCrn(crns, options) {
  return (await rankCandidateCrns(crns, options))[0] ?? null;
}

// src/port-forwarding.ts
var DEFAULT_INSTANCE_PORT_FORWARDS = [
  { port: 22, tcp: true, udp: false, purpose: "SSH" }
];
function normalizeRequestedPort(entry) {
  return {
    port: entry.port,
    tcp: entry.tcp === true,
    udp: entry.udp === true,
    purpose: entry.purpose?.trim() || void 0
  };
}
function normalizePortFlags(value) {
  if (!value || typeof value !== "object") return null;
  const candidate = value;
  return {
    tcp: candidate.tcp === true,
    udp: candidate.udp === true
  };
}
function normalizeExistingPortForwardEntry(entry) {
  if (!entry?.ports || typeof entry.ports !== "object") return {};
  return Object.fromEntries(
    Object.entries(entry.ports).map(([port, flags]) => [port, normalizePortFlags(flags)]).filter((item) => item[1] != null)
  );
}
function requestedPortFlags(portForwards) {
  return Object.fromEntries(
    portForwards.map((entry) => [
      String(entry.port),
      {
        tcp: entry.tcp === true,
        udp: entry.udp === true
      }
    ])
  );
}
function mergePortFlagMaps(existing, requested) {
  const merged = /* @__PURE__ */ new Map();
  for (const [port, flags] of Object.entries(existing)) {
    merged.set(port, {
      tcp: flags.tcp === true,
      udp: flags.udp === true
    });
  }
  for (const [port, flags] of Object.entries(requested)) {
    const current = merged.get(port);
    merged.set(port, {
      tcp: current?.tcp === true || flags.tcp === true,
      udp: current?.udp === true || flags.udp === true
    });
  }
  return Object.fromEntries([...merged.entries()].sort((left, right) => Number(left[0]) - Number(right[0])));
}
function mergeRequiredPortForwards(...groups) {
  const merged = /* @__PURE__ */ new Map();
  for (const group of groups) {
    for (const entry of group ?? []) {
      const normalized = normalizeRequestedPort(entry);
      const current = merged.get(normalized.port);
      merged.set(normalized.port, {
        port: normalized.port,
        tcp: current?.tcp === true || normalized.tcp === true,
        udp: current?.udp === true || normalized.udp === true,
        purpose: current?.purpose ?? normalized.purpose
      });
    }
  }
  return [...merged.values()].sort((left, right) => left.port - right.port);
}
function requiredInstancePortForwards(manifest) {
  return mergeRequiredPortForwards(DEFAULT_INSTANCE_PORT_FORWARDS, manifest?.requiredPortForwards);
}
function portForwardLabel(entry) {
  const protocols = [entry.tcp === true ? "TCP" : null, entry.udp === true ? "UDP" : null].filter((value) => Boolean(value)).join("/");
  return `${entry.port}/${protocols}`;
}
async function fetchPortForwardAggregate(address, options) {
  const requestUrl = new URL(`/api/v0/aggregates/${address}.json`, options.apiHost ?? DEFAULT_ALEPH_API_HOST);
  requestUrl.searchParams.set("keys", "port-forwarding");
  const response = await options.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (response.status === 404) return {};
  if (!response.ok) {
    throw new Error(`Port-forward aggregate request failed: ${response.status}`);
  }
  const payload = await response.json();
  const aggregate = payload.data?.["port-forwarding"];
  if (!aggregate || typeof aggregate !== "object" || Array.isArray(aggregate)) return {};
  return aggregate;
}

// src/aleph-normalizers.ts
function asString2(value) {
  return typeof value === "string" && value.trim() ? value : null;
}
function asNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function normalizeMessageStatus(status) {
  if (typeof status !== "string") return "unknown";
  const normalized = status.toLowerCase();
  if (normalized === "processed" || normalized === "pending" || normalized === "rejected") {
    return normalized;
  }
  return "unknown";
}
function normalizeProxyUrl(value) {
  const stringValue = asString2(value);
  if (!stringValue) return null;
  if (/^https?:\/\//i.test(stringValue)) return stringValue;
  return `https://${stringValue}`;
}
function messageTypeFromEnvelope(payload) {
  if (!payload) return null;
  const type = payload.type ?? payload.message?.type ?? (Array.isArray(payload.messages) ? payload.messages[0]?.type : void 0);
  return typeof type === "string" ? type.toUpperCase() : null;
}
function extractReferenceHashes(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) return [];
  const errors = details.errors;
  if (!Array.isArray(errors)) return [];
  return errors.filter((value) => typeof value === "string");
}
function extractInsufficientBalanceMessage(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) {
    return null;
  }
  const errors = details.errors;
  const firstError = Array.isArray(errors) && errors[0] && typeof errors[0] === "object" ? errors[0] : null;
  const accountBalance = typeof firstError?.account_balance === "number" || typeof firstError?.account_balance === "string" ? Number(firstError.account_balance) : Number.NaN;
  const requiredBalance = typeof firstError?.required_balance === "number" || typeof firstError?.required_balance === "string" ? Number(firstError.required_balance) : Number.NaN;
  if (!Number.isFinite(accountBalance) || !Number.isFinite(requiredBalance)) {
    return null;
  }
  const shortfall = requiredBalance - accountBalance;
  return shortfall > 0 ? `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required, ${shortfall.toFixed(3)} short` : `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required`;
}
function describeRejectedDeployment(payload, references, rootfsRef) {
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const pendingReferences = references.filter((reference) => reference.status === "pending");
  const missingReferences = references.filter((reference) => reference.status === "missing");
  const rootfsReference = references.find((reference) => reference.itemHash === rootfsRef);
  if (rootfsReference?.status === "pending") {
    return `Aleph rejected this deployment because the referenced rootfs STORE message ${rootfsReference.itemHash} is still pending and cannot yet be used by an instance. Wait for that STORE message to process, then deploy again.`;
  }
  if (pendingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) are still pending: ${pendingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  if (missingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) were not found on Aleph: ${missingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  const insufficientBalanceMessage = extractInsufficientBalanceMessage(payload.details);
  if (insufficientBalanceMessage) {
    return `Aleph rejected this deployment due to ${insufficientBalanceMessage}.`;
  }
  const referencedHashes = extractReferenceHashes(payload.details);
  if (referencedHashes.length > 0) {
    return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}. Referenced message(s): ${referencedHashes.join(", ")}.`;
  }
  return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}.`;
}
function extractProxyUrl(item, networking) {
  const networkingCandidates = [
    networking?.proxy_url,
    networking?.proxyUrl,
    networking?.web_access_url,
    networking?.webAccessUrl,
    networking?.proxy_hostname,
    networking?.proxyHostname,
    networking?.domain,
    networking?.hostname
  ];
  for (const candidate of networkingCandidates) {
    const normalized = normalizeProxyUrl(candidate);
    if (normalized) return normalized;
  }
  const webAccessCandidates = [item.web_access, item.webAccess];
  for (const entry of webAccessCandidates) {
    const normalized = normalizeProxyUrl(entry?.url) ?? normalizeProxyUrl(entry?.proxy_url) ?? normalizeProxyUrl(entry?.hostname) ?? normalizeProxyUrl(entry?.domain);
    if (normalized) return normalized;
  }
  return null;
}
function normalizeExecution(item, crnUrl) {
  const networking = item.networking ?? null;
  const mappedPorts = networking && "mapped_ports" in networking && networking.mapped_ports && typeof networking.mapped_ports === "object" ? Object.fromEntries(
    Object.entries(networking.mapped_ports).map(([port, mapping]) => [
      port,
      {
        host: asNumber(mapping?.host) ?? void 0,
        tcp: typeof mapping?.tcp === "boolean" ? mapping.tcp : void 0,
        udp: typeof mapping?.udp === "boolean" ? mapping.udp : void 0
      }
    ])
  ) : void 0;
  if (networking && ("host_ipv4" in networking || "ipv6_ip" in networking || "ipv4_network" in networking)) {
    const v2Item = item;
    return {
      crnUrl,
      version: "v2",
      running: typeof v2Item.running === "boolean" ? v2Item.running : void 0,
      networking: {
        ipv4_network: asString2(networking.ipv4_network),
        host_ipv4: asString2(networking.host_ipv4),
        ipv6_network: asString2(networking.ipv6_network),
        ipv6_ip: asString2(networking.ipv6_ip),
        ipv4_ip: asString2(networking.ipv4_ip),
        proxy_url: extractProxyUrl(v2Item, networking),
        mapped_ports: mappedPorts
      },
      status: v2Item.status ? {
        defined_at: asString2(v2Item.status.defined_at),
        preparing_at: asString2(v2Item.status.preparing_at),
        prepared_at: asString2(v2Item.status.prepared_at),
        starting_at: asString2(v2Item.status.starting_at),
        started_at: asString2(v2Item.status.started_at),
        stopping_at: asString2(v2Item.status.stopping_at),
        stopped_at: asString2(v2Item.status.stopped_at)
      } : null
    };
  }
  return {
    crnUrl,
    version: "v1",
    networking: {
      ipv4: networking && "ipv4" in networking ? asString2(networking.ipv4) : null,
      ipv6: networking && "ipv6" in networking ? asString2(networking.ipv6) : null
    },
    status: null
  };
}

// src/deployment-inspection.ts
async function fetchMessageEnvelope(itemHash, options) {
  const response = await options.fetch(`${options.apiHost ?? DEFAULT_ALEPH_API_HOST}/api/v0/messages/${itemHash}`, {
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Message lookup failed: ${response.status}`);
  return await response.json();
}
async function inspectMessageResult(itemHash, options) {
  const label = options.label ?? "Message";
  const payload = await fetchMessageEnvelope(itemHash, options);
  if (!payload) {
    return {
      status: "unknown",
      errorCode: null,
      details: null,
      rejectionReason: `${label} ${itemHash} was not found on Aleph.`
    };
  }
  const status = normalizeMessageStatus(payload.status);
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  let rejectionReason = null;
  if (status === "rejected") {
    const balanceMessage = extractInsufficientBalanceMessage(details);
    rejectionReason = balanceMessage ? `${label} ${itemHash} was rejected by Aleph due to ${balanceMessage}.` : `${label} ${itemHash} was rejected by Aleph${errorCode ? ` (error ${errorCode})` : ""}.`;
  }
  return {
    status,
    errorCode,
    details,
    rejectionReason
  };
}
async function fetchReference(itemHash, options) {
  const payload = await fetchMessageEnvelope(itemHash, options);
  if (!payload) {
    return {
      itemHash,
      status: "missing",
      type: null
    };
  }
  return {
    itemHash,
    status: normalizeMessageStatus(payload.status),
    type: messageTypeFromEnvelope(payload)
  };
}
async function inspectDeploymentResult(itemHash, options) {
  const payload = await fetchMessageEnvelope(itemHash, options);
  if (!payload) {
    return {
      status: "unknown",
      errorCode: null,
      details: null,
      rejectionReason: `Deployment message ${itemHash} was not found on Aleph.`,
      references: []
    };
  }
  const relatedHashes = new Set(options.rootfsRef ? [options.rootfsRef] : []);
  for (const referenceHash of extractReferenceHashes(payload.details)) {
    relatedHashes.add(referenceHash);
  }
  const references = await Promise.all(
    Array.from(relatedHashes).map((hash) => fetchReference(hash, options))
  );
  const status = normalizeMessageStatus(payload.status);
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  return {
    status,
    errorCode,
    details,
    rejectionReason: status === "rejected" ? describeRejectedDeployment(payload, references, options.rootfsRef) : null,
    references
  };
}
async function waitForDeploymentResult(itemHash, options) {
  const attempts = Math.max(1, Number(options.attempts ?? 15));
  const delayMs = Math.max(0, Number(options.delayMs ?? 2e3));
  const sleep2 = options.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastResult = await inspectDeploymentResult(itemHash, options);
  options.onAttempt?.(lastResult, 1, attempts);
  for (let attempt = 1; attempt < attempts; attempt += 1) {
    if (lastResult.status === "processed" || lastResult.status === "rejected") {
      return lastResult;
    }
    await sleep2(delayMs);
    lastResult = await inspectDeploymentResult(itemHash, options);
    options.onAttempt?.(lastResult, attempt + 1, attempts);
  }
  return lastResult;
}

// src/broadcast.ts
function signaturePayload(message) {
  return [message.chain, message.sender, message.type, message.item_hash].join("\n");
}
async function signAlephMessage(unsignedMessage, signer) {
  const signature = await signer(unsignedMessage.sender, signaturePayload(unsignedMessage));
  return {
    ...unsignedMessage,
    signature: signature.startsWith("0x") ? signature : `0x${signature}`
  };
}
function normalizeBroadcastStatus(httpStatus, responseStatus) {
  if (httpStatus === 202) return "pending";
  return normalizeMessageStatus(responseStatus);
}
function isInvalidMessageFormatResponse(response, payload) {
  if (response.status !== 422) return false;
  const details = payload?.details;
  if (typeof details === "string" && details.includes("InvalidMessageFormat")) return true;
  if (details && typeof details === "object") {
    const detailMessage = details.message;
    if (typeof detailMessage === "string" && detailMessage.includes("InvalidMessageFormat")) return true;
  }
  return false;
}
function isRetryableBroadcastFailure(response, payload) {
  if (response.status >= 500) return true;
  const publicationStatus = payload?.publication_status?.status;
  if (typeof publicationStatus === "string" && publicationStatus.toLowerCase() === "error") {
    return true;
  }
  return false;
}
async function postBroadcastPayload(body, options) {
  const rawResponse = await options.fetch(`${options.apiHost ?? DEFAULT_ALEPH_API_HOST}/api/v0/messages`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  const response = await rawResponse.json().catch(() => ({}));
  return {
    response,
    httpStatus: rawResponse.status
  };
}
async function broadcastAlephMessage(message, options) {
  const requestBody = { sync: options.sync ?? false, message };
  const maxAttempts = 3;
  for (let index = 0; index < maxAttempts; index += 1) {
    const result = await postBroadcastPayload(requestBody, {
      apiHost: options.apiHost,
      fetch: options.fetch
    });
    if (result.httpStatus === 202 || normalizeBroadcastStatus(result.httpStatus, result.response?.message_status) !== "unknown" || result.httpStatus >= 200 && result.httpStatus < 300) {
      return result;
    }
    const canRetry = index < maxAttempts - 1 && isRetryableBroadcastFailure({ status: result.httpStatus }, result.response);
    if (!canRetry) {
      throw new Error(`Broadcast failed: ${result.httpStatus} ${JSON.stringify(result.response ?? {})}`);
    }
  }
  throw new Error("Broadcast failed: retry budget exhausted");
}

// src/runtime.ts
var DEFAULT_SCHEDULER_ALLOCATION_URL = "https://scheduler.api.aleph.cloud/api/v0/allocation";
var DEFAULT_TWO_N_SIX_HASH_URL = "https://api.2n6.me/api/hash";
function asString3(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function asNumber2(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function normalizeIpv6(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  if (!normalized) return null;
  const zoneIndex = normalized.indexOf("%");
  return zoneIndex >= 0 ? normalized.slice(0, zoneIndex) : normalized;
}
function isLikelyGlobalIpv6(value) {
  const normalized = normalizeIpv6(value);
  if (!normalized || normalized === "::" || normalized === "::1") return false;
  const firstHextetText = normalized.split(":", 1)[0];
  if (!firstHextetText) return false;
  const firstHextet = Number.parseInt(firstHextetText, 16);
  if (!Number.isFinite(firstHextet)) return false;
  if ((firstHextet & 65024) === 64512) return false;
  if ((firstHextet & 65472) === 65152) return false;
  if ((firstHextet & 65280) === 65280) return false;
  if ((firstHextet & 65472) === 65216) return false;
  return true;
}
function findCrnByHash(crns, crnHash) {
  return crns.find((crn) => crn.hash === crnHash) ?? null;
}
async function fetchSchedulerAllocation(itemHash, options) {
  const response = await options.fetch(
    `${options.schedulerAllocationUrl ?? DEFAULT_SCHEDULER_ALLOCATION_URL}/${itemHash}`,
    { cache: "no-cache" }
  );
  if (response.status === 404) return null;
  if (!response.ok) {
    throw new Error(`Scheduler allocation request failed: ${response.status}`);
  }
  const payload = await response.json();
  const node = payload?.node;
  return {
    source: "scheduler",
    crnHash: asString3(node?.node_id),
    crnUrl: asString3(node?.url),
    node: node ? {
      node_id: asString3(node.node_id) ?? void 0,
      url: asString3(node.url) ?? void 0,
      ipv6: asString3(node.ipv6),
      supports_ipv6: typeof node.supports_ipv6 === "boolean" ? node.supports_ipv6 : void 0
    } : null,
    vmIpv6: asString3(payload?.vm_ipv6),
    period: payload?.period ? {
      start_timestamp: asString3(payload.period.start_timestamp) ?? void 0,
      duration_seconds: asNumber2(payload.period.duration_seconds) ?? void 0
    } : null
  };
}
async function fetch2n6WebAccessUrl(itemHash, options) {
  const response = await options.fetch(
    `${options.twoN6HashUrl ?? DEFAULT_TWO_N_SIX_HASH_URL}/${itemHash}`,
    { cache: "no-cache" }
  );
  if (!response.ok) return null;
  const payload = await response.json();
  return {
    url: normalizeProxyUrl(payload?.url ?? payload?.subdomain),
    active: typeof payload?.active === "boolean" ? payload.active : null,
    subdomain: asString3(payload?.subdomain)
  };
}
async function fetchCrnExecutionMap(crnUrl, options) {
  const normalizedCrnUrl = String(crnUrl).replace(/\/+$/, "");
  for (const [version, suffix] of [
    ["v2", "/v2/about/executions/list"],
    ["v1", "/about/executions/list"]
  ]) {
    const requestUrl = `${normalizedCrnUrl}${suffix}`;
    const response = await options.fetch(requestUrl, {
      cache: "no-cache"
    });
    if (response.ok) {
      const payload = await response.json();
      return {
        version,
        payload: payload && typeof payload === "object" ? payload : null,
        requestUrl
      };
    }
    if (response.status !== 404) {
      return {
        version,
        payload: null,
        requestUrl
      };
    }
  }
  return {
    version: "v2",
    payload: null,
    requestUrl: `${normalizedCrnUrl}/v2/about/executions/list`
  };
}
function describeRuntimeAvailability(runtime) {
  const execution = runtime.execution ?? null;
  const mappedPorts = runtime.mappedPorts ?? {};
  const hostIpv4 = runtime.hostIpv4 ?? null;
  const ipv6 = runtime.ipv6 ?? null;
  const executionGuestIpv6 = execution?.networking?.ipv6_ip ?? null;
  const proxyUrl = runtime.proxyUrl ?? null;
  const schedulerSource = runtime.allocation?.source ?? null;
  const webAccessActive = runtime.webAccess?.active ?? null;
  const mappedPortCount = Object.keys(mappedPorts).length;
  if (hostIpv4 && mappedPortCount > 0 && runtime.requirePublicGuestIpv6ForProxy === true && proxyUrl && executionGuestIpv6 && !isLikelyGlobalIpv6(executionGuestIpv6)) {
    return {
      state: "execution-invalid-public-ipv6",
      reason: `The CRN exposed runtime networking, but the guest IPv6 (${executionGuestIpv6}) is not globally routable. Proxy-backed HTTPS activation cannot succeed until the CRN reports a public guest IPv6.`,
      schedulerSource,
      executionSeen: Boolean(execution),
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (hostIpv4 && mappedPortCount > 0) {
    return {
      state: "ready",
      reason: null,
      schedulerSource,
      executionSeen: Boolean(execution),
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (!execution && proxyUrl && webAccessActive === false) {
    return {
      state: "proxy-reserved-inactive",
      reason: "Aleph reserved a proxy URL for the VM, but it is still inactive and the selected CRN has not exposed execution networking yet.",
      schedulerSource,
      executionSeen: false,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (!execution && schedulerSource === "manual") {
    return {
      state: "crn-execution-missing",
      reason: "The deployment is pinned to a specific CRN, but that CRN is not exposing this VM in its execution list yet.",
      schedulerSource,
      executionSeen: false,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (execution && !hostIpv4) {
    return {
      state: "execution-missing-host-ipv4",
      reason: "The CRN exposed an execution record, but it does not include a public host IPv4 yet.",
      schedulerSource,
      executionSeen: true,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (execution && mappedPortCount === 0) {
    return {
      state: "execution-missing-port-mappings",
      reason: "The CRN exposed an execution record, but mapped ports are still empty.",
      schedulerSource,
      executionSeen: true,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  return {
    state: "runtime-pending",
    reason: "Aleph has not exposed enough runtime networking details yet.",
    schedulerSource,
    executionSeen: Boolean(execution),
    webAccessActive,
    mappedPortCount,
    proxyUrl
  };
}
async function fetchVmRuntime(args) {
  const crns = args.crns ?? await fetchCrns({
    url: args.crnListUrl ?? DEFAULT_CRN_LIST_URL,
    fetch: args.fetch
  });
  const schedulerAllocation = await fetchSchedulerAllocation(args.itemHash, {
    fetch: args.fetch,
    schedulerAllocationUrl: args.schedulerAllocationUrl
  }).catch(() => null);
  const selectedCrn = args.crnHash ? findCrnByHash(crns, args.crnHash) : null;
  const allocation = schedulerAllocation ?? (selectedCrn ? {
    source: "manual",
    crnHash: selectedCrn.hash,
    crnUrl: selectedCrn.address,
    node: { url: selectedCrn.address },
    vmIpv6: null,
    period: null
  } : null);
  const webAccess = await fetch2n6WebAccessUrl(args.itemHash, {
    fetch: args.fetch,
    twoN6HashUrl: args.twoN6HashUrl
  }).catch(() => null);
  const webAccessUrl = webAccess?.url ?? null;
  let execution = null;
  let executionLookupBlocked = false;
  if (allocation?.crnUrl) {
    const executionLookup = await fetchCrnExecutionMap(allocation.crnUrl, {
      fetch: args.fetch
    });
    const executionPayload = executionLookup.payload?.[args.itemHash];
    if (executionPayload && typeof executionPayload === "object") {
      execution = normalizeExecution(executionPayload, allocation.crnUrl);
      if (!execution.networking.proxy_url && webAccessUrl) {
        execution.networking.proxy_url = webAccessUrl;
      }
    } else if (executionLookup.payload == null) {
      executionLookupBlocked = true;
    }
  }
  const hostIpv4 = execution?.networking?.host_ipv4 ?? execution?.networking?.ipv4 ?? null;
  const ipv6 = execution?.networking?.ipv6_ip ?? execution?.networking?.ipv6 ?? allocation?.vmIpv6 ?? null;
  const mappedPorts = execution?.networking?.mapped_ports ?? {};
  const sshPort = mappedPorts?.["22"]?.host ?? null;
  const proxyUrl = execution?.networking?.proxy_url ?? webAccessUrl ?? null;
  const diagnostics = describeRuntimeAvailability({
    allocation,
    execution,
    webAccess,
    hostIpv4,
    ipv6,
    proxyUrl,
    mappedPorts,
    requirePublicGuestIpv6ForProxy: args.requirePublicGuestIpv6ForProxy
  });
  return {
    allocation,
    execution,
    webAccess,
    webAccessUrl,
    hostIpv4,
    ipv6,
    proxyUrl,
    mappedPorts,
    diagnostics,
    sshCommand: hostIpv4 && sshPort ? `ssh root@${hostIpv4} -p ${sshPort}` : ipv6 ? `ssh root@${ipv6}` : null,
    selectedCrn,
    executionLookupBlocked
  };
}
async function waitForVmRuntime(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 20));
  const delayMs = Math.max(0, Number(args.delayMs ?? 4e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastRuntime = await fetchVmRuntime(args);
  args.onAttempt?.(lastRuntime, 1, attempts);
  for (let attempt = 0; attempt < attempts - 1; attempt += 1) {
    if (lastRuntime.diagnostics?.state === "ready" || lastRuntime.diagnostics?.state === "execution-invalid-public-ipv6") {
      return lastRuntime;
    }
    await sleep2(delayMs);
    lastRuntime = await fetchVmRuntime(args);
    args.onAttempt?.(lastRuntime, attempt + 2, attempts);
  }
  if (lastRuntime.diagnostics) {
    lastRuntime.diagnostics.timedOut = true;
  }
  return lastRuntime;
}

// src/crn-control.ts
function bytesToHex(bytes) {
  return Array.from(bytes).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function utf8Hex(value) {
  return bytesToHex(new TextEncoder().encode(value));
}
function normalizeHexSignature(signature) {
  return signature.startsWith("0x") ? signature : `0x${signature}`;
}
function asString4(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function trimTrailingSlashes(value) {
  return value.replace(/\/+$/u, "");
}
function isoTimestampWithMicros(date = /* @__PURE__ */ new Date()) {
  return date.toISOString().replace(/\.(\d{3})Z$/u, ".$1000Z");
}
async function generateEphemeralKeyPair() {
  return globalThis.crypto.subtle.generateKey(
    {
      name: "ECDSA",
      namedCurve: "P-256"
    },
    true,
    ["sign", "verify"]
  );
}
async function exportP256PublicJwk(publicKey) {
  const jwk = await globalThis.crypto.subtle.exportKey("jwk", publicKey);
  return {
    kty: String(jwk.kty ?? "EC"),
    crv: String(jwk.crv ?? "P-256"),
    x: String(jwk.x ?? ""),
    y: String(jwk.y ?? "")
  };
}
async function buildSignedPubKeyHeader(args) {
  const payload = {
    pubkey: await exportP256PublicJwk(args.publicKey),
    alg: "ECDSA",
    domain: args.domain,
    address: args.sender,
    expires: isoTimestampWithMicros(new Date(Date.now() + 24 * 60 * 60 * 1e3)),
    chain: "ETH"
  };
  const payloadJson = JSON.stringify(payload);
  const signature = normalizeHexSignature(await args.signer(args.sender, payloadJson));
  return JSON.stringify({
    sender: args.sender,
    payload: utf8Hex(payloadJson),
    signature,
    content: {
      domain: args.domain
    }
  });
}
async function buildSignedOperationHeader(args) {
  const payload = {
    time: isoTimestampWithMicros(),
    method: args.method,
    path: args.path,
    domain: args.domain
  };
  const payloadJson = JSON.stringify(payload);
  const signature = new Uint8Array(
    await globalThis.crypto.subtle.sign(
      {
        name: "ECDSA",
        hash: "SHA-256"
      },
      args.privateKey,
      new TextEncoder().encode(payloadJson)
    )
  );
  return JSON.stringify({
    payload: utf8Hex(payloadJson),
    signature: bytesToHex(signature)
  });
}
async function fetchInstanceNodeHash(args) {
  const envelope = await fetchMessageEnvelope(args.instanceHash, {
    fetch: args.fetch,
    apiHost: args.apiHost
  });
  const payload = envelope;
  return asString4(payload?.content?.requirements?.node?.node_hash) ?? asString4(payload?.message?.content?.requirements?.node?.node_hash) ?? null;
}
async function resolveInstanceCrn(args) {
  const providedCrnUrl = asString4(args.crnUrl);
  if (providedCrnUrl) {
    return {
      crnUrl: trimTrailingSlashes(providedCrnUrl),
      crnHash: asString4(args.crnHash),
      source: "provided"
    };
  }
  const allocation = await fetchSchedulerAllocation(args.instanceHash, {
    fetch: args.fetch,
    schedulerAllocationUrl: args.schedulerAllocationUrl ?? DEFAULT_SCHEDULER_ALLOCATION_URL
  }).catch(() => null);
  if (allocation?.crnUrl) {
    return {
      crnUrl: trimTrailingSlashes(allocation.crnUrl),
      crnHash: asString4(allocation.crnHash),
      source: "scheduler"
    };
  }
  const manualCrnHash = asString4(args.crnHash) ?? await fetchInstanceNodeHash({
    instanceHash: args.instanceHash,
    fetch: args.fetch,
    apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST
  }).catch(() => null);
  if (manualCrnHash) {
    const crns = await fetchCrns({
      url: args.crnListUrl ?? DEFAULT_CRN_LIST_URL,
      fetch: args.fetch
    }).catch(() => []);
    const matchingCrn = crns.find((candidate) => candidate.hash === manualCrnHash);
    if (matchingCrn?.address) {
      return {
        crnUrl: trimTrailingSlashes(matchingCrn.address),
        crnHash: manualCrnHash,
        source: "manual"
      };
    }
  }
  return {
    crnUrl: null,
    crnHash: manualCrnHash,
    source: "missing"
  };
}
async function eraseInstanceOnCrn(args) {
  const resolution = await resolveInstanceCrn({
    instanceHash: args.instanceHash,
    fetch: args.fetch,
    apiHost: args.apiHost,
    crnUrl: args.crnUrl,
    crnHash: args.crnHash,
    crnListUrl: args.crnListUrl,
    schedulerAllocationUrl: args.schedulerAllocationUrl
  });
  if (!resolution.crnUrl) {
    return {
      ...resolution,
      status: "skipped"
    };
  }
  const crnUrl = new URL(resolution.crnUrl);
  const domain = crnUrl.host;
  const path = `/control/machine/${args.instanceHash}/erase`;
  const { privateKey, publicKey } = await generateEphemeralKeyPair();
  const signedPubKeyHeader = await buildSignedPubKeyHeader({
    sender: args.sender,
    signer: args.signer,
    domain,
    publicKey
  });
  const signedOperationHeader = await buildSignedOperationHeader({
    privateKey,
    domain,
    method: "POST",
    path
  });
  const response = await args.fetch(`${trimTrailingSlashes(resolution.crnUrl)}${path}`, {
    method: "POST",
    headers: {
      "X-SignedPubKey": signedPubKeyHeader,
      "X-SignedOperation": signedOperationHeader
    }
  });
  if (response.status === 404) {
    return {
      ...resolution,
      status: "missing"
    };
  }
  if (response.ok) {
    return {
      ...resolution,
      status: "erased"
    };
  }
  const errorBody = await response.json().then((payload) => JSON.stringify(payload)).catch(() => "");
  throw new Error(
    `CRN erase failed for ${args.instanceHash} on ${resolution.crnUrl}: ${response.status}${errorBody ? ` ${errorBody}` : ""}`
  );
}

// src/forget.ts
function asOptionalReason(value) {
  return typeof value === "string" && value.trim() ? value.trim() : void 0;
}
async function createUnsignedForgetMessage(args) {
  const content = {
    address: args.sender,
    time: args.now ?? Date.now() / 1e3,
    hashes: [...new Set((args.hashes ?? []).filter(Boolean))],
    aggregates: [...new Set((args.aggregates ?? []).filter(Boolean))],
    reason: asOptionalReason(args.reason)
  };
  if (content.hashes.length === 0 && content.aggregates.length === 0) {
    throw new Error("FORGET message requires at least one hash or aggregate key.");
  }
  const itemContent = JSON.stringify(content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "FORGET",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function forgetAlephMessages(args) {
  args.onProgress?.({
    stage: "building-delete-message",
    label: "Building delete message",
    progress: 18,
    status: "info",
    itemHash: null,
    detail: [...new Set((args.hashes ?? []).filter(Boolean))].join(", ") || null,
    error: null,
    timestamp: Date.now()
  });
  const unsignedMessage = await createUnsignedForgetMessage({
    sender: args.sender,
    hashes: args.hashes,
    aggregates: args.aggregates,
    reason: args.reason,
    hasher: args.hasher,
    channel: args.channel,
    now: args.now
  });
  args.onProgress?.({
    stage: "signing-delete-message",
    label: "Waiting for delete signature",
    progress: 42,
    status: "info",
    itemHash: unsignedMessage.item_hash,
    detail: unsignedMessage.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const message = await signAlephMessage(unsignedMessage, args.signer);
  args.onProgress?.({
    stage: "broadcasting-delete",
    label: "Broadcasting delete to Aleph",
    progress: 68,
    status: "warning",
    itemHash: message.item_hash,
    detail: message.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const { response, httpStatus } = await broadcastAlephMessage(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const status = normalizeBroadcastStatus(httpStatus, response?.message_status);
  args.onProgress?.({
    stage: status === "rejected" ? "error" : "delete-completed",
    label: status === "rejected" ? "Delete rejected by Aleph" : "Delete submitted to Aleph",
    progress: 100,
    status: status === "rejected" ? "error" : "success",
    itemHash: message.item_hash,
    detail: status === "rejected" ? String(response?.details ?? "Aleph rejected this delete request.") : null,
    error: status === "rejected" ? String(response?.details ?? "Aleph rejected this delete request.") : null,
    timestamp: Date.now()
  });
  return {
    sender: args.sender,
    itemHash: message.item_hash,
    response,
    httpStatus,
    status
  };
}
async function cleanupFailedDeployment(args) {
  try {
    return await forgetAlephMessages({
      sender: args.sender,
      hashes: [args.instanceItemHash],
      reason: args.reason ?? "Discard failed deployment attempt",
      signer: args.signer,
      hasher: args.hasher,
      fetch: args.fetch,
      channel: args.channel,
      apiHost: args.apiHost
    });
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : String(error)
    };
  }
}

// src/retention.ts
var SUCCESSFUL_DEPLOYMENTS_AGGREGATE_KEY = "uc-go-peer-successful-deployments";
function asString5(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function normalizeRetentionRecord(record) {
  if (!record || typeof record !== "object" || Array.isArray(record)) return null;
  const candidate = record;
  const instanceItemHash = asString5(candidate.instance_item_hash);
  if (!instanceItemHash) return null;
  return {
    instance_item_hash: instanceItemHash,
    rootfs_item_hash: asString5(candidate.rootfs_item_hash) ?? "",
    site_item_hash: asString5(candidate.site_item_hash) ?? "",
    rootfs_cid: asString5(candidate.rootfs_cid) ?? "",
    site_url: asString5(candidate.site_url) ?? "",
    relay_peer_id: asString5(candidate.relay_peer_id) ?? "",
    rootfs_version: asString5(candidate.rootfs_version) ?? "",
    deployed_at: asString5(candidate.deployed_at) ?? (/* @__PURE__ */ new Date()).toISOString(),
    vm_name: asString5(candidate.vm_name) ?? ""
  };
}
function normalizeRetentionLedger(value) {
  if (Array.isArray(value)) {
    return value.map(normalizeRetentionRecord).filter((entry) => entry != null);
  }
  if (value && typeof value === "object" && Array.isArray(value.deployments)) {
    return value.deployments.map(normalizeRetentionRecord).filter((entry) => entry != null);
  }
  return [];
}
function retentionRecordId(record) {
  return [record.instance_item_hash, record.rootfs_item_hash, record.site_item_hash].join(":");
}
function hashesFromRetentionRecord(record) {
  return [record.instance_item_hash, record.rootfs_item_hash, record.site_item_hash].filter(Boolean);
}
function uniqueHashes(hashes) {
  return [...new Set(hashes.filter(Boolean))];
}
function dependentHashesFromRetentionRecord(record) {
  return [record.rootfs_item_hash, record.site_item_hash].filter(Boolean);
}
function splitForgetStages(args) {
  const instanceForgetHashes = uniqueHashes(args.prunedRecords.map((record) => record.instance_item_hash)).filter(
    (hash) => !args.retainedHashes.has(hash)
  );
  const dependentForgetHashes = uniqueHashes([
    ...args.prunedRecords.flatMap(dependentHashesFromRetentionRecord),
    ...args.extraForgetHashes
  ]).filter((hash) => !args.retainedHashes.has(hash) && !instanceForgetHashes.includes(hash));
  return {
    instanceForgetHashes,
    dependentForgetHashes,
    orderedForgetHashes: [...instanceForgetHashes, ...dependentForgetHashes]
  };
}
async function fetchAggregateKey(args) {
  const requestUrl = new URL(`/api/v0/aggregates/${args.address}.json`, args.apiHost ?? "https://api.aleph.im");
  requestUrl.searchParams.set("keys", args.key);
  const response = await args.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (response.status === 404) return {};
  if (!response.ok) {
    throw new Error(`Aggregate request failed for key ${args.key}: ${response.status}`);
  }
  const payload = await response.json();
  return payload?.data?.[args.key] ?? {};
}
async function createUnsignedAggregateMessage(args) {
  const itemContent = JSON.stringify(args.content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "AGGREGATE",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function publishAggregateKey(args) {
  const aggregateContent = {
    address: args.sender,
    key: args.key,
    content: args.content,
    time: args.now ?? Date.now() / 1e3
  };
  const unsignedMessage = await createUnsignedAggregateMessage({
    sender: args.sender,
    content: aggregateContent,
    hasher: args.hasher,
    channel: args.channel,
    now: args.now
  });
  const message = await signAlephMessage(unsignedMessage, args.signer);
  const { response, httpStatus } = await broadcastAlephMessage(message, {
    apiHost: args.apiHost,
    sync: true,
    fetch: args.fetch
  });
  return {
    itemHash: message.item_hash,
    status: normalizeBroadcastStatus(httpStatus, response?.message_status),
    response,
    httpStatus
  };
}
async function fetchMessageStatus(args) {
  const requestUrl = new URL(`/api/v0/messages/${args.hash}`, args.apiHost ?? "https://api.aleph.im");
  const response = await args.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (response.status === 404) return "missing";
  if (!response.ok) return "unknown";
  const payload = await response.json();
  return asString5(payload?.status) ?? "unknown";
}
async function classifyForgetHashes(args) {
  const statuses = {};
  for (const hash of args.hashes) {
    statuses[hash] = await fetchMessageStatus({
      hash,
      fetch: args.fetch,
      apiHost: args.apiHost
    });
  }
  const forgottenHashes = args.hashes.filter((hash) => statuses[hash] === "forgotten");
  const outstandingForgetHashes = args.hashes.filter((hash) => statuses[hash] !== "forgotten");
  return {
    forgottenHashes,
    outstandingForgetHashes,
    statuses
  };
}
async function executeForgetStage(args) {
  const stageHashes = uniqueHashes(args.hashes);
  let forgetResult = null;
  const followUpForgetResults = [];
  if (stageHashes.length === 0) {
    return {
      hashes: stageHashes,
      forgottenHashes: [],
      outstandingForgetHashes: [],
      statuses: {},
      forgetResult,
      followUpForgetResults
    };
  }
  let classified = await classifyForgetHashes({
    hashes: stageHashes,
    fetch: args.fetch,
    apiHost: args.apiHost
  });
  if (classified.outstandingForgetHashes.length > 0) {
    forgetResult = await forgetAlephMessages({
      sender: args.sender,
      hashes: classified.outstandingForgetHashes,
      reason: args.reason,
      signer: args.signer,
      hasher: args.hasher,
      fetch: args.fetch,
      channel: args.channel,
      apiHost: args.apiHost,
      now: args.now
    });
    classified = await classifyForgetHashes({
      hashes: stageHashes,
      fetch: args.fetch,
      apiHost: args.apiHost
    });
    if (classified.outstandingForgetHashes.length > 0) {
      for (const hash of classified.outstandingForgetHashes) {
        const result = await forgetAlephMessages({
          sender: args.sender,
          hashes: [hash],
          reason: args.reason,
          signer: args.signer,
          hasher: args.hasher,
          fetch: args.fetch,
          channel: args.channel,
          apiHost: args.apiHost,
          now: args.now
        });
        followUpForgetResults.push({ hash, result });
      }
      classified = await classifyForgetHashes({
        hashes: stageHashes,
        fetch: args.fetch,
        apiHost: args.apiHost
      });
    }
  }
  return {
    hashes: stageHashes,
    forgottenHashes: classified.forgottenHashes,
    outstandingForgetHashes: classified.outstandingForgetHashes,
    statuses: classified.statuses,
    forgetResult,
    followUpForgetResults
  };
}
async function retainSuccessfulDeployments(args) {
  const keepCount = Math.max(0, Number.parseInt(String(args.keepCount ?? 0), 10) || 0);
  const aggregateKey = asString5(args.aggregateKey) ?? SUCCESSFUL_DEPLOYMENTS_AGGREGATE_KEY;
  const currentRecord = normalizeRetentionRecord(args.currentRecord);
  if (!currentRecord) {
    throw new Error("retainSuccessfulDeployments requires a current deployment record with instance_item_hash.");
  }
  const existingValue = await fetchAggregateKey({
    address: args.sender,
    key: aggregateKey,
    fetch: args.fetch,
    apiHost: args.apiHost
  });
  const existingRecords = normalizeRetentionLedger(existingValue);
  const mergedRecords = [currentRecord, ...existingRecords];
  const uniqueRecords = [];
  const seenIds = /* @__PURE__ */ new Set();
  for (const record of mergedRecords) {
    const id = retentionRecordId(record);
    if (seenIds.has(id)) continue;
    seenIds.add(id);
    uniqueRecords.push(record);
  }
  const retainedRecords = keepCount > 0 ? uniqueRecords.slice(0, keepCount) : [];
  const prunedRecords = keepCount > 0 ? uniqueRecords.slice(keepCount) : uniqueRecords;
  const retainedHashes = new Set(retainedRecords.flatMap(hashesFromRetentionRecord));
  const extraForgetHashes = uniqueHashes(args.extraForgetHashes ?? []);
  const { instanceForgetHashes, dependentForgetHashes, orderedForgetHashes } = splitForgetStages({
    prunedRecords,
    extraForgetHashes,
    retainedHashes
  });
  const forgetHashes = orderedForgetHashes;
  const aggregateContent = {
    keep: keepCount,
    updated_at: (/* @__PURE__ */ new Date()).toISOString(),
    deployments: retainedRecords
  };
  const aggregatePublication = await publishAggregateKey({
    sender: args.sender,
    key: aggregateKey,
    content: aggregateContent,
    signer: args.signer,
    hasher: args.hasher,
    fetch: args.fetch,
    channel: args.channel,
    apiHost: args.apiHost,
    now: args.now
  });
  const forgetReason = args.reason ?? `Prune successful deployments beyond retention limit ${keepCount}`;
  const forgetStageResults = [];
  let forgottenHashes = [];
  let outstandingForgetHashes = [];
  let forgetStatuses = {};
  let forgetResult = null;
  const followUpForgetResults = [];
  if (instanceForgetHashes.length > 0) {
    const eraseResults = await Promise.all(
      instanceForgetHashes.map(async (hash) => ({
        hash,
        ...await eraseInstanceOnCrn({
          sender: args.sender,
          signer: args.signer,
          instanceHash: hash,
          fetch: args.fetch,
          apiHost: args.apiHost,
          crnListUrl: args.crnListUrl,
          schedulerAllocationUrl: args.schedulerAllocationUrl
        })
      }))
    );
    const instanceStage = await executeForgetStage({
      sender: args.sender,
      hashes: instanceForgetHashes,
      reason: forgetReason,
      signer: args.signer,
      hasher: args.hasher,
      fetch: args.fetch,
      channel: args.channel,
      apiHost: args.apiHost,
      now: args.now
    });
    forgetStageResults.push({ stage: "instances", eraseResults, ...instanceStage });
    forgottenHashes.push(...instanceStage.forgottenHashes);
    outstandingForgetHashes.push(...instanceStage.outstandingForgetHashes);
    forgetStatuses = { ...forgetStatuses, ...instanceStage.statuses };
    if (!forgetResult && instanceStage.forgetResult) {
      forgetResult = instanceStage.forgetResult;
    }
    followUpForgetResults.push(...instanceStage.followUpForgetResults);
  }
  if (dependentForgetHashes.length > 0) {
    if (outstandingForgetHashes.length === 0) {
      const dependentStage = await executeForgetStage({
        sender: args.sender,
        hashes: dependentForgetHashes,
        reason: forgetReason,
        signer: args.signer,
        hasher: args.hasher,
        fetch: args.fetch,
        channel: args.channel,
        apiHost: args.apiHost,
        now: args.now
      });
      forgetStageResults.push({ stage: "dependents", ...dependentStage });
      forgottenHashes.push(...dependentStage.forgottenHashes);
      outstandingForgetHashes.push(...dependentStage.outstandingForgetHashes);
      forgetStatuses = { ...forgetStatuses, ...dependentStage.statuses };
      if (!forgetResult && dependentStage.forgetResult) {
        forgetResult = dependentStage.forgetResult;
      }
      followUpForgetResults.push(...dependentStage.followUpForgetResults);
    } else {
      const dependentStageStatus = await classifyForgetHashes({
        hashes: dependentForgetHashes,
        fetch: args.fetch,
        apiHost: args.apiHost
      });
      forgetStageResults.push({
        stage: "dependents",
        hashes: dependentForgetHashes,
        skipped: true,
        skippedReason: "Waiting for instance forget stage to complete before pruning dependent store items.",
        forgottenHashes: dependentStageStatus.forgottenHashes,
        outstandingForgetHashes: dependentStageStatus.outstandingForgetHashes,
        statuses: dependentStageStatus.statuses,
        forgetResult: null,
        followUpForgetResults: []
      });
      forgottenHashes.push(...dependentStageStatus.forgottenHashes);
      outstandingForgetHashes.push(...dependentStageStatus.outstandingForgetHashes);
      forgetStatuses = { ...forgetStatuses, ...dependentStageStatus.statuses };
    }
  }
  forgottenHashes = uniqueHashes(forgottenHashes);
  outstandingForgetHashes = uniqueHashes(outstandingForgetHashes);
  return {
    sender: args.sender,
    aggregateKey,
    keepCount,
    aggregatePublication,
    retainedRecords,
    prunedRecords,
    forgetHashes,
    forgottenHashes,
    outstandingForgetHashes,
    forgetStatuses,
    forgetResult,
    followUpForgetResults,
    forgetStageResults
  };
}

// src/aggregate-publication.ts
function createPortForwardAggregateContent(args) {
  const existingPorts = normalizeExistingPortForwardEntry(args.existingAggregate?.[args.instanceItemHash]);
  const mergedPorts = mergePortFlagMaps(existingPorts, requestedPortFlags(args.requestedPorts));
  return {
    address: args.sender,
    key: "port-forwarding",
    content: {
      [args.instanceItemHash]: {
        ports: mergedPorts
      }
    },
    time: args.now ?? Date.now() / 1e3
  };
}
async function createUnsignedAggregateMessage2(args) {
  const itemContent = JSON.stringify(args.content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "AGGREGATE",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function ensureInstancePortForwards(args) {
  const requestedPorts = requiredInstancePortForwards(args.manifest);
  const aggregate = await fetchPortForwardAggregate(args.sender, {
    apiHost: args.apiHost,
    fetch: args.fetch
  });
  const content = createPortForwardAggregateContent({
    sender: args.sender,
    instanceItemHash: args.instanceItemHash,
    requestedPorts,
    existingAggregate: aggregate
  });
  const unsignedMessage = await createUnsignedAggregateMessage2({
    sender: args.sender,
    content,
    hasher: args.hasher,
    channel: args.channel
  });
  const message = await signAlephMessage(unsignedMessage, args.signer);
  const { response, httpStatus } = await broadcastAlephMessage(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const aggregateStatus = normalizeBroadcastStatus(httpStatus, response.message_status);
  if (aggregateStatus === "rejected") {
    throw new Error(`Port-forward aggregate was rejected by Aleph: ${JSON.stringify(response.details ?? response)}`);
  }
  return {
    aggregateItemHash: message.item_hash,
    aggregateStatus,
    requestedPorts
  };
}

// src/instance-deployment.ts
var SSH_PUBLIC_KEY_PATTERN = /^(ssh-rsa|ssh-ed25519|ecdsa-sha2-nistp256|ecdsa-sha2-nistp384|ecdsa-sha2-nistp521|sk-ssh-ed25519@openssh\.com|sk-ecdsa-sha2-nistp256@openssh\.com)\s+[A-Za-z0-9+/]+={0,3}(?:\s+.+)?$/;
function toFiniteNumber(value) {
  if (typeof value === "number") return value;
  if (typeof value === "string" && value.trim()) return Number(value);
  return Number.NaN;
}
function normalizeSshPublicKey(value) {
  return value.split(/\r?\n/g).map((line) => line.trim()).filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
}
function isValidSshPublicKey(value) {
  return SSH_PUBLIC_KEY_PATTERN.test(normalizeSshPublicKey(value));
}
function createDeploymentToken() {
  const randomUuid = globalThis.crypto?.randomUUID?.();
  if (typeof randomUuid === "string" && randomUuid.trim()) {
    return randomUuid;
  }
  return `deploy-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}
function appendDeploymentTokenToSshPublicKey(sshPublicKey, ownerAddress, deploymentToken) {
  const normalized = normalizeSshPublicKey(sshPublicKey);
  if (!normalized) return normalized;
  const [algorithm = "", key = ""] = normalized.split(/\s+/, 3);
  const owner = ownerAddress.trim();
  const token = deploymentToken.trim();
  if (!algorithm || !key || !owner || !token) {
    return normalized;
  }
  return `${algorithm} ${key} aleph-bootstrap-config:${owner}:${token}`;
}
function createReleaseMetadata(name, rootfsVersion, deployer = "shared-aleph-tooling") {
  return {
    name,
    rootfs_version: rootfsVersion,
    deployer
  };
}
function selectedTier(pricing, tierId) {
  return pricing?.tiers.find((tier) => tier.id === tierId) ?? null;
}
function tierSpec(pricing, tier) {
  return {
    vcpus: pricing.compute_unit.vcpus * tier.compute_units,
    memoryMiB: pricing.compute_unit.memory_mib * tier.compute_units,
    diskMiB: pricing.compute_unit.disk_mib * tier.compute_units
  };
}
function buildPaymentQuote(tier, pricing, balance) {
  const computeUnitPrice = pricing.price.compute_unit;
  if (!computeUnitPrice) return null;
  const unitPrice = toFiniteNumber(computeUnitPrice.credit);
  if (!Number.isFinite(unitPrice)) return null;
  return {
    required: unitPrice * tier.compute_units,
    available: Number(balance.credit_balance ?? 0),
    computeUnits: tier.compute_units,
    unitPrice,
    label: "credits"
  };
}
function quoteRequiredBudgetUnits(quote) {
  if (!quote) return 0n;
  return BigInt(Math.ceil(quote.required * 1e18));
}
function describeRejectedInstanceBroadcast(response) {
  const balanceMessage = extractInsufficientBalanceMessage(response.details);
  if (balanceMessage) {
    return `Aleph rejected this deployment due to ${balanceMessage}.`;
  }
  const errorCode = typeof response.error_code === "number" ? response.error_code : null;
  return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}.`;
}
function createInstanceContent(args) {
  const sshKey = normalizeSshPublicKey(args.sshPublicKey);
  if (!sshKey) {
    throw new Error("An SSH public key is required.");
  }
  if (!isValidSshPublicKey(sshKey)) {
    throw new Error("SSH public key must be a single valid .pub line.");
  }
  if (!args.rootfsItemHash || !/^[a-fA-F0-9]{64}$/.test(args.rootfsItemHash)) {
    throw new Error("rootfsItemHash must be a 64-character Aleph item hash.");
  }
  return {
    address: args.address,
    time: args.now ?? Date.now() / 1e3,
    allow_amend: false,
    metadata: createReleaseMetadata(args.name.trim(), args.rootfsVersion ?? "custom-rootfs", args.deployer),
    authorized_keys: [sshKey],
    environment: {
      internet: true,
      aleph_api: true,
      hypervisor: "qemu",
      reproducible: false,
      shared_cache: false
    },
    resources: {
      vcpus: Number(args.vcpus),
      memory: Number(args.memoryMiB),
      seconds: Number(args.seconds ?? 30)
    },
    payment: {
      type: "credit"
    },
    requirements: args.crnHash ? {
      node: {
        node_hash: args.crnHash
      }
    } : void 0,
    volumes: [],
    rootfs: {
      parent: {
        ref: args.rootfsItemHash,
        use_latest: true
      },
      persistence: "host",
      size_mib: Number(args.rootfsSizeMiB)
    }
  };
}
async function createUnsignedInstanceMessage(args) {
  const itemContent = JSON.stringify(args.content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "INSTANCE",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function createDeploymentIntent(args) {
  const intent = {
    ownerAddress: args.sender,
    messageTime: args.unsignedMessage.time,
    itemHash: args.unsignedMessage.item_hash,
    paymentType: args.content.payment.type,
    rootfsRef: args.content.rootfs.parent.ref,
    rootfsSizeMiB: args.content.rootfs.size_mib,
    computeUnits: args.computeUnits,
    vcpus: args.content.resources.vcpus,
    memoryMiB: args.content.resources.memory,
    crnHash: args.content.requirements?.node?.node_hash ?? null,
    channel: args.unsignedMessage.channel,
    expiresAt: args.expiresAt,
    maxCost: args.maxCost
  };
  return {
    intent,
    intentHash: await args.hasher(JSON.stringify(intent))
  };
}
async function deployInstance(args) {
  args.onProgress?.({
    stage: "building-message",
    label: "Building deployment message",
    progress: 32,
    status: "info",
    detail: args.content.metadata?.name ?? null,
    itemHash: null,
    error: null,
    timestamp: Date.now()
  });
  const unsignedMessage = await createUnsignedInstanceMessage({
    sender: args.sender,
    content: args.content,
    hasher: args.hasher,
    channel: args.channel,
    now: args.now
  });
  args.onProgress?.({
    stage: "signing-message",
    label: "Waiting for MetaMask signature",
    progress: 48,
    status: "info",
    detail: unsignedMessage.item_hash,
    itemHash: unsignedMessage.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const signature = await args.signer(unsignedMessage.sender, [unsignedMessage.chain, unsignedMessage.sender, unsignedMessage.type, unsignedMessage.item_hash].join("\n"));
  const message = {
    ...unsignedMessage,
    signature: signature.startsWith("0x") ? signature : `0x${signature}`
  };
  args.onProgress?.({
    stage: "broadcasting",
    label: "Broadcasting to Aleph",
    progress: 64,
    status: "info",
    detail: message.item_hash,
    itemHash: message.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const { response, httpStatus } = await broadcastAlephMessage(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const status = httpStatus === 202 ? "pending" : typeof response.message_status === "string" ? response.message_status : "unknown";
  args.onProgress?.({
    stage: status === "processed" ? "deployment-confirmed" : status === "rejected" ? "deployment-rejected" : "waiting-for-aleph",
    label: status === "processed" ? "Deployment accepted by Aleph" : status === "rejected" ? "Deployment rejected by Aleph" : "Deployment submitted to Aleph",
    progress: status === "processed" ? 88 : status === "rejected" ? 100 : 78,
    status: status === "processed" ? "success" : status === "rejected" ? "error" : "warning",
    detail: status === "rejected" ? describeRejectedInstanceBroadcast(response) : null,
    itemHash: message.item_hash,
    error: status === "rejected" ? describeRejectedInstanceBroadcast(response) : null,
    timestamp: Date.now()
  });
  return {
    itemHash: message.item_hash,
    httpStatus,
    status,
    message,
    response,
    rejectionReason: status === "rejected" ? describeRejectedInstanceBroadcast(response) : null
  };
}

// src/guest.ts
function proxyHostnameFromUrl(value) {
  try {
    return value ? new URL(value).hostname : null;
  } catch {
    return null;
  }
}
async function defaultHttpProbe(fetch, url, timeoutMs = 1e4) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const response = await fetch(url, {
      method: "GET",
      redirect: "follow",
      signal: controller.signal
    });
    clearTimeout(timeout);
    return {
      ok: response.ok,
      status: response.status,
      url: response.url
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : String(error)
    };
  }
}
async function notifyCrnAllocation(args) {
  const normalizedCrnUrl = typeof args.crnUrl === "string" ? args.crnUrl.trim().replace(/\/+$/, "") : "";
  if (!normalizedCrnUrl) {
    return {
      status: "skipped",
      reason: "No CRN URL available for allocation notification."
    };
  }
  try {
    const response = await args.fetch(
      `${normalizedCrnUrl}/control/allocation/notify`,
      {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify({ instance: args.itemHash })
      }
    );
    const payload = await response.json().catch(() => null);
    const responseText = payload == null ? "" : typeof payload === "string" ? payload : JSON.stringify(payload);
    if (!response.ok) {
      return {
        status: "unconfirmed",
        reason: `CRN allocation notify returned ${response.status}${responseText ? ` ${responseText}` : ""}.`,
        payload
      };
    }
    return {
      status: "confirmed",
      payload
    };
  } catch (error) {
    return {
      status: "unconfirmed",
      reason: error instanceof Error ? error.message : String(error)
    };
  }
}
function isRetryableAllocationNotifyReason(reason) {
  const normalized = String(reason ?? "").toLowerCase();
  return normalized.includes("503") && (normalized.includes("node hash not yet discovered") || normalized.includes("cannot accept targeted allocations"));
}
async function notifyCrnAllocationWithRetry(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 6));
  const delayMs = Math.max(0, Number(args.delayMs ?? 2e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastResult = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    args.onProgress?.({
      stage: "notifying-crn",
      label: "Notifying selected CRN",
      progress: 84,
      status: "info",
      itemHash: args.itemHash,
      detail: `${attempt + 1}/${attempts} ${String(args.crnUrl ?? "").trim() || "selected CRN"}`,
      error: null,
      timestamp: Date.now()
    });
    const result = await notifyCrnAllocation({
      crnUrl: args.crnUrl,
      itemHash: args.itemHash,
      fetch: args.fetch
    });
    if (result.status === "confirmed" || result.status === "skipped") {
      return result;
    }
    lastResult = result;
    if (!isRetryableAllocationNotifyReason(result.reason)) {
      return result;
    }
    if (attempt < attempts - 1) {
      await sleep2(delayMs);
    }
  }
  return lastResult ?? {
    status: "unconfirmed",
    reason: "CRN allocation notify was not confirmed."
  };
}
async function waitForSetupEndpoint(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 15));
  const delayMs = Math.max(0, Number(args.delayMs ?? 4e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const url = `http://${args.hostIpv4}:${args.setupPort}/health`;
  let result = await defaultHttpProbe(
    args.fetch,
    url,
    Number(args.httpTimeoutMs ?? 1e4)
  );
  args.onAttempt?.(result, 1, attempts);
  for (let attempt = 1; attempt < attempts; attempt += 1) {
    if (result.ok) return result;
    await sleep2(delayMs);
    result = await defaultHttpProbe(
      args.fetch,
      url,
      Number(args.httpTimeoutMs ?? 1e4)
    );
    args.onAttempt?.(result, attempt + 1, attempts);
  }
  return result;
}
async function configureUcGoPeer(args) {
  const controller = new AbortController();
  const timeout = setTimeout(
    () => controller.abort(),
    Number(args.timeoutMs ?? 18e4)
  );
  const payload = {
    public_ipv4: args.hostIpv4,
    public_ipv6: args.publicIpv6 ?? void 0,
    proxy_url: args.proxyUrl ?? void 0,
    tcp_port: args.tcpPort ?? void 0,
    ws_port: args.wsPort ?? void 0,
    udp_port: args.udpPort ?? void 0,
    quic_port: args.quicPort ?? void 0,
    webrtc_port: args.webrtcPort ?? void 0,
    bootstrap_publisher_private_key: args.bootstrapPublisherPrivateKey ?? void 0,
    bootstrap_publisher_libp2p_identity_b64: args.bootstrapPublisherLibp2pIdentityBase64 ?? void 0,
    bootstrap_owner_private_key: args.bootstrapOwnerPrivateKey ?? void 0,
    bootstrap_owner_authorization_b64: args.bootstrapOwnerAuthorizationBase64 ?? void 0,
    bootstrap_registration_id: args.bootstrapRegistrationId ?? void 0,
    no_start: args.noStart === true ? true : void 0
  };
  try {
    const response = await args.fetch(
      `http://${args.hostIpv4}:${args.setupPort}/configure`,
      {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      }
    );
    const responsePayload = await response.json().catch(() => null);
    if (!response.ok) {
      throw new Error(
        `Relay setup request failed: ${response.status} ${typeof responsePayload === "string" ? responsePayload : JSON.stringify(responsePayload ?? {})}`
      );
    }
    return responsePayload;
  } finally {
    clearTimeout(timeout);
  }
}
async function configureOrbitdbRelaySetup(args) {
  const controller = new AbortController();
  const timeout = setTimeout(
    () => controller.abort(),
    Number(args.timeoutMs ?? 18e4)
  );
  const payload = {
    public_ipv4: args.hostIpv4,
    public_ipv6: args.publicIpv6 ?? void 0,
    tcp_port: args.tcpPort,
    ws_port: args.wsPort,
    proxy_url: args.proxyUrl ?? void 0,
    metrics_port: args.metricsPort ?? void 0,
    metrics_https_port: args.metricsHttpsPort ?? void 0,
    webrtc_port: args.webrtcPort ?? void 0,
    quic_port: args.quicPort ?? void 0,
    bootstrap_publisher_private_key: args.bootstrapPublisherPrivateKey ?? void 0,
    bootstrap_publisher_libp2p_identity_hex: args.bootstrapPublisherLibp2pIdentityHex ?? void 0,
    bootstrap_owner_private_key: args.bootstrapOwnerPrivateKey ?? void 0,
    bootstrap_owner_authorization_b64: args.bootstrapOwnerAuthorizationBase64 ?? void 0,
    bootstrap_registration_id: args.bootstrapRegistrationId ?? void 0,
    no_start: args.noStart === true ? true : void 0
  };
  try {
    const response = await args.fetch(
      `http://${args.hostIpv4}:${args.setupPort}/configure`,
      {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      }
    );
    const responsePayload = await response.json().catch(() => null);
    if (!response.ok) {
      throw new Error(
        `Relay setup request failed: ${response.status} ${typeof responsePayload === "string" ? responsePayload : JSON.stringify(responsePayload ?? {})}`
      );
    }
    return responsePayload;
  } finally {
    clearTimeout(timeout);
  }
}
async function fetchUcGoPeerMetadata(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 60));
  const delayMs = Math.max(0, Number(args.delayMs ?? 3e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastPayload = null;
  let lastError = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(
      () => controller.abort(),
      Number(args.timeoutMs ?? 18e4)
    );
    const requestUrl = args.metadataUrl && args.metadataUrl.trim() ? args.metadataUrl : `http://${args.hostIpv4}:${args.setupPort}/metadata`;
    try {
      const response = await args.fetch(
        requestUrl,
        {
          signal: controller.signal
        }
      );
      const payload = await response.json().catch(() => null);
      lastPayload = payload;
      lastError = null;
      const ready = Boolean(
        args.isReady ? args.isReady({
          payload,
          ok: response.ok,
          status: response.status,
          requestUrl
        }) : response.ok && payload && typeof payload === "object" && payload.status === "ready"
      );
      args.onAttempt?.({
        payload,
        ready,
        attempt: attempt + 1,
        attempts,
        requestUrl,
        ok: response.ok,
        status: response.status,
        error: null
      });
      if (ready) {
        return payload;
      }
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error);
      lastPayload = {
        error: lastError
      };
      args.onAttempt?.({
        payload: null,
        ready: false,
        attempt: attempt + 1,
        attempts,
        requestUrl,
        ok: false,
        status: null,
        error: lastError
      });
    } finally {
      clearTimeout(timeout);
    }
    if (attempt < attempts - 1) {
      await sleep2(delayMs);
    }
  }
  throw new Error(
    `Relay metadata did not become ready after ${attempts} attempts: ${lastError ? lastError : typeof lastPayload === "string" ? lastPayload : JSON.stringify(lastPayload ?? {})}`
  );
}
async function verifyUcGoPeerReachability(args) {
  const checks = {};
  const mappedPorts = args.mappedPorts ?? {};
  const hostIpv4 = args.hostIpv4;
  const skippedInternalPorts = new Set(
    (args.skipInternalPorts ?? ["80"]).map((value) => String(value))
  );
  const httpProbe = args.httpProbe ?? ((url, timeoutMs) => defaultHttpProbe(args.fetch, url, timeoutMs));
  if (hostIpv4) {
    for (const [internalPort, mapping] of Object.entries(mappedPorts)) {
      if (skippedInternalPorts.has(String(internalPort))) continue;
      if (mapping?.tcp === true && mapping?.host) {
        checks[`tcp:${internalPort}`] = {
          host: hostIpv4,
          port: mapping.host,
          ...await args.tcpProbe(
            hostIpv4,
            mapping.host,
            Number(args.tcpTimeoutMs ?? 5e3)
          )
        };
      } else if (mapping?.udp === true && mapping?.host) {
        checks[`udp:${internalPort}`] = {
          host: hostIpv4,
          port: mapping.host,
          ok: null,
          note: "UDP mapping published; CI does not perform an application-level UDP handshake probe."
        };
      }
    }
  }
  if (args.proxyUrl && args.verifyProxyHttp !== false) {
    checks["https:proxy"] = await httpProbe(
      args.proxyUrl,
      Number(args.httpTimeoutMs ?? 1e4)
    );
  }
  const proxyHostname = proxyHostnameFromUrl(args.proxyUrl);
  if (proxyHostname) {
    checks["tcp:proxy-443"] = await args.tcpProbe(
      proxyHostname,
      443,
      Number(args.tcpTimeoutMs ?? 5e3)
    );
  }
  const failedChecks = Object.entries(checks).filter(
    ([, value]) => value?.ok === false
  );
  return {
    ok: failedChecks.length === 0,
    checks
  };
}

// ../aleph-bootstrap/src/index.ts
var DEFAULT_ALEPH_API_HOST2 = "https://api.aleph.im";
var DEFAULT_ALEPH_BOOTSTRAP_CHANNEL = "simple-todo";
var DEFAULT_ALEPH_BOOTSTRAP_REF = "simple-todo-bootstrap";
var DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE = "relay-bootstrap";
var DEFAULT_BOOTSTRAP_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
var DEFAULT_BOOTSTRAP_PAGINATION = 50;
var RELAY_BOOTSTRAP_SIGNATURE_SCHEME = "personal_sign";
function serializeOwnerAuthorizationPayload(payload) {
  return JSON.stringify({
    ownerAddress: payload.ownerAddress,
    publisherAddress: payload.publisherAddress,
    peerId: payload.peerId,
    registrationId: payload.registrationId,
    profile: payload.profile,
    version: payload.version,
    instanceItemHash: payload.instanceItemHash,
    issuedAt: payload.issuedAt,
    expiresAt: payload.expiresAt
  });
}
function serializeRelayProofPayload(payload) {
  return JSON.stringify({
    peerId: payload.peerId,
    multiaddrs: dedupeMultiaddrs(payload.multiaddrs),
    browserMultiaddrs: payload.browserMultiaddrs ? dedupeMultiaddrs(payload.browserMultiaddrs) : void 0,
    registrationId: payload.registrationId,
    profile: payload.profile,
    version: payload.version,
    updatedAt: payload.updatedAt
  });
}
function asTrimmedString(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function asNumber3(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function normalizeHost(host) {
  return host.trim().toLowerCase();
}
function normalizeAddress(address) {
  return address.trim().toLowerCase();
}
function normalizeSignature(signature) {
  const trimmed = signature.trim();
  return trimmed.startsWith("0x") ? trimmed : `0x${trimmed}`;
}
function splitMultiaddr(addr) {
  return addr.split("/").filter(Boolean);
}
function isPrivateIpv4(ip) {
  const parts = ip.split(".").map((part) => Number(part));
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) {
    return false;
  }
  if (parts[0] === 10) return true;
  if (parts[0] === 127) return true;
  if (parts[0] === 0) return true;
  if (parts[0] === 169 && parts[1] === 254) return true;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  if (parts[0] === 192 && parts[1] === 168) return true;
  if (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127) return true;
  return false;
}
function isPrivateIpv6(ip) {
  const normalized = ip.trim().toLowerCase();
  return normalized === "::1" || normalized.startsWith("fc") || normalized.startsWith("fd") || normalized.startsWith("fe8") || normalized.startsWith("fe9") || normalized.startsWith("fea") || normalized.startsWith("feb");
}
function isLocalHostname(host) {
  const normalized = normalizeHost(host);
  return normalized === "localhost" || normalized.endsWith(".localhost") || normalized.endsWith(".local");
}
function hasPeerId(addr) {
  return splitMultiaddr(addr).includes("p2p");
}
function isBrowserDialableMultiaddr(addr) {
  const normalized = addr.toLowerCase();
  return normalized.includes("/ws") || normalized.includes("/wss") || normalized.includes("/webtransport") || normalized.includes("/webrtc-direct");
}
function dedupeMultiaddrs(addrs) {
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const value of addrs) {
    const trimmed = value.trim();
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    result.push(trimmed);
  }
  return result;
}
function isPublicMultiaddr(addr) {
  const parts = splitMultiaddr(addr);
  for (let index = 0; index < parts.length; index += 1) {
    const protocol = parts[index];
    const value = parts[index + 1];
    if (protocol === "ip4" && value) {
      return !isPrivateIpv4(value);
    }
    if (protocol === "ip6" && value) {
      return !isPrivateIpv6(value);
    }
    if ((protocol === "dns4" || protocol === "dns6" || protocol === "dnsaddr") && value) {
      return !isLocalHostname(value);
    }
  }
  return false;
}
function filterPublicMultiaddrs(addrs, options = {}) {
  return dedupeMultiaddrs(addrs).filter((addr) => {
    if (!isPublicMultiaddr(addr)) return false;
    if (options.requirePeerId !== false && !hasPeerId(addr)) return false;
    if (options.browserDialableOnly && !isBrowserDialableMultiaddr(addr)) {
      return false;
    }
    return true;
  });
}
function normalizeRelayBootstrapContent(value) {
  if (!value || typeof value !== "object") return null;
  const content = value;
  const peerId = asTrimmedString(content.peerId);
  const updatedAt = asNumber3(content.updatedAt);
  if (!peerId || updatedAt == null) return null;
  const multiaddrs = Array.isArray(content.multiaddrs) ? content.multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserMultiaddrs = Array.isArray(content.browserMultiaddrs) ? content.browserMultiaddrs.filter((entry) => typeof entry === "string") : void 0;
  return {
    peerId,
    multiaddrs: dedupeMultiaddrs(multiaddrs),
    browserMultiaddrs: browserMultiaddrs ? dedupeMultiaddrs(browserMultiaddrs) : void 0,
    registrationId: asTrimmedString(content.registrationId) ?? void 0,
    profile: asTrimmedString(content.profile) ?? void 0,
    version: asTrimmedString(content.version) ?? void 0,
    ownerAddress: asTrimmedString(content.ownerAddress) ?? void 0,
    publisherAddress: asTrimmedString(content.publisherAddress) ?? void 0,
    authorization: normalizeRelayBootstrapAuthorizationRecord(content.authorization) ?? void 0,
    relayProof: normalizeRelayBootstrapProofRecord(content.relayProof) ?? void 0,
    updatedAt
  };
}
function normalizeRelayBootstrapAuthorizationPayload(value) {
  if (!value || typeof value !== "object") return null;
  const payload = value;
  const ownerAddress = asTrimmedString(payload.ownerAddress);
  const publisherAddress = asTrimmedString(payload.publisherAddress);
  const peerId = asTrimmedString(payload.peerId);
  const issuedAt = asNumber3(payload.issuedAt);
  const expiresAt = asNumber3(payload.expiresAt) ?? void 0;
  if (!ownerAddress || !publisherAddress || !peerId || issuedAt == null) {
    return null;
  }
  return {
    ownerAddress,
    publisherAddress,
    peerId,
    registrationId: asTrimmedString(payload.registrationId) ?? void 0,
    profile: asTrimmedString(payload.profile) ?? void 0,
    version: asTrimmedString(payload.version) ?? void 0,
    instanceItemHash: asTrimmedString(payload.instanceItemHash) ?? void 0,
    issuedAt,
    expiresAt
  };
}
function normalizeRelayBootstrapAuthorizationRecord(value) {
  if (!value || typeof value !== "object") return null;
  const record = value;
  const scheme = asTrimmedString(record.scheme);
  const signature = asTrimmedString(record.signature);
  const payload = normalizeRelayBootstrapAuthorizationPayload(record.payload);
  if (!scheme || !signature || !payload) return null;
  return { scheme, signature, payload };
}
function normalizeRelayBootstrapProofPayload(value) {
  if (!value || typeof value !== "object") return null;
  const payload = value;
  const peerId = asTrimmedString(payload.peerId);
  const updatedAt = asNumber3(payload.updatedAt);
  if (!peerId || updatedAt == null) return null;
  const multiaddrs = Array.isArray(payload.multiaddrs) ? payload.multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserMultiaddrs = Array.isArray(payload.browserMultiaddrs) ? payload.browserMultiaddrs.filter((entry) => typeof entry === "string") : void 0;
  return {
    peerId,
    multiaddrs: dedupeMultiaddrs(multiaddrs),
    browserMultiaddrs: browserMultiaddrs ? dedupeMultiaddrs(browserMultiaddrs) : void 0,
    registrationId: asTrimmedString(payload.registrationId) ?? void 0,
    profile: asTrimmedString(payload.profile) ?? void 0,
    version: asTrimmedString(payload.version) ?? void 0,
    updatedAt
  };
}
function normalizeRelayBootstrapProofRecord(value) {
  if (!value || typeof value !== "object") return null;
  const record = value;
  const scheme = asTrimmedString(record.scheme);
  const signature = asTrimmedString(record.signature);
  const payload = normalizeRelayBootstrapProofPayload(record.payload);
  if (!scheme || !signature || !payload) return null;
  return { scheme, signature, payload };
}
function normalizeRelayBootstrapPostRecord(value) {
  if (!value || typeof value !== "object") return null;
  const entry = value;
  return {
    hash: asTrimmedString(entry.hash),
    itemHash: asTrimmedString(entry.item_hash),
    address: asTrimmedString(entry.address),
    ref: asTrimmedString(entry.ref),
    type: asTrimmedString(entry.type),
    time: asNumber3(entry.time),
    content: normalizeRelayBootstrapContent(entry.content)
  };
}
function buildRelayBootstrapPostContent(args) {
  const now = args.now ?? Date.now() / 1e3;
  const updatedAt = args.now ?? Date.now();
  return {
    type: args.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE,
    address: args.sender,
    ...args.ref ? { ref: args.ref } : {},
    content: {
      peerId: args.peerId,
      multiaddrs: filterPublicMultiaddrs(args.multiaddrs),
      browserMultiaddrs: args.browserMultiaddrs ? filterPublicMultiaddrs(args.browserMultiaddrs, {
        browserDialableOnly: true
      }) : void 0,
      registrationId: args.registrationId,
      profile: args.profile,
      version: args.version,
      ownerAddress: args.ownerAddress,
      publisherAddress: args.publisherAddress,
      authorization: args.authorization,
      relayProof: args.relayProof,
      updatedAt: Math.round(updatedAt)
    },
    time: now
  };
}
async function createRelayBootstrapPost(args) {
  const nowMillis = args.now ?? Date.now();
  const nowSeconds = nowMillis / 1e3;
  const itemContent = buildRelayBootstrapPostContent({
    sender: args.sender,
    peerId: args.peerId,
    multiaddrs: args.multiaddrs,
    browserMultiaddrs: args.browserMultiaddrs,
    registrationId: args.registrationId,
    ref: args.ref ?? DEFAULT_ALEPH_BOOTSTRAP_REF,
    postType: args.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE,
    profile: args.profile,
    version: args.version,
    ownerAddress: args.ownerAddress,
    publisherAddress: args.publisherAddress,
    authorization: args.authorization,
    relayProof: args.relayProof,
    now: nowMillis
  });
  itemContent.time = nowSeconds;
  const serialized = JSON.stringify(itemContent);
  const itemHash = await args.hasher(serialized);
  return {
    channel: args.channel ?? DEFAULT_ALEPH_BOOTSTRAP_CHANNEL,
    sender: args.sender,
    chain: "ETH",
    type: "POST",
    time: nowSeconds,
    item_type: "inline",
    item_content: serialized,
    item_hash: itemHash
  };
}
async function signRelayBootstrapAuthorization(args) {
  const payload = {
    ownerAddress: args.ownerAddress,
    publisherAddress: args.publisherAddress,
    peerId: args.peerId,
    registrationId: args.registrationId,
    profile: args.profile,
    version: args.version,
    instanceItemHash: args.instanceItemHash,
    issuedAt: args.issuedAt ?? Date.now(),
    expiresAt: args.expiresAt
  };
  const serialized = serializeOwnerAuthorizationPayload(payload);
  const signature = await args.signer(args.ownerAddress, serialized);
  return {
    scheme: RELAY_BOOTSTRAP_SIGNATURE_SCHEME,
    payload,
    signature: normalizeSignature(signature)
  };
}
async function signRelayBootstrapProof(args) {
  const payload = {
    peerId: args.peerId,
    multiaddrs: filterPublicMultiaddrs(args.multiaddrs),
    browserMultiaddrs: args.browserMultiaddrs ? filterPublicMultiaddrs(args.browserMultiaddrs, {
      browserDialableOnly: true
    }) : void 0,
    registrationId: args.registrationId,
    profile: args.profile,
    version: args.version,
    updatedAt: args.updatedAt ?? Date.now()
  };
  const serialized = serializeRelayProofPayload(payload);
  const signature = await args.signer(args.publisherAddress, serialized);
  return {
    scheme: RELAY_BOOTSTRAP_SIGNATURE_SCHEME,
    payload,
    signature: normalizeSignature(signature)
  };
}
async function fetchAlephBootstrapPosts(options = {}) {
  const fetchImpl = options.fetch ?? globalThis.fetch?.bind(globalThis);
  if (typeof fetchImpl !== "function") {
    throw new Error(
      "A fetch implementation is required to query Aleph bootstrap posts."
    );
  }
  const url = new URL(
    "/api/v0/posts.json",
    options.apiHost ?? DEFAULT_ALEPH_API_HOST2
  );
  url.searchParams.set(
    "channels",
    options.channel ?? DEFAULT_ALEPH_BOOTSTRAP_CHANNEL
  );
  url.searchParams.set("refs", options.ref ?? DEFAULT_ALEPH_BOOTSTRAP_REF);
  url.searchParams.set(
    "types",
    options.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE
  );
  url.searchParams.set(
    "pagination",
    String(options.pagination ?? DEFAULT_BOOTSTRAP_PAGINATION)
  );
  url.searchParams.set("page", String(options.page ?? 1));
  const response = await fetchImpl(url.toString(), {
    method: "GET",
    headers: { accept: "application/json" }
  });
  if (!response.ok) {
    throw new Error(`Aleph bootstrap post lookup failed: ${response.status}`);
  }
  const payload = await response.json();
  return (payload.posts ?? []).map((entry) => normalizeRelayBootstrapPostRecord(entry)).filter((entry) => entry != null);
}
function compareRelayBootstrapPostRecency(left, right) {
  const leftUpdatedAt = left.content?.updatedAt ?? 0;
  const rightUpdatedAt = right.content?.updatedAt ?? 0;
  if (leftUpdatedAt !== rightUpdatedAt) return leftUpdatedAt - rightUpdatedAt;
  const leftTime = left.time ?? 0;
  const rightTime = right.time ?? 0;
  return leftTime - rightTime;
}
function relayBootstrapRecordIdentity(post) {
  const content = post.content;
  if (!content) return null;
  if (content.registrationId) return `registration:${content.registrationId}`;
  if (post.address) return `sender:${normalizeAddress(post.address)}`;
  return content.peerId ? `peer:${content.peerId}` : null;
}
function selectCurrentRelayBootstrapPosts(posts, options = {}) {
  const maxAgeMs = options.maxAgeMs ?? DEFAULT_BOOTSTRAP_MAX_AGE_MS;
  const now = options.now ?? Date.now();
  const selected = /* @__PURE__ */ new Map();
  for (const post of posts) {
    const content = post.content;
    if (!content) continue;
    if (now - content.updatedAt > maxAgeMs) continue;
    const identity = relayBootstrapRecordIdentity(post);
    if (!identity) continue;
    const previous = selected.get(identity);
    if (!previous || compareRelayBootstrapPostRecency(post, previous) > 0) {
      selected.set(identity, post);
    }
  }
  return [...selected.values()].sort(
    (left, right) => compareRelayBootstrapPostRecency(right, left)
  );
}

// src/bootstrap-registration.ts
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function waitForRelayBootstrapRegistration(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 10));
  const delayMs = Math.max(0, Number(args.delayMs ?? 2e3));
  const expectedSender = args.sender?.trim().toLowerCase() || null;
  const expectedRegistrationId = args.registrationId?.trim() || null;
  const expectedPeerId = args.peerId?.trim() || null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const posts = await fetchAlephBootstrapPosts({
      apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST2,
      channel: args.channel,
      ref: args.ref,
      postType: args.postType,
      fetch: args.fetch
    });
    const currentPosts = selectCurrentRelayBootstrapPosts(posts);
    const match = currentPosts.find((post) => {
      if (expectedSender && post.address?.toLowerCase() !== expectedSender) {
        return false;
      }
      if (expectedRegistrationId && post.content?.registrationId === expectedRegistrationId) {
        return true;
      }
      if (expectedPeerId && post.content?.peerId === expectedPeerId) {
        return true;
      }
      return false;
    });
    if (match?.content) {
      const visibleRegistration = {
        itemHash: match.itemHash ?? null,
        hash: match.hash ?? null,
        sender: typeof match.address === "string" ? match.address : null,
        registrationId: match.content.registrationId,
        peerId: match.content.peerId,
        multiaddrs: Array.isArray(match.content.multiaddrs) ? match.content.multiaddrs : [],
        browserMultiaddrs: Array.isArray(match.content.browserMultiaddrs) ? match.content.browserMultiaddrs : []
      };
      args.onAttempt?.(visibleRegistration, attempt + 1, attempts);
      return visibleRegistration;
    }
    args.onAttempt?.(null, attempt + 1, attempts);
    if (attempt < attempts - 1) {
      await sleep(delayMs);
    }
  }
  return null;
}
async function publishRelayBootstrapRegistration(args) {
  const publisherAddress = args.publisherAddress ?? args.sender;
  const ownerAddress = args.ownerAddress;
  let ownerAuthorization = args.ownerAuthorization;
  let relayProof = args.relayProof;
  if (!ownerAuthorization && ownerAddress && args.ownerSigner) {
    ownerAuthorization = await signRelayBootstrapAuthorization({
      ownerAddress,
      publisherAddress,
      peerId: args.peerId,
      registrationId: args.registrationId,
      profile: args.profile,
      version: args.version,
      instanceItemHash: args.instanceItemHash,
      issuedAt: args.authorizationIssuedAt ?? args.now ?? Date.now(),
      expiresAt: args.authorizationExpiresAt,
      signer: args.ownerSigner
    });
  }
  if (!relayProof && args.publisherSigner) {
    relayProof = await signRelayBootstrapProof({
      publisherAddress,
      peerId: args.peerId,
      multiaddrs: args.multiaddrs,
      browserMultiaddrs: args.browserMultiaddrs,
      registrationId: args.registrationId,
      profile: args.profile,
      version: args.version,
      updatedAt: args.now ?? Date.now(),
      signer: args.publisherSigner
    });
  }
  const unsigned = await createRelayBootstrapPost({
    sender: args.sender,
    peerId: args.peerId,
    multiaddrs: args.multiaddrs,
    browserMultiaddrs: args.browserMultiaddrs,
    registrationId: args.registrationId,
    channel: args.channel,
    ref: args.ref,
    postType: args.postType,
    profile: args.profile,
    version: args.version,
    ownerAddress,
    publisherAddress,
    authorization: ownerAuthorization,
    relayProof,
    now: args.now,
    hasher: args.hasher
  });
  const content = JSON.parse(unsigned.item_content);
  if ((content.content?.multiaddrs?.length ?? 0) === 0) {
    return {
      status: "skipped",
      reason: "No public relay multiaddrs remained after filtering.",
      publishedMultiaddrs: [],
      publishedBrowserMultiaddrs: content.content?.browserMultiaddrs ?? []
    };
  }
  const message = await signAlephMessage(unsigned, args.signer);
  const { response, httpStatus } = await broadcastAlephMessage(message, {
    apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST2,
    sync: args.sync ?? true,
    fetch: args.fetch
  });
  let forgottenHashes = [];
  let forgetResult;
  if (args.forgetPrevious && args.registrationId) {
    const previousPosts = await fetchAlephBootstrapPosts({
      apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST2,
      channel: args.channel,
      ref: args.ref,
      postType: args.postType,
      fetch: args.fetch
    });
    forgottenHashes = previousPosts.filter(
      (post) => post.address?.toLowerCase() === args.sender.toLowerCase() && post.content?.registrationId === args.registrationId && (post.itemHash ?? post.hash) != null && (post.itemHash ?? post.hash) !== unsigned.item_hash
    ).map((post) => post.itemHash ?? post.hash ?? "").filter(Boolean);
    if (forgottenHashes.length > 0) {
      forgetResult = await forgetAlephMessages({
        sender: args.sender,
        hashes: forgottenHashes,
        reason: args.forgetPreviousReason ?? `Replace older relay bootstrap records for ${args.registrationId}`,
        signer: args.signer,
        hasher: args.hasher,
        fetch: args.fetch,
        apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST2,
        sync: args.sync ?? true
      });
    }
  }
  return {
    status: "published",
    itemHash: unsigned.item_hash,
    message,
    response,
    httpStatus,
    publishedMultiaddrs: content.content?.multiaddrs ?? [],
    publishedBrowserMultiaddrs: content.content?.browserMultiaddrs ?? [],
    forgottenHashes,
    forgetResult
  };
}

// src/bootstrap-config.ts
var VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY = "vm-bootstrap-config";
var VM_BOOTSTRAP_CONFIG_SIGNAL_REF = "vm-bootstrap-config";
var VM_BOOTSTRAP_CONFIG_SIGNAL_POST_TYPE = "vm-bootstrap-config-status";
var VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS = 6 * 60 * 60 * 1e3;
function parseJsonObject(value) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
function parseTimestampMs(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value > 1e12 ? value : value * 1e3;
  }
  if (typeof value === "string" && value.trim()) {
    const numeric = Number(value);
    if (Number.isFinite(numeric)) {
      return numeric > 1e12 ? numeric : numeric * 1e3;
    }
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function normalizeVmBootstrapConfigRecord(deploymentTokenKey, value, options = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value;
  const deploymentToken = typeof candidate.deploymentToken === "string" ? candidate.deploymentToken.trim() : "";
  const profile = typeof candidate.profile === "string" ? candidate.profile.trim() : "";
  const ownerAddress = typeof candidate.ownerAddress === "string" ? candidate.ownerAddress.trim() : "";
  const instanceItemHash = typeof candidate.instanceItemHash === "string" ? candidate.instanceItemHash.trim() : "";
  const createdAt = typeof candidate.createdAt === "string" ? candidate.createdAt.trim() : "";
  const expiresAt = typeof candidate.expiresAt === "string" ? candidate.expiresAt.trim() : "";
  if (!deploymentTokenKey.trim() || !deploymentToken || deploymentToken !== deploymentTokenKey.trim() || !profile || !ownerAddress || !instanceItemHash || !createdAt || !expiresAt) {
    return null;
  }
  const nowMs = Math.max(0, Number(options.nowMs ?? Date.now()));
  const maxRecordAgeMs = Math.max(
    6e4,
    Number(options.maxRecordAgeMs ?? VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS)
  );
  const createdAtMs = parseTimestampMs(createdAt);
  const expiresAtMs = parseTimestampMs(expiresAt);
  if (createdAtMs == null || expiresAtMs == null) return null;
  if (expiresAtMs <= nowMs) return null;
  if (createdAtMs < nowMs - maxRecordAgeMs) return null;
  return candidate;
}
async function fetchVmBootstrapConfigAggregate(address, options) {
  const requestUrl = new URL(`/api/v0/aggregates/${address}.json`, options.apiHost ?? DEFAULT_ALEPH_API_HOST);
  requestUrl.searchParams.set("keys", VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY);
  const response = await options.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (response.status === 404) return {};
  if (!response.ok) {
    throw new Error(`VM bootstrap config aggregate request failed: ${response.status}`);
  }
  const payload = await response.json();
  const aggregate = payload.data?.[VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY];
  if (!aggregate || typeof aggregate !== "object" || Array.isArray(aggregate)) return {};
  return aggregate;
}
function normalizeVmBootstrapConfigAggregate(aggregate, options = {}) {
  if (!aggregate || typeof aggregate !== "object") return {};
  return Object.fromEntries(
    Object.entries(aggregate).map(([deploymentToken, record]) => [
      deploymentToken,
      normalizeVmBootstrapConfigRecord(deploymentToken, record, options)
    ]).filter((entry) => entry[1] != null)
  );
}
function createVmBootstrapConfigAggregateContent(args) {
  const nowMs = Math.max(0, Number(args.now ?? Date.now() / 1e3) * 1e3);
  const content = normalizeVmBootstrapConfigAggregate(args.existingAggregate, {
    nowMs,
    maxRecordAgeMs: args.maxRecordAgeMs
  });
  content[args.record.deploymentToken] = args.record;
  return {
    address: args.sender,
    key: VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY,
    content,
    time: args.now ?? Date.now() / 1e3
  };
}
async function createUnsignedVmBootstrapConfigAggregateMessage(args) {
  const itemContent = JSON.stringify(args.content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "AGGREGATE",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function publishVmBootstrapConfigAggregate(args) {
  const unsignedMessage = await createUnsignedVmBootstrapConfigAggregateMessage({
    sender: args.sender,
    content: args.content,
    hasher: args.hasher,
    channel: args.channel
  });
  const message = await signAlephMessage(unsignedMessage, args.signer);
  const { response, httpStatus } = await broadcastAlephMessage(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const aggregateStatus = httpStatus >= 200 && httpStatus < 300 ? response.message_status ?? "processed" : "unknown";
  if (aggregateStatus === "rejected") {
    throw new Error(`VM bootstrap config aggregate was rejected by Aleph: ${JSON.stringify(response.details ?? response)}`);
  }
  return {
    aggregateItemHash: message.item_hash,
    aggregateStatus
  };
}
function normalizeAggregateMessageHashRecord(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value;
  const itemHash = typeof candidate.item_hash === "string" ? candidate.item_hash.trim() : "";
  if (!itemHash) return null;
  const content = candidate.content && typeof candidate.content === "object" && !Array.isArray(candidate.content) ? candidate.content : typeof candidate.item_content === "string" ? parseJsonObject(candidate.item_content) : null;
  if (!content || content.key !== VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY) return null;
  const timeMs = parseTimestampMs(candidate.time);
  if (timeMs == null) return null;
  return { itemHash, timeMs };
}
async function listStaleVmBootstrapConfigAggregateMessageHashes(args) {
  const address = args.address.trim();
  if (!address) return [];
  const currentAggregateItemHash = args.currentAggregateItemHash?.trim() ?? "";
  const olderThanMs = Math.max(
    6e4,
    Number(args.olderThanMs ?? VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS)
  );
  const cutoffMs = Math.max(0, Number(args.nowMs ?? Date.now()) - olderThanMs);
  const pagination = Math.max(1, Number(args.pagination ?? 100));
  const maxPages = Math.max(1, Number(args.maxPages ?? 10));
  const hashes = /* @__PURE__ */ new Set();
  for (let page = 1; page <= maxPages; page += 1) {
    const requestUrl = new URL("/api/v0/messages.json", args.apiHost ?? DEFAULT_ALEPH_API_HOST);
    requestUrl.searchParams.set("msgType", "AGGREGATE");
    requestUrl.searchParams.set("addresses", address);
    requestUrl.searchParams.set("message_statuses", "processed,pending,rejected");
    requestUrl.searchParams.set("pagination", String(pagination));
    requestUrl.searchParams.set("page", String(page));
    requestUrl.searchParams.set("sortOrder", "-1");
    const response = await args.fetch(requestUrl.toString(), { cache: "no-cache" });
    if (!response.ok) {
      throw new Error(`VM bootstrap config aggregate history request failed: ${response.status}`);
    }
    const payload = await response.json();
    const messages = Array.isArray(payload.messages) ? payload.messages : [];
    if (messages.length === 0) break;
    for (const message of messages) {
      const normalized = normalizeAggregateMessageHashRecord(message);
      if (!normalized) continue;
      if (normalized.itemHash === currentAggregateItemHash) continue;
      if (normalized.timeMs > cutoffMs) continue;
      hashes.add(normalized.itemHash);
    }
    if (messages.length < pagination) break;
  }
  return [...hashes];
}
async function publishVmBootstrapConfig(args) {
  const aggregate = await fetchVmBootstrapConfigAggregate(args.sender, {
    apiHost: args.apiHost,
    fetch: args.fetch
  });
  const content = createVmBootstrapConfigAggregateContent({
    sender: args.sender,
    record: args.record,
    existingAggregate: aggregate,
    maxRecordAgeMs: VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS
  });
  const result = await publishVmBootstrapConfigAggregate({
    sender: args.sender,
    content,
    signer: args.signer,
    hasher: args.hasher,
    fetch: args.fetch,
    channel: args.channel,
    apiHost: args.apiHost,
    sync: args.sync
  });
  return {
    ...result,
    aggregate: content.content
  };
}
async function deleteVmBootstrapConfig(args) {
  const aggregate = await fetchVmBootstrapConfigAggregate(args.sender, {
    apiHost: args.apiHost,
    fetch: args.fetch
  });
  const content = normalizeVmBootstrapConfigAggregate(aggregate, {
    maxRecordAgeMs: VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS
  });
  delete content[args.deploymentToken];
  const publishResult = await publishVmBootstrapConfigAggregate({
    sender: args.sender,
    content: {
      address: args.sender,
      key: VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY,
      content,
      time: Date.now() / 1e3
    },
    signer: args.signer,
    hasher: args.hasher,
    fetch: args.fetch,
    channel: args.channel,
    apiHost: args.apiHost,
    sync: args.sync
  });
  return {
    ...publishResult,
    aggregate: content
  };
}
function normalizeVmBootstrapConfigSignalRecord(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value;
  const deploymentToken = typeof candidate.deploymentToken === "string" ? candidate.deploymentToken.trim() : "";
  const status = typeof candidate.status === "string" ? candidate.status.trim() : "";
  const profile = typeof candidate.profile === "string" ? candidate.profile.trim() : "";
  const ownerAddress = typeof candidate.ownerAddress === "string" ? candidate.ownerAddress.trim() : "";
  const instanceItemHash = typeof candidate.instanceItemHash === "string" ? candidate.instanceItemHash.trim() : "";
  const updatedAt = typeof candidate.updatedAt === "string" ? candidate.updatedAt.trim() : "";
  if (!deploymentToken || !status || !profile || !ownerAddress || !instanceItemHash || !updatedAt) {
    return null;
  }
  return {
    deploymentToken,
    status,
    profile,
    ownerAddress,
    instanceItemHash,
    updatedAt,
    publisherAddress: typeof candidate.publisherAddress === "string" && candidate.publisherAddress.trim() ? candidate.publisherAddress.trim() : null,
    authorization: candidate.authorization,
    peerId: typeof candidate.peerId === "string" && candidate.peerId.trim() ? candidate.peerId.trim() : null,
    probeMultiaddrs: Array.isArray(candidate.probeMultiaddrs) ? candidate.probeMultiaddrs.filter(
      (entry) => typeof entry === "string" && entry.trim().length > 0
    ) : [],
    browserBootstrapMultiaddrs: Array.isArray(candidate.browserBootstrapMultiaddrs) ? candidate.browserBootstrapMultiaddrs.filter(
      (entry) => typeof entry === "string" && entry.trim().length > 0
    ) : []
  };
}
async function fetchVmBootstrapConfigSignals(args) {
  const requestUrl = new URL("/api/v0/posts.json", args.apiHost ?? DEFAULT_ALEPH_API_HOST);
  requestUrl.searchParams.set("refs", args.ref ?? VM_BOOTSTRAP_CONFIG_SIGNAL_REF);
  requestUrl.searchParams.set("types", args.postType ?? VM_BOOTSTRAP_CONFIG_SIGNAL_POST_TYPE);
  requestUrl.searchParams.set("pagination", String(Math.max(1, Number(args.pagination ?? 100))));
  requestUrl.searchParams.set("page", String(Math.max(1, Number(args.page ?? 1))));
  requestUrl.searchParams.set("sortOrder", "-1");
  const response = await args.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (!response.ok) {
    throw new Error(`VM bootstrap config signal request failed: ${response.status}`);
  }
  const payload = await response.json();
  const expectedDeploymentToken = args.deploymentToken?.trim() ?? "";
  const expectedOwnerAddress = args.ownerAddress?.trim().toLowerCase() ?? "";
  const expectedInstanceItemHash = args.instanceItemHash?.trim() ?? "";
  return (payload.posts ?? []).map((entry) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
    const parsed = "content" in entry && entry.content && typeof entry.content === "object" && !Array.isArray(entry.content) ? entry.content : "item_content" in entry && typeof entry.item_content === "string" ? parseJsonObject(entry.item_content) : null;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
    const content = "deploymentToken" in parsed ? parsed : "content" in parsed && parsed.content && typeof parsed.content === "object" && !Array.isArray(parsed.content) ? parsed.content : null;
    if (!content || typeof content !== "object" || Array.isArray(content)) return null;
    return normalizeVmBootstrapConfigSignalRecord(content);
  }).filter((entry) => {
    if (!entry) return false;
    if (expectedDeploymentToken && entry.deploymentToken !== expectedDeploymentToken) return false;
    if (expectedOwnerAddress && entry.ownerAddress.toLowerCase() !== expectedOwnerAddress) return false;
    if (expectedInstanceItemHash && entry.instanceItemHash !== expectedInstanceItemHash) return false;
    return true;
  });
}
async function waitForVmBootstrapConfigSignal(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 24));
  const delayMs = Math.max(0, Number(args.delayMs ?? 2500));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const expectedStatus = args.expectedStatus ?? "applied";
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const signals = await fetchVmBootstrapConfigSignals({
      deploymentToken: args.deploymentToken,
      ownerAddress: args.ownerAddress,
      instanceItemHash: args.instanceItemHash,
      fetch: args.fetch,
      apiHost: args.apiHost,
      ref: args.ref,
      postType: args.postType
    }).catch(() => []);
    const match = signals.find((entry) => entry.status === expectedStatus) ?? null;
    if (match) return match;
    if (attempt < attempts - 1) {
      await sleep2(delayMs);
    }
  }
  return null;
}

// src/bootstrap-reconcile.ts
function createRelayBootstrapRegistrationId(profile, instanceName, itemHash) {
  const normalizedName = String(instanceName ?? "").trim();
  const normalizedHash = String(itemHash ?? "").trim();
  if (!normalizedHash) {
    return `relay:${profile}:${normalizedName || "instance"}`;
  }
  return `relay:${profile}:${normalizedName || normalizedHash}:${normalizedHash}`;
}
function secureBootstrapMetadataUrl(proxyUrl) {
  const normalized = String(proxyUrl ?? "").trim();
  if (!normalized) return null;
  try {
    return new URL("/bootstrap/metadata", normalized).toString();
  } catch {
    return null;
  }
}
function extractRelayMetadata(payload) {
  const metadata = payload && typeof payload === "object" && payload.metadata && typeof payload.metadata === "object" ? payload.metadata : null;
  const peerId = typeof metadata?.peer_id === "string" ? metadata.peer_id : null;
  const probeMultiaddrs = Array.isArray(metadata?.probe_multiaddrs) ? metadata.probe_multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserBootstrapMultiaddrs = Array.isArray(metadata?.browser_bootstrap_multiaddrs) ? metadata.browser_bootstrap_multiaddrs.filter((entry) => typeof entry === "string") : [];
  if (!peerId || probeMultiaddrs.length === 0) return null;
  return {
    peerId,
    probeMultiaddrs,
    browserBootstrapMultiaddrs
  };
}
async function fetchOwnerInstances(address, options) {
  const url = new URL("/api/v0/messages.json", options.apiHost ?? DEFAULT_ALEPH_API_HOST);
  url.searchParams.set("msgTypes", "INSTANCE");
  url.searchParams.set("addresses", address);
  url.searchParams.set("message_statuses", "processed,pending,rejected");
  url.searchParams.set("pagination", "100");
  url.searchParams.set("page", "1");
  url.searchParams.set("sortOrder", "-1");
  const response = await options.fetch(url.toString(), { cache: "no-cache" });
  if (!response.ok) {
    throw new Error(`Instance list request failed: ${response.status}`);
  }
  const payload = await response.json();
  return (payload.messages ?? []).map((message) => ({
    ...message,
    status: typeof message.status === "string" && message.status.trim() ? message.status : message.confirmed ? "processed" : "pending"
  }));
}
async function fetchRelayMetadataForRuntime(args) {
  const setupPort = args.runtime.mappedPorts?.["80"]?.host ?? 80;
  const metadataUrl = args.preferSecureMetadata ? secureBootstrapMetadataUrl(args.runtime.proxyUrl) : null;
  if (args.preferSecureMetadata && !metadataUrl) {
    return null;
  }
  const payload = await fetchUcGoPeerMetadata({
    hostIpv4: args.runtime.hostIpv4 ?? "",
    setupPort,
    metadataUrl,
    fetch: args.fetch,
    attempts: args.attempts,
    delayMs: args.delayMs,
    timeoutMs: args.timeoutMs,
    isReady: (result) => extractRelayMetadata(result.payload) != null,
    onAttempt: (result) => {
      args.onAttempt?.({
        ...result,
        metadataUrl,
        hostIpv4: args.runtime.hostIpv4 ?? null,
        setupPort
      });
    }
  }).catch(() => null);
  return extractRelayMetadata(payload);
}
async function reconcileOwnerRelayBootstrapRegistrations(args) {
  const result = {
    refreshedRegistrations: [],
    forgottenHashes: [],
    skippedInstanceHashes: [],
    errors: []
  };
  const liveRegistrationIds = /* @__PURE__ */ new Set();
  if (args.current?.registrationId) {
    liveRegistrationIds.add(args.current.registrationId);
    result.refreshedRegistrations.push(args.current.registrationId);
  }
  const instances = await fetchOwnerInstances(args.instanceOwnerAddress, {
    apiHost: args.apiHost,
    fetch: args.fetch
  });
  const processedInstances = instances.filter((instance) => {
    const status = String(instance.status ?? "").trim().toLowerCase();
    return status === "processed";
  });
  for (const instance of processedInstances) {
    if (instance.item_hash === args.current?.itemHash) continue;
    const registrationId = createRelayBootstrapRegistrationId(
      args.profile,
      instance.content?.metadata?.name,
      instance.item_hash
    );
    try {
      const runtime = await fetchVmRuntime({
        itemHash: instance.item_hash,
        fetch: args.fetch,
        crns: args.crns,
        crnListUrl: args.crnListUrl
      });
      if (!runtime.hostIpv4 || Object.keys(runtime.mappedPorts ?? {}).length === 0) {
        result.skippedInstanceHashes.push(instance.item_hash);
        continue;
      }
      const relayMetadata = await fetchRelayMetadataForRuntime({
        runtime,
        fetch: args.fetch,
        preferSecureMetadata: args.preferSecureMetadata,
        attempts: 3,
        delayMs: 1e3,
        timeoutMs: 1e4
      });
      if (!relayMetadata) {
        result.skippedInstanceHashes.push(instance.item_hash);
        continue;
      }
      liveRegistrationIds.add(registrationId);
      await publishRelayBootstrapRegistration({
        sender: args.sender,
        signer: args.signer,
        hasher: args.hasher,
        fetch: args.fetch,
        apiHost: args.apiHost,
        channel: args.channel,
        ref: args.ref,
        postType: args.postType,
        peerId: relayMetadata.peerId,
        multiaddrs: relayMetadata.probeMultiaddrs,
        browserMultiaddrs: relayMetadata.browserBootstrapMultiaddrs,
        registrationId,
        ownerAddress: args.ownerAddress,
        publisherAddress: args.publisherAddress,
        ownerSigner: args.ownerSigner,
        publisherSigner: args.publisherSigner,
        forgetPrevious: true,
        profile: args.profile,
        version: args.version,
        instanceItemHash: instance.item_hash,
        sync: true
      });
      result.refreshedRegistrations.push(registrationId);
    } catch (error) {
      result.errors.push({
        phase: "publish",
        itemHash: instance.item_hash,
        registrationId,
        message: error instanceof Error ? error.message : String(error)
      });
    }
  }
  try {
    const bootstrapPosts = await fetchAlephBootstrapPosts({
      apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST,
      channel: args.channel,
      ref: args.ref,
      postType: args.postType,
      fetch: args.fetch
    });
    const currentPosts = selectCurrentRelayBootstrapPosts(bootstrapPosts);
    const staleHashes = currentPosts.filter(
      (post) => post.address?.toLowerCase() === args.sender.toLowerCase() && post.content?.profile === args.profile && post.content?.registrationId && !liveRegistrationIds.has(post.content.registrationId)
    ).map((post) => post.itemHash ?? post.hash ?? "").filter(Boolean);
    if (staleHashes.length > 0) {
      await forgetAlephMessages({
        sender: args.sender,
        hashes: staleHashes,
        reason: `Forget stale ${args.profile} relay bootstrap registrations after owner reconcile`,
        signer: args.signer,
        hasher: args.hasher,
        fetch: args.fetch,
        apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST,
        sync: true
      });
      result.forgottenHashes.push(...staleHashes);
    }
  } catch (error) {
    result.errors.push({
      phase: "forget",
      message: error instanceof Error ? error.message : String(error)
    });
  }
  return result;
}
export {
  DEFAULT_ALEPH_API_HOST,
  DEFAULT_ALEPH_CHANNEL,
  DEFAULT_COUNTRY_LOOKUP_BASE_URL,
  DEFAULT_CRN_LIST_URL,
  DEFAULT_DNS_RESOLVE_URL,
  DEFAULT_INSTANCE_PORT_FORWARDS,
  DEFAULT_IPFS_GATEWAY_BASE_URL,
  DEFAULT_SCHEDULER_ALLOCATION_URL,
  DEFAULT_TWO_N_SIX_HASH_URL,
  ITEM_HASH_RE,
  SSH_PUBLIC_KEY_PATTERN,
  SUCCESSFUL_DEPLOYMENTS_AGGREGATE_KEY,
  VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY,
  VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS,
  VM_BOOTSTRAP_CONFIG_SIGNAL_POST_TYPE,
  VM_BOOTSTRAP_CONFIG_SIGNAL_REF,
  appendDeploymentTokenToSshPublicKey,
  broadcastAlephMessage,
  buildPaymentQuote,
  cleanupFailedDeployment,
  configureOrbitdbRelaySetup,
  configureUcGoPeer,
  createDeploymentIntent,
  createDeploymentToken,
  createInstanceContent,
  createPortForwardAggregateContent,
  createRelayBootstrapRegistrationId,
  createReleaseMetadata,
  createUnsignedAggregateMessage2 as createUnsignedAggregateMessage,
  createUnsignedForgetMessage,
  createUnsignedInstanceMessage,
  createVmBootstrapConfigAggregateContent,
  deleteVmBootstrapConfig,
  deployInstance,
  describeRejectedDeployment,
  describeRuntimeAvailability,
  enrichCrnsWithGeo,
  ensureInstancePortForwards,
  eraseInstanceOnCrn,
  extractInsufficientBalanceMessage,
  extractProxyUrl,
  extractReferenceHashes,
  fetch2n6WebAccessUrl,
  fetchAggregateKey,
  fetchCrnExecutionMap,
  fetchCrns,
  fetchMessageEnvelope,
  fetchPortForwardAggregate,
  fetchRelayMetadataForRuntime,
  fetchSchedulerAllocation,
  fetchUcGoPeerMetadata,
  fetchVmBootstrapConfigAggregate,
  fetchVmBootstrapConfigSignals,
  fetchVmRuntime,
  filterDeployableCrns,
  findCrnByHash,
  forgetAlephMessages,
  inspectDeploymentResult,
  inspectMessageResult,
  isInvalidMessageFormatResponse,
  isRetryableBroadcastFailure,
  isValidSshPublicKey,
  listGeocodedCrns,
  listStaleVmBootstrapConfigAggregateMessageHashes,
  mergePortFlagMaps,
  mergeRequiredPortForwards,
  messageTypeFromEnvelope,
  normalizeBroadcastStatus,
  normalizeExecution,
  normalizeExistingPortForwardEntry,
  normalizeMessageStatus,
  normalizeProxyUrl,
  normalizeSshPublicKey,
  notifyCrnAllocation,
  notifyCrnAllocationWithRetry,
  portForwardLabel,
  postBroadcastPayload,
  probeRootfsGateway,
  publishAggregateKey,
  publishRelayBootstrapRegistration,
  publishVmBootstrapConfig,
  quoteRequiredBudgetUnits,
  rankCandidateCrns,
  reconcileOwnerRelayBootstrapRegistrations,
  requestedPortFlags,
  requiredInstancePortForwards,
  resolveInstanceCrn,
  resolveRootfsReference,
  retainSuccessfulDeployments,
  selectPreferredCrn,
  selectedTier,
  signAlephMessage,
  signaturePayload,
  tierSpec,
  validateRootfsManifest,
  verifyRootfsExists,
  verifyUcGoPeerReachability,
  waitForDeploymentResult,
  waitForRelayBootstrapRegistration,
  waitForSetupEndpoint,
  waitForVmBootstrapConfigSignal,
  waitForVmRuntime
};
