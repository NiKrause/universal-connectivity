// src/react/SponsorRelayFab.tsx
import React from "react";

// src/shared/constants.ts
var DEFAULT_INSTANCE_NAME = "sponsor-relay";
var DEFAULT_MANIFEST_URL = "./rootfs-manifest.json";
var DEFAULT_TIER_ID = "tier-1";
var ROOTFS_MISSING_STATE = {
  tone: "idle",
  label: "manifest missing",
  detail: "Provide a manifest URL or paste manifest JSON."
};
var IDLE_DEPLOYMENT_PROGRESS = {
  stage: "idle",
  label: "Ready",
  progress: 0,
  status: "info",
  itemHash: null,
  detail: null,
  error: null,
  timestamp: Date.now()
};
var REFRESH_INTERVAL_MS = 3e4;
var MANIFEST_SOURCE_REFRESH_DEBOUNCE_MS = 400;
var INSTANCE_RUNTIME_STALE_REFRESH_MS = 5 * 6e4;
var STALE_INSTANCE_ALLOCATION_COOLDOWN_MS = 5 * 60 * 1e3;
var RECENT_INSTANCE_RUNTIME_GRACE_MS = 10 * 60 * 1e3;
var DEPLOYMENT_PENDING_WARNING_MS = 3 * 60 * 1e3;

// src/shared/package-version.ts
var UI_PACKAGE_VERSION = "0.5.1";

// src/shared/format.ts
function shortHash(value, head = 8, tail = 6) {
  if (!value) return "-";
  if (value.length <= head + tail + 3) return value;
  return `${value.slice(0, head)}...${value.slice(-tail)}`;
}
function formatNumber(value, digits = 0) {
  if (value == null || !Number.isFinite(value)) return "-";
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits === 0 ? 0 : Math.min(2, digits)
  }).format(value);
}
function formatDateTime(value) {
  if (!value) return "-";
  const normalizedValue = typeof value === "number" && value > 0 && value < 1e10 ? value * 1e3 : value;
  const date = typeof normalizedValue === "number" ? new Date(normalizedValue) : new Date(normalizedValue);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString();
}
function formatTierSpecLabel(vcpus, memoryMiB, diskMiB) {
  if (vcpus == null || !Number.isFinite(vcpus) || memoryMiB == null || !Number.isFinite(memoryMiB) || diskMiB == null || !Number.isFinite(diskMiB)) {
    return "-";
  }
  return `(${formatNumber(vcpus, 0)} vCPU \xB7 ${formatNumber(memoryMiB / 1024, 1)} GiB RAM \xB7 ${formatNumber(diskMiB / 1024, 0)} GiB disk)`;
}
function buildSshCommand(hostIpv4, mappedPorts2) {
  if (!hostIpv4) return null;
  const sshPort = mappedPorts2.find((entry) => entry.label.startsWith("22/"))?.hostPort ?? 22;
  return `ssh root@${hostIpv4}${sshPort && sshPort !== 22 ? ` -p ${sshPort}` : ""}`;
}
function joinMappedPorts(mappedPorts2) {
  if (mappedPorts2.length === 0) return "-";
  return mappedPorts2.map((entry) => `${entry.label}->${entry.hostPort ?? "?"}`).join(" \xB7 ");
}
function joinRequiredPortForwards(portForwards) {
  if (!portForwards || portForwards.length === 0) return "-";
  return portForwards.map((entry) => {
    const protocols = [
      entry.tcp === true ? "tcp" : null,
      entry.udp === true ? "udp" : null
    ].filter((value) => Boolean(value)).join("/");
    return `${entry.port}/${protocols}`;
  }).join(" \xB7 ");
}

// ../browser/src/http.ts
async function fetchWithTimeout(input, init = {}, timeoutMs = 15e3) {
  const controller = new AbortController();
  const timeout = globalThis.setTimeout(() => controller.abort(), timeoutMs);
  try {
    if (input instanceof URL) {
      const url = new URL(input.toString());
      url.searchParams.set("_ts", String(Date.now()));
      return await fetch(url, {
        ...init,
        cache: init.cache ?? "no-store",
        signal: init.signal ?? controller.signal
      });
    }
    if (typeof input === "string") {
      let requestInput = input;
      try {
        const url = new URL(input, globalThis.location?.href);
        url.searchParams.set("_ts", String(Date.now()));
        requestInput = url;
      } catch {
      }
      return await fetch(requestInput, {
        ...init,
        cache: init.cache ?? "no-store",
        signal: init.signal ?? controller.signal
      });
    }
    return await fetch(input, {
      ...init,
      cache: init.cache ?? "no-store",
      signal: init.signal ?? controller.signal
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error(`Request timed out after ${timeoutMs / 1e3}s.`);
    }
    throw error;
  } finally {
    globalThis.clearTimeout(timeout);
  }
}

// ../browser/src/aleph-api.ts
var DEFAULT_ALEPH_API_HOST = "https://api.aleph.im";
var DEFAULT_CRN_LIST_URL = "https://crns-list.aleph.sh/crns.json";
var DEFAULT_ALEPH_SCHEDULER_API_HOST = "https://scheduler.api.aleph.cloud";
var DEFAULT_2N6_API_HOST = "https://api.2n6.me";
function normalizeMessageStatus(status) {
  if (typeof status !== "string") return "unknown";
  const normalized = status.toLowerCase();
  if (normalized === "processed" || normalized === "pending" || normalized === "rejected") {
    return normalized;
  }
  return "unknown";
}
function asString(value) {
  return typeof value === "string" && value.trim() ? value : null;
}
function asNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function isUnconfirmedNetworkError(error) {
  const message = error instanceof Error ? error.message : String(error);
  return error instanceof TypeError || message.includes("Failed to fetch") || message.includes("Request timed out");
}
function normalizeProxyUrl(value) {
  const stringValue = asString(value);
  if (!stringValue) return null;
  if (/^https?:\/\//i.test(stringValue)) return stringValue;
  return `https://${stringValue}`;
}
function extractProxyUrl(value, networking) {
  const networkingCandidates = [
    networking?.proxy_url,
    networking?.proxyUrl,
    networking?.web_access_url,
    networking?.webAccessUrl,
    networking?.proxy_hostname,
    networking?.proxyHostname,
    networking?.domain,
    networking?.hostname
  ];
  for (const candidate of networkingCandidates) {
    const normalized = normalizeProxyUrl(candidate);
    if (normalized) return normalized;
  }
  for (const entry of [value.web_access, value.webAccess]) {
    const normalized = normalizeProxyUrl(entry?.url) ?? normalizeProxyUrl(entry?.proxy_url) ?? normalizeProxyUrl(entry?.hostname) ?? normalizeProxyUrl(entry?.domain);
    if (normalized) return normalized;
  }
  return null;
}
async function fetchBalance(address, apiHost = DEFAULT_ALEPH_API_HOST) {
  const response = await fetchWithTimeout(`${apiHost}/api/v0/addresses/${address}/balance`, {
    cache: "no-cache"
  });
  if (!response.ok) throw new Error(`Balance request failed: ${response.status}`);
  return await response.json();
}
async function fetchCrns(url = DEFAULT_CRN_LIST_URL) {
  const requestUrl = new URL(url);
  requestUrl.searchParams.set("filter_inactive", "true");
  const response = await fetchWithTimeout(requestUrl, { cache: "no-cache" });
  if (!response.ok) throw new Error(`CRN list request failed: ${response.status}`);
  const payload = await response.json();
  return payload.crns ?? [];
}
async function fetchInstances(address, apiHost = DEFAULT_ALEPH_API_HOST) {
  const url = new URL("/api/v0/messages.json", apiHost);
  url.searchParams.set("msgTypes", "INSTANCE");
  url.searchParams.set("addresses", address);
  url.searchParams.set("message_statuses", "processed,pending,rejected");
  url.searchParams.set("pagination", "100");
  url.searchParams.set("page", "1");
  url.searchParams.set("sortOrder", "-1");
  const response = await fetchWithTimeout(url, { cache: "no-cache" });
  if (!response.ok) throw new Error(`Instance list request failed: ${response.status}`);
  const payload = await response.json();
  return (payload.messages ?? []).map((message) => ({
    ...message,
    status: typeof message.status === "string" && message.status.trim() ? message.status : message.confirmed ? "processed" : "pending"
  }));
}
async function fetch2n6WebAccessUrl(itemHash, twoN6ApiHost = DEFAULT_2N6_API_HOST) {
  const requestUrl = new URL(`/api/hash/${itemHash}`, twoN6ApiHost).toString();
  try {
    const response = await fetchWithTimeout(requestUrl, { cache: "no-cache" });
    if (response.status === 404 || !response.ok) {
      return null;
    }
    const payload = await response.json();
    return normalizeProxyUrl(payload.url ?? payload.subdomain);
  } catch {
    return null;
  }
}
async function fetchSchedulerAllocation(itemHash, schedulerApiHost = DEFAULT_ALEPH_SCHEDULER_API_HOST) {
  const response = await fetchWithTimeout(`${schedulerApiHost}/api/v0/allocation/${itemHash}`, {
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Scheduler allocation request failed: ${response.status}`);
  const payload = await response.json();
  const node = payload.node;
  return {
    source: "scheduler",
    crnUrl: asString(node?.url),
    node: node ? {
      node_id: asString(node.node_id) ?? void 0,
      url: asString(node.url) ?? void 0,
      ipv6: asString(node.ipv6),
      supports_ipv6: typeof node.supports_ipv6 === "boolean" ? node.supports_ipv6 : void 0
    } : null,
    vmIpv6: asString(payload.vm_ipv6),
    period: payload.period ? {
      start_timestamp: asString(payload.period.start_timestamp) ?? void 0,
      duration_seconds: asNumber(payload.period.duration_seconds) ?? void 0
    } : null
  };
}
async function fetchCrnExecutionMap(crnUrl) {
  const normalizedCrnUrl = crnUrl.replace(/\/+$/, "");
  const v2Url = `${normalizedCrnUrl}/v2/about/executions/list`;
  const v1Url = `${normalizedCrnUrl}/about/executions/list`;
  try {
    const v2Response = await fetchWithTimeout(v2Url, { cache: "no-cache" });
    if (v2Response.ok) {
      const payload = await v2Response.json();
      return {
        payload,
        blocked: false,
        requestUrl: v2Url,
        version: "v2"
      };
    }
    if (v2Response.status !== 404) {
      return { payload: null, blocked: false, requestUrl: v2Url, version: "v2" };
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (error instanceof TypeError || message.includes("Failed to fetch")) {
      return { payload: null, blocked: true, requestUrl: v2Url, version: "v2" };
    }
    return { payload: null, blocked: false, requestUrl: v2Url, version: "v2" };
  }
  try {
    const v1Response = await fetchWithTimeout(v1Url, { cache: "no-cache" });
    if (!v1Response.ok) {
      return { payload: null, blocked: false, requestUrl: v1Url, version: "v1" };
    }
    const payload = await v1Response.json();
    return {
      payload,
      blocked: false,
      requestUrl: v1Url,
      version: "v1"
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (error instanceof TypeError || message.includes("Failed to fetch")) {
      return { payload: null, blocked: true, requestUrl: v1Url, version: "v1" };
    }
    return { payload: null, blocked: false, requestUrl: v1Url, version: "v1" };
  }
}
function normalizeExecution(item, crnUrl) {
  const networking = item.networking ?? null;
  const mappedPorts2 = networking && "mapped_ports" in networking && networking.mapped_ports && typeof networking.mapped_ports === "object" ? Object.fromEntries(
    Object.entries(networking.mapped_ports).map(([port, mapping]) => [
      port,
      {
        host: asNumber(mapping?.host) ?? void 0,
        tcp: typeof mapping?.tcp === "boolean" ? mapping.tcp : void 0,
        udp: typeof mapping?.udp === "boolean" ? mapping.udp : void 0
      }
    ])
  ) : void 0;
  if (networking && ("host_ipv4" in networking || "ipv6_ip" in networking || "ipv4_network" in networking)) {
    const v2Item = item;
    return {
      crnUrl,
      version: "v2",
      running: typeof v2Item.running === "boolean" ? v2Item.running : void 0,
      networking: {
        ipv4_network: asString(networking.ipv4_network),
        host_ipv4: asString(networking.host_ipv4),
        ipv6_network: asString(networking.ipv6_network),
        ipv6_ip: asString(networking.ipv6_ip),
        ipv4_ip: asString(networking.ipv4_ip),
        proxy_url: extractProxyUrl(v2Item, networking),
        mapped_ports: mappedPorts2
      },
      status: v2Item.status ? {
        defined_at: asString(v2Item.status.defined_at),
        preparing_at: asString(v2Item.status.preparing_at),
        prepared_at: asString(v2Item.status.prepared_at),
        starting_at: asString(v2Item.status.starting_at),
        started_at: asString(v2Item.status.started_at),
        stopping_at: asString(v2Item.status.stopping_at),
        stopped_at: asString(v2Item.status.stopped_at)
      } : null
    };
  }
  return {
    crnUrl,
    version: "v1",
    networking: {
      ipv4: networking && "ipv4" in networking ? asString(networking.ipv4) : null,
      ipv6: networking && "ipv6" in networking ? asString(networking.ipv6) : null
    },
    status: null
  };
}
async function notifyCrnAllocation(crnUrl, itemHash) {
  const normalizedCrnUrl = crnUrl.replace(/\/+$/, "");
  try {
    const response = await fetchWithTimeout(`${normalizedCrnUrl}/control/allocation/notify`, {
      method: "POST",
      headers: {
        "content-type": "text/plain;charset=UTF-8"
      },
      body: JSON.stringify({ instance: itemHash }),
      mode: "cors"
    });
    if (!response.ok) {
      const responseText = await response.text().catch(() => "");
      throw new Error(`CRN allocation notify failed: ${response.status}${responseText ? ` ${responseText}` : ""}`);
    }
    return { status: "confirmed" };
  } catch (error) {
    if (isUnconfirmedNetworkError(error)) {
      return { status: "unconfirmed" };
    }
    throw error;
  }
}
async function configureOrbitdbRelaySetup(args) {
  const targetUrl = `http://${args.hostIpv4}:${args.setupPort}/configure`;
  try {
    const response = await fetchWithTimeout(
      targetUrl,
      {
        method: "POST",
        headers: {
          "content-type": "text/plain;charset=UTF-8"
        },
        body: JSON.stringify({
          public_ipv4: args.hostIpv4,
          public_ipv6: args.publicIpv6 ?? void 0,
          tcp_port: args.tcpPort,
          ws_port: args.wsPort,
          proxy_url: args.proxyUrl ?? void 0,
          metrics_port: args.metricsPort ?? void 0,
          metrics_https_port: args.metricsHttpsPort ?? void 0,
          webrtc_port: args.webrtcPort ?? void 0,
          quic_port: args.quicPort ?? void 0
        }),
        mode: "cors"
      },
      3e4
    );
    if (!response.ok) {
      const responseText = await response.text().catch(() => "");
      throw new Error(`Relay setup request failed: ${response.status}${responseText ? ` ${responseText}` : ""}`);
    }
    return { status: "configured" };
  } catch (error) {
    if (isUnconfirmedNetworkError(error)) {
      return { status: "unconfirmed" };
    }
    throw error;
  }
}
function messageTypeFromEnvelope(payload) {
  if (!payload) return null;
  const type = payload.type ?? payload.message?.type ?? (Array.isArray(payload.messages) ? payload.messages[0]?.type : void 0);
  return typeof type === "string" ? type.toUpperCase() : null;
}
function extractReferenceHashes(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) return [];
  const errors = details.errors;
  if (!Array.isArray(errors)) return [];
  return errors.filter((value) => typeof value === "string");
}
function extractInsufficientBalanceMessage(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) return null;
  const errors = details.errors;
  const firstError = Array.isArray(errors) && errors[0] && typeof errors[0] === "object" ? errors[0] : null;
  const accountBalance = typeof firstError?.account_balance === "number" || typeof firstError?.account_balance === "string" ? Number(firstError.account_balance) : Number.NaN;
  const requiredBalance = typeof firstError?.required_balance === "number" || typeof firstError?.required_balance === "string" ? Number(firstError.required_balance) : Number.NaN;
  if (!Number.isFinite(accountBalance) || !Number.isFinite(requiredBalance)) {
    return null;
  }
  const shortfall = requiredBalance - accountBalance;
  return shortfall > 0 ? `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required, ${shortfall.toFixed(3)} short` : `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required`;
}
function describeRejectedDeployment(payload, references, rootfsRef) {
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const pendingReferences = references.filter((reference) => reference.status === "pending");
  const missingReferences = references.filter((reference) => reference.status === "missing");
  const rootfsReference = references.find((reference) => reference.itemHash === rootfsRef);
  if (rootfsReference?.status === "pending") {
    return `Aleph rejected this deployment because the referenced rootfs STORE message ${rootfsReference.itemHash} is still pending and cannot yet be used by an instance. Wait for that STORE message to process, then deploy again.`;
  }
  if (pendingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) are still pending: ${pendingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  if (missingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) were not found on Aleph: ${missingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  const insufficientBalanceMessage = extractInsufficientBalanceMessage(payload.details);
  if (insufficientBalanceMessage) {
    return `Aleph rejected this deployment due to ${insufficientBalanceMessage}.`;
  }
  const referencedHashes = extractReferenceHashes(payload.details);
  if (referencedHashes.length > 0) {
    return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}. Referenced message(s): ${referencedHashes.join(", ")}.`;
  }
  return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}.`;
}
async function fetchMessageEnvelope(itemHash, apiHost = DEFAULT_ALEPH_API_HOST) {
  const response = await fetchWithTimeout(`${apiHost}/api/v0/messages/${itemHash}`, {
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Message lookup failed: ${response.status}`);
  return await response.json();
}
async function fetchReference(itemHash, apiHost) {
  const payload = await fetchMessageEnvelope(itemHash, apiHost);
  if (!payload) {
    return {
      itemHash,
      status: "missing",
      type: null
    };
  }
  return {
    itemHash,
    status: normalizeMessageStatus(payload.status),
    type: messageTypeFromEnvelope(payload)
  };
}
async function inspectDeploymentResult(itemHash, rootfsRef, apiHost = DEFAULT_ALEPH_API_HOST) {
  const payload = await fetchMessageEnvelope(itemHash, apiHost);
  if (!payload) {
    return {
      status: "unknown",
      errorCode: null,
      details: null,
      rejectionReason: `Deployment message ${itemHash} was not found on Aleph.`,
      references: []
    };
  }
  const relatedHashes = new Set(rootfsRef ? [rootfsRef] : []);
  for (const referenceHash of extractReferenceHashes(payload.details)) {
    relatedHashes.add(referenceHash);
  }
  const references = await Promise.all(Array.from(relatedHashes).map((hash) => fetchReference(hash, apiHost)));
  const status = normalizeMessageStatus(payload.status);
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  return {
    status,
    errorCode,
    details,
    rejectionReason: status === "rejected" ? describeRejectedDeployment(payload, references, rootfsRef) : null,
    references
  };
}
async function waitForDeploymentResult(itemHash, rootfsRef, apiHost = DEFAULT_ALEPH_API_HOST, attempts = 15, delayMs = 2e3) {
  let lastResult = await inspectDeploymentResult(itemHash, rootfsRef, apiHost);
  for (let attempt = 1; attempt < attempts; attempt += 1) {
    if (lastResult.status === "processed" || lastResult.status === "rejected") {
      return lastResult;
    }
    await new Promise((resolve) => globalThis.setTimeout(resolve, delayMs));
    lastResult = await inspectDeploymentResult(itemHash, rootfsRef, apiHost);
  }
  return lastResult;
}
function isInvalidMessageFormatResponse(response, payload) {
  if (response.status !== 422) return false;
  const details = payload.details;
  if (typeof details === "string" && details.includes("InvalidMessageFormat")) return true;
  if (details && typeof details === "object") {
    const detailMessage = details.message;
    if (typeof detailMessage === "string" && detailMessage.includes("InvalidMessageFormat")) return true;
  }
  return false;
}
async function postBroadcastPayload(body, apiHost) {
  const rawResponse = await fetchWithTimeout(`${apiHost}/api/v0/messages`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  const response = await rawResponse.json().catch(() => ({}));
  return {
    response,
    httpStatus: rawResponse.status,
    rawResponse
  };
}
async function broadcastInstanceMessage(message, apiHost = DEFAULT_ALEPH_API_HOST, sync = false) {
  const attempts = [{ sync, message }, { ...message, sync }, { ...message }];
  for (let index = 0; index < attempts.length; index += 1) {
    const result = await postBroadcastPayload(attempts[index], apiHost);
    if (result.rawResponse.ok || result.httpStatus === 202) {
      return {
        response: result.response,
        httpStatus: result.httpStatus
      };
    }
    const canRetry = index < attempts.length - 1 && isInvalidMessageFormatResponse(result.rawResponse, result.response);
    if (!canRetry) {
      throw new Error(`Broadcast failed: ${result.httpStatus} ${JSON.stringify(result.response)}`);
    }
  }
  throw new Error("Broadcast failed: no compatible request format was accepted");
}
async function broadcastAlephMessage(message, apiHost = DEFAULT_ALEPH_API_HOST, sync = false) {
  return broadcastInstanceMessage(message, apiHost, sync);
}

// ../browser/src/rootfs.ts
var ITEM_HASH_RE = /^[a-fA-F0-9]{64}$/u;
var DEFAULT_ROOTFS_MANIFEST_URL = "./rootfs-manifest.json";
var DEFAULT_IPFS_GATEWAY_BASE_URL = "https://ipfs.aleph.cloud/ipfs/";
function resolveManifestUrl(input, baseUrl) {
  if (input instanceof URL) return input;
  try {
    return new URL(input, baseUrl ? String(baseUrl) : globalThis.location?.href);
  } catch {
    return input;
  }
}
function validateRootfsManifest(manifest) {
  const errors = [];
  if (!manifest) {
    return { manifest, valid: false, errors: ["Rootfs manifest is missing."] };
  }
  if (!manifest.version) errors.push("Rootfs manifest version is missing.");
  if (manifest.rootfsInstallStrategy != null && manifest.rootfsInstallStrategy !== "thin" && manifest.rootfsInstallStrategy !== "prebaked") {
    errors.push('Rootfs install strategy must be "thin" or "prebaked" when provided.');
  }
  if (manifest.requiresBootstrapNetwork != null && typeof manifest.requiresBootstrapNetwork !== "boolean") {
    errors.push("Rootfs bootstrap network flag must be a boolean when provided.");
  }
  if (manifest.bootstrapSummary != null && !manifest.bootstrapSummary.trim()) {
    errors.push("Rootfs bootstrap summary must be non-empty when provided.");
  }
  if (manifest.requiredPortForwards != null) {
    if (!Array.isArray(manifest.requiredPortForwards)) {
      errors.push("Rootfs required port forwards must be an array when provided.");
    } else {
      manifest.requiredPortForwards.forEach((entry, index) => {
        if (!entry || typeof entry !== "object") {
          errors.push(`Rootfs required port forward #${index + 1} must be an object.`);
          return;
        }
        if (!Number.isInteger(entry.port) || entry.port < 1 || entry.port > 65535) {
          errors.push(`Rootfs required port forward #${index + 1} must use a TCP/UDP port between 1 and 65535.`);
        }
        if (entry.tcp !== true && entry.udp !== true) {
          errors.push(`Rootfs required port forward #${index + 1} must enable TCP or UDP.`);
        }
        if (entry.purpose != null && (typeof entry.purpose !== "string" || !entry.purpose.trim())) {
          errors.push(`Rootfs required port forward #${index + 1} purpose must be non-empty when provided.`);
        }
      });
    }
  }
  if (!ITEM_HASH_RE.test(manifest.rootfsItemHash || "")) {
    errors.push("Rootfs ItemHash must be a 64 character hex value.");
  }
  if (!Number.isInteger(manifest.rootfsSizeMiB) || manifest.rootfsSizeMiB <= 0) {
    errors.push("Rootfs size must be a positive MiB integer.");
  }
  if (manifest.rootfsSourceSizeBytes != null && (!Number.isInteger(manifest.rootfsSourceSizeBytes) || manifest.rootfsSourceSizeBytes <= 0)) {
    errors.push("Rootfs source size must be a positive byte integer when provided.");
  }
  if (!manifest.createdAt || Number.isNaN(new Date(manifest.createdAt).getTime())) {
    errors.push("Rootfs creation date is missing or invalid.");
  }
  return { manifest, valid: errors.length === 0, errors };
}
async function loadRootfsManifest(url = DEFAULT_ROOTFS_MANIFEST_URL, options = {}) {
  const response = await fetchWithTimeout(resolveManifestUrl(url, options.baseUrl), { cache: "no-cache" });
  if (!response.ok) {
    throw new Error(`Rootfs manifest request failed: ${response.status}`);
  }
  return validateRootfsManifest(await response.json());
}
async function verifyRootfsExists(itemHash, apiHost = DEFAULT_ALEPH_API_HOST) {
  if (!ITEM_HASH_RE.test(itemHash)) return false;
  const response = await fetchWithTimeout(`${apiHost}/api/v0/messages/${itemHash}`, {
    method: "GET",
    cache: "no-cache"
  });
  if (response.status === 404) return false;
  if (!response.ok) throw new Error(`Rootfs lookup failed: ${response.status}`);
  const payload = await response.json();
  const firstMessage = Array.isArray(payload.messages) ? payload.messages[0] : void 0;
  const type = String(payload.type || payload.message?.type || firstMessage?.type || "").toUpperCase();
  return type === "STORE";
}
function normalizeStatus(status) {
  if (typeof status !== "string") return "unknown";
  const normalized = status.toLowerCase();
  if (normalized === "processed" || normalized === "pending" || normalized === "rejected") {
    return normalized;
  }
  return "unknown";
}
function parseCidFromPayload(payload) {
  const firstMessage = Array.isArray(payload.messages) && payload.messages[0] && typeof payload.messages[0] === "object" ? payload.messages[0] : null;
  const directContent = firstMessage?.content && typeof firstMessage.content === "object" ? firstMessage.content : null;
  if (typeof directContent?.item_hash === "string") {
    return directContent.item_hash;
  }
  if (typeof firstMessage?.item_content === "string") {
    try {
      const itemContent = JSON.parse(firstMessage.item_content);
      if (typeof itemContent.item_hash === "string") {
        return itemContent.item_hash;
      }
    } catch {
      return null;
    }
  }
  return null;
}
function parseRejectionReason(payload) {
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  const rawErrors = Array.isArray(details?.errors) ? details.errors : [];
  const firstError = rawErrors[0] && typeof rawErrors[0] === "object" ? rawErrors[0] : null;
  if (firstError) {
    const accountBalance = Number(firstError.account_balance);
    const requiredBalance = Number(firstError.required_balance);
    if (Number.isFinite(accountBalance) && Number.isFinite(requiredBalance)) {
      const shortfall = requiredBalance - accountBalance;
      return {
        rejectionErrorCode: errorCode,
        rejectionReason: shortfall > 0 ? `Rejected by Aleph for insufficient hold balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required, ${shortfall.toFixed(3)} short.` : `Rejected by Aleph for insufficient hold balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required.`
      };
    }
  }
  return {
    rejectionErrorCode: errorCode,
    rejectionReason: errorCode != null ? `Rejected by Aleph (error code ${errorCode}).` : null
  };
}
async function probeGateway(cid, gatewayBaseUrl = DEFAULT_IPFS_GATEWAY_BASE_URL) {
  const gatewayUrl = new URL(cid, gatewayBaseUrl).toString();
  try {
    const response = await fetchWithTimeout(gatewayUrl, { method: "HEAD", cache: "no-store" }, 5e3);
    return {
      gatewayUrl,
      gatewayStatus: response.ok ? "reachable" : "error",
      gatewayError: response.ok ? null : `Gateway responded with ${response.status}.`
    };
  } catch (error) {
    if (error instanceof Error && error.message.includes("timed out")) {
      return {
        gatewayUrl,
        gatewayStatus: "timeout",
        gatewayError: error.message
      };
    }
    return {
      gatewayUrl,
      gatewayStatus: "unavailable",
      gatewayError: error instanceof Error ? error.message : String(error)
    };
  }
}
async function resolveRootfsReference(itemHash, apiHost = DEFAULT_ALEPH_API_HOST, gatewayBaseUrl = DEFAULT_IPFS_GATEWAY_BASE_URL) {
  if (!ITEM_HASH_RE.test(itemHash)) return null;
  const response = await fetchWithTimeout(`${apiHost}/api/v0/messages/${itemHash}`, {
    method: "GET",
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Rootfs lookup failed: ${response.status}`);
  const payload = await response.json();
  const firstMessage = Array.isArray(payload.messages) && payload.messages[0] && typeof payload.messages[0] === "object" ? payload.messages[0] : null;
  const messageObject = payload.message && typeof payload.message === "object" ? payload.message : null;
  const cid = parseCidFromPayload(payload);
  const rejection = normalizeStatus(payload.status) === "rejected" ? parseRejectionReason(payload) : { rejectionErrorCode: null, rejectionReason: null };
  const gateway = cid ? await probeGateway(cid, gatewayBaseUrl) : { gatewayUrl: null, gatewayStatus: "unknown", gatewayError: null };
  return {
    itemHash,
    messageStatus: normalizeStatus(payload.status),
    messageType: String(payload.type || messageObject?.type || firstMessage?.type || "").toUpperCase() || null,
    cid,
    receptionTime: typeof payload.reception_time === "string" ? payload.reception_time : null,
    rejectionErrorCode: rejection.rejectionErrorCode,
    rejectionReason: rejection.rejectionReason,
    gatewayUrl: gateway.gatewayUrl,
    gatewayStatus: gateway.gatewayStatus,
    gatewayError: gateway.gatewayError
  };
}

// src/shared/manifest-source.ts
function resolveManifestSource(args) {
  const trimmed = args.manifestJson.trim();
  if (!trimmed) return null;
  try {
    return validateRootfsManifest(JSON.parse(trimmed));
  } catch (error) {
    return {
      manifest: null,
      valid: false,
      errors: [error instanceof Error ? error.message : String(error)]
    };
  }
}

// src/shared/wallet-controller.ts
import { getAddress } from "viem";
function getEthereumProvider() {
  return globalThis.window?.ethereum ?? null;
}
function toChecksumAddress(address) {
  try {
    return getAddress(address);
  } catch {
    throw new Error("Invalid EVM address.");
  }
}
async function connectWallet(provider = getEthereumProvider()) {
  if (!provider) {
    throw new Error("MetaMask provider not found.");
  }
  const accounts = await provider.request({
    method: "eth_requestAccounts"
  });
  const chainId = await provider.request({ method: "eth_chainId" });
  const address = accounts[0] ? toChecksumAddress(accounts[0]) : null;
  return {
    connected: Boolean(address),
    address,
    chainId,
    isMetaMask: Boolean(provider.isMetaMask)
  };
}
async function personalSign(address, message, provider = getEthereumProvider()) {
  if (!provider) {
    throw new Error("MetaMask provider not found.");
  }
  const payload = `0x${Array.from(new TextEncoder().encode(message)).map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
  return provider.request({
    method: "personal_sign",
    params: [payload, address]
  });
}
function watchWallet(onChange, provider = getEthereumProvider()) {
  if (!provider?.on || !provider?.removeListener) {
    return () => {
    };
  }
  provider.on("accountsChanged", onChange);
  provider.on("chainChanged", onChange);
  return () => {
    provider.removeListener?.("accountsChanged", onChange);
    provider.removeListener?.("chainChanged", onChange);
  };
}

// ../browser/src/client.ts
function createAlephBrowserClient(options = {}) {
  const apiHost = options.apiHost ?? DEFAULT_ALEPH_API_HOST;
  const crnListUrl = options.crnListUrl ?? DEFAULT_CRN_LIST_URL;
  const schedulerApiHost = options.schedulerApiHost ?? DEFAULT_ALEPH_SCHEDULER_API_HOST;
  const twoN6ApiHost = options.twoN6ApiHost ?? DEFAULT_2N6_API_HOST;
  return {
    apiHost,
    crnListUrl,
    schedulerApiHost,
    fetchBalance(address) {
      return fetchBalance(address, apiHost);
    },
    fetchCrns() {
      return fetchCrns(crnListUrl);
    },
    fetchInstances(address) {
      return fetchInstances(address, apiHost);
    },
    fetch2n6WebAccessUrl(itemHash) {
      return fetch2n6WebAccessUrl(itemHash, twoN6ApiHost);
    },
    fetchMessageEnvelope(itemHash) {
      return fetchMessageEnvelope(itemHash, apiHost);
    },
    fetchSchedulerAllocation(itemHash) {
      return fetchSchedulerAllocation(itemHash, schedulerApiHost);
    },
    fetchCrnExecutionMap(crnUrl) {
      return fetchCrnExecutionMap(crnUrl);
    },
    notifyCrnAllocation(crnUrl, itemHash) {
      return notifyCrnAllocation(crnUrl, itemHash);
    },
    configureOrbitdbRelaySetup(args) {
      return configureOrbitdbRelaySetup(args);
    },
    inspectDeploymentResult(itemHash, rootfsRef) {
      return inspectDeploymentResult(itemHash, rootfsRef, apiHost);
    },
    waitForDeploymentResult(itemHash, rootfsRef, attempts, delayMs) {
      return waitForDeploymentResult(itemHash, rootfsRef, apiHost, attempts, delayMs);
    },
    broadcastInstanceMessage(message, sync) {
      return broadcastInstanceMessage(message, apiHost, sync);
    },
    broadcastAlephMessage(message, sync) {
      return broadcastAlephMessage(message, apiHost, sync);
    }
  };
}

// ../browser/src/pricing.ts
var DEFAULT_ALEPH_AGGREGATE_ADDRESS = "0xFba561a84A537fCaa567bb7A2257e7142701ae2A";
function parseInstancePricing(payload) {
  const data = payload;
  const pricing = data.data?.pricing ?? data.pricing;
  const instance = pricing?.instance;
  if (!instance?.price?.compute_unit || !instance.compute_unit || !Array.isArray(instance.tiers)) {
    throw new Error("Aleph pricing aggregate does not contain instance pricing.");
  }
  return instance;
}
async function fetchInstancePricing(apiHost = DEFAULT_ALEPH_API_HOST, aggregateAddress = DEFAULT_ALEPH_AGGREGATE_ADDRESS) {
  const response = await fetchWithTimeout(`${apiHost}/api/v0/aggregates/${aggregateAddress}.json?keys=pricing`, {
    cache: "no-cache"
  });
  if (!response.ok) {
    throw new Error(`Pricing aggregate request failed: ${response.status}`);
  }
  const payload = await response.json();
  const pricingAggregate = payload.data?.pricing;
  if (!pricingAggregate) {
    throw new Error("Pricing aggregate response did not include a pricing key.");
  }
  return {
    pricing: parseInstancePricing({ pricing: pricingAggregate }),
    fetchedAt: Date.now()
  };
}

// ../core/src/constants.ts
var DEFAULT_ALEPH_CHANNEL = "TEST";

// ../core/src/manifests.ts
var DEFAULT_ALEPH_API_HOST2 = "https://api.aleph.im";

// ../core/src/crns.ts
var DEFAULT_CRN_LIST_URL2 = "https://crns-list.aleph.sh/crns.json";
function compatibleCrns(crns, excludedHashes = []) {
  const excluded = new Set(excludedHashes.filter(Boolean));
  return [...crns].filter((crn) => {
    if (!crn?.hash || excluded.has(crn.hash)) return false;
    if (crn.qemu_support === false) return false;
    if (crn.system_usage?.active === false) return false;
    return true;
  });
}
function hasCrnCapacity(crn, spec) {
  if (!spec) return true;
  const usage = crn.system_usage;
  if (!usage) return true;
  const cpuOk = usage.cpu?.count == null || usage.cpu.count >= spec.vcpus;
  const memoryOk = usage.mem?.available_kB == null || usage.mem.available_kB >= spec.memoryMiB * 1024;
  const diskOk = usage.disk?.available_kB == null || usage.disk.available_kB >= spec.diskMiB * 1024;
  return cpuOk && memoryOk && diskOk;
}
function scoreSortedCrns(crns) {
  return [...crns].sort((left, right) => {
    const rightScore = typeof right.score === "number" ? right.score : Number(right.score ?? Number.NEGATIVE_INFINITY);
    const leftScore = typeof left.score === "number" ? left.score : Number(left.score ?? Number.NEGATIVE_INFINITY);
    if (rightScore !== leftScore) return rightScore - leftScore;
    const leftName = (left.name || left.address || left.hash).toLowerCase();
    const rightName = (right.name || right.address || right.hash).toLowerCase();
    return leftName.localeCompare(rightName);
  });
}
function filterDeployableCrns(crns, options = {}) {
  return scoreSortedCrns(
    compatibleCrns(crns, options.excludedHashes).filter((crn) => hasCrnCapacity(crn, options.spec))
  );
}
async function fetchCrns2(options) {
  const requestUrl = new URL(options.url ?? DEFAULT_CRN_LIST_URL2);
  requestUrl.searchParams.set("filter_inactive", "true");
  const response = await options.fetch(requestUrl.toString(), {
    cache: "no-cache"
  });
  if (!response.ok) {
    throw new Error(`CRN list request failed: ${response.status}`);
  }
  const payload = await response.json();
  return Array.isArray(payload?.crns) ? payload.crns : [];
}

// ../core/src/port-forwarding.ts
var DEFAULT_INSTANCE_PORT_FORWARDS = [
  { port: 22, tcp: true, udp: false, purpose: "SSH" }
];
function normalizeRequestedPort(entry) {
  return {
    port: entry.port,
    tcp: entry.tcp === true,
    udp: entry.udp === true,
    purpose: entry.purpose?.trim() || void 0
  };
}
function normalizePortFlags(value) {
  if (!value || typeof value !== "object") return null;
  const candidate = value;
  return {
    tcp: candidate.tcp === true,
    udp: candidate.udp === true
  };
}
function normalizeExistingPortForwardEntry(entry) {
  if (!entry?.ports || typeof entry.ports !== "object") return {};
  return Object.fromEntries(
    Object.entries(entry.ports).map(([port, flags]) => [port, normalizePortFlags(flags)]).filter((item) => item[1] != null)
  );
}
function requestedPortFlags(portForwards) {
  return Object.fromEntries(
    portForwards.map((entry) => [
      String(entry.port),
      {
        tcp: entry.tcp === true,
        udp: entry.udp === true
      }
    ])
  );
}
function mergePortFlagMaps(existing, requested) {
  const merged = /* @__PURE__ */ new Map();
  for (const [port, flags] of Object.entries(existing)) {
    merged.set(port, {
      tcp: flags.tcp === true,
      udp: flags.udp === true
    });
  }
  for (const [port, flags] of Object.entries(requested)) {
    const current = merged.get(port);
    merged.set(port, {
      tcp: current?.tcp === true || flags.tcp === true,
      udp: current?.udp === true || flags.udp === true
    });
  }
  return Object.fromEntries([...merged.entries()].sort((left, right) => Number(left[0]) - Number(right[0])));
}
function mergeRequiredPortForwards(...groups) {
  const merged = /* @__PURE__ */ new Map();
  for (const group of groups) {
    for (const entry of group ?? []) {
      const normalized = normalizeRequestedPort(entry);
      const current = merged.get(normalized.port);
      merged.set(normalized.port, {
        port: normalized.port,
        tcp: current?.tcp === true || normalized.tcp === true,
        udp: current?.udp === true || normalized.udp === true,
        purpose: current?.purpose ?? normalized.purpose
      });
    }
  }
  return [...merged.values()].sort((left, right) => left.port - right.port);
}
function requiredInstancePortForwards(manifest) {
  return mergeRequiredPortForwards(DEFAULT_INSTANCE_PORT_FORWARDS, manifest?.requiredPortForwards);
}
async function fetchPortForwardAggregate(address, options) {
  const requestUrl = new URL(`/api/v0/aggregates/${address}.json`, options.apiHost ?? DEFAULT_ALEPH_API_HOST2);
  requestUrl.searchParams.set("keys", "port-forwarding");
  const response = await options.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (response.status === 404) return {};
  if (!response.ok) {
    throw new Error(`Port-forward aggregate request failed: ${response.status}`);
  }
  const payload = await response.json();
  const aggregate = payload.data?.["port-forwarding"];
  if (!aggregate || typeof aggregate !== "object" || Array.isArray(aggregate)) return {};
  return aggregate;
}

// ../core/src/aleph-normalizers.ts
function asString2(value) {
  return typeof value === "string" && value.trim() ? value : null;
}
function asNumber2(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function normalizeMessageStatus2(status) {
  if (typeof status !== "string") return "unknown";
  const normalized = status.toLowerCase();
  if (normalized === "processed" || normalized === "pending" || normalized === "rejected") {
    return normalized;
  }
  return "unknown";
}
function normalizeProxyUrl2(value) {
  const stringValue = asString2(value);
  if (!stringValue) return null;
  if (/^https?:\/\//i.test(stringValue)) return stringValue;
  return `https://${stringValue}`;
}
function messageTypeFromEnvelope2(payload) {
  if (!payload) return null;
  const type = payload.type ?? payload.message?.type ?? (Array.isArray(payload.messages) ? payload.messages[0]?.type : void 0);
  return typeof type === "string" ? type.toUpperCase() : null;
}
function extractReferenceHashes2(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) return [];
  const errors = details.errors;
  if (!Array.isArray(errors)) return [];
  return errors.filter((value) => typeof value === "string");
}
function extractInsufficientBalanceMessage2(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) {
    return null;
  }
  const errors = details.errors;
  const firstError = Array.isArray(errors) && errors[0] && typeof errors[0] === "object" ? errors[0] : null;
  const accountBalance = typeof firstError?.account_balance === "number" || typeof firstError?.account_balance === "string" ? Number(firstError.account_balance) : Number.NaN;
  const requiredBalance = typeof firstError?.required_balance === "number" || typeof firstError?.required_balance === "string" ? Number(firstError.required_balance) : Number.NaN;
  if (!Number.isFinite(accountBalance) || !Number.isFinite(requiredBalance)) {
    return null;
  }
  const shortfall = requiredBalance - accountBalance;
  return shortfall > 0 ? `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required, ${shortfall.toFixed(3)} short` : `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required`;
}
function describeRejectedDeployment2(payload, references, rootfsRef) {
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const pendingReferences = references.filter((reference) => reference.status === "pending");
  const missingReferences = references.filter((reference) => reference.status === "missing");
  const rootfsReference = references.find((reference) => reference.itemHash === rootfsRef);
  if (rootfsReference?.status === "pending") {
    return `Aleph rejected this deployment because the referenced rootfs STORE message ${rootfsReference.itemHash} is still pending and cannot yet be used by an instance. Wait for that STORE message to process, then deploy again.`;
  }
  if (pendingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) are still pending: ${pendingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  if (missingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) were not found on Aleph: ${missingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  const insufficientBalanceMessage = extractInsufficientBalanceMessage2(payload.details);
  if (insufficientBalanceMessage) {
    return `Aleph rejected this deployment due to ${insufficientBalanceMessage}.`;
  }
  const referencedHashes = extractReferenceHashes2(payload.details);
  if (referencedHashes.length > 0) {
    return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}. Referenced message(s): ${referencedHashes.join(", ")}.`;
  }
  return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}.`;
}
function extractProxyUrl2(item, networking) {
  const networkingCandidates = [
    networking?.proxy_url,
    networking?.proxyUrl,
    networking?.web_access_url,
    networking?.webAccessUrl,
    networking?.proxy_hostname,
    networking?.proxyHostname,
    networking?.domain,
    networking?.hostname
  ];
  for (const candidate of networkingCandidates) {
    const normalized = normalizeProxyUrl2(candidate);
    if (normalized) return normalized;
  }
  const webAccessCandidates = [item.web_access, item.webAccess];
  for (const entry of webAccessCandidates) {
    const normalized = normalizeProxyUrl2(entry?.url) ?? normalizeProxyUrl2(entry?.proxy_url) ?? normalizeProxyUrl2(entry?.hostname) ?? normalizeProxyUrl2(entry?.domain);
    if (normalized) return normalized;
  }
  return null;
}
function normalizeExecution2(item, crnUrl) {
  const networking = item.networking ?? null;
  const mappedPorts2 = networking && "mapped_ports" in networking && networking.mapped_ports && typeof networking.mapped_ports === "object" ? Object.fromEntries(
    Object.entries(networking.mapped_ports).map(([port, mapping]) => [
      port,
      {
        host: asNumber2(mapping?.host) ?? void 0,
        tcp: typeof mapping?.tcp === "boolean" ? mapping.tcp : void 0,
        udp: typeof mapping?.udp === "boolean" ? mapping.udp : void 0
      }
    ])
  ) : void 0;
  if (networking && ("host_ipv4" in networking || "ipv6_ip" in networking || "ipv4_network" in networking)) {
    const v2Item = item;
    return {
      crnUrl,
      version: "v2",
      running: typeof v2Item.running === "boolean" ? v2Item.running : void 0,
      networking: {
        ipv4_network: asString2(networking.ipv4_network),
        host_ipv4: asString2(networking.host_ipv4),
        ipv6_network: asString2(networking.ipv6_network),
        ipv6_ip: asString2(networking.ipv6_ip),
        ipv4_ip: asString2(networking.ipv4_ip),
        proxy_url: extractProxyUrl2(v2Item, networking),
        mapped_ports: mappedPorts2
      },
      status: v2Item.status ? {
        defined_at: asString2(v2Item.status.defined_at),
        preparing_at: asString2(v2Item.status.preparing_at),
        prepared_at: asString2(v2Item.status.prepared_at),
        starting_at: asString2(v2Item.status.starting_at),
        started_at: asString2(v2Item.status.started_at),
        stopping_at: asString2(v2Item.status.stopping_at),
        stopped_at: asString2(v2Item.status.stopped_at)
      } : null
    };
  }
  return {
    crnUrl,
    version: "v1",
    networking: {
      ipv4: networking && "ipv4" in networking ? asString2(networking.ipv4) : null,
      ipv6: networking && "ipv6" in networking ? asString2(networking.ipv6) : null
    },
    status: null
  };
}

// ../core/src/deployment-inspection.ts
async function fetchMessageEnvelope2(itemHash, options) {
  const response = await options.fetch(`${options.apiHost ?? DEFAULT_ALEPH_API_HOST2}/api/v0/messages/${itemHash}`, {
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Message lookup failed: ${response.status}`);
  return await response.json();
}
async function fetchReference2(itemHash, options) {
  const payload = await fetchMessageEnvelope2(itemHash, options);
  if (!payload) {
    return {
      itemHash,
      status: "missing",
      type: null
    };
  }
  return {
    itemHash,
    status: normalizeMessageStatus2(payload.status),
    type: messageTypeFromEnvelope2(payload)
  };
}
async function inspectDeploymentResult2(itemHash, options) {
  const payload = await fetchMessageEnvelope2(itemHash, options);
  if (!payload) {
    return {
      status: "unknown",
      errorCode: null,
      details: null,
      rejectionReason: `Deployment message ${itemHash} was not found on Aleph.`,
      references: []
    };
  }
  const relatedHashes = new Set(options.rootfsRef ? [options.rootfsRef] : []);
  for (const referenceHash of extractReferenceHashes2(payload.details)) {
    relatedHashes.add(referenceHash);
  }
  const references = await Promise.all(
    Array.from(relatedHashes).map((hash) => fetchReference2(hash, options))
  );
  const status = normalizeMessageStatus2(payload.status);
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  return {
    status,
    errorCode,
    details,
    rejectionReason: status === "rejected" ? describeRejectedDeployment2(payload, references, options.rootfsRef) : null,
    references
  };
}
async function waitForDeploymentResult2(itemHash, options) {
  const attempts = Math.max(1, Number(options.attempts ?? 15));
  const delayMs = Math.max(0, Number(options.delayMs ?? 2e3));
  const sleep2 = options.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastResult = await inspectDeploymentResult2(itemHash, options);
  options.onAttempt?.(lastResult, 1, attempts);
  for (let attempt = 1; attempt < attempts; attempt += 1) {
    if (lastResult.status === "processed" || lastResult.status === "rejected") {
      return lastResult;
    }
    await sleep2(delayMs);
    lastResult = await inspectDeploymentResult2(itemHash, options);
    options.onAttempt?.(lastResult, attempt + 1, attempts);
  }
  return lastResult;
}

// ../core/src/broadcast.ts
function signaturePayload(message) {
  return [message.chain, message.sender, message.type, message.item_hash].join("\n");
}
async function signAlephMessage(unsignedMessage, signer) {
  const signature = await signer(unsignedMessage.sender, signaturePayload(unsignedMessage));
  return {
    ...unsignedMessage,
    signature: signature.startsWith("0x") ? signature : `0x${signature}`
  };
}
function normalizeBroadcastStatus(httpStatus, responseStatus) {
  if (httpStatus === 202) return "pending";
  return normalizeMessageStatus2(responseStatus);
}
function isRetryableBroadcastFailure(response, payload) {
  if (response.status >= 500) return true;
  const publicationStatus = payload?.publication_status?.status;
  if (typeof publicationStatus === "string" && publicationStatus.toLowerCase() === "error") {
    return true;
  }
  return false;
}
async function postBroadcastPayload2(body, options) {
  const rawResponse = await options.fetch(`${options.apiHost ?? DEFAULT_ALEPH_API_HOST2}/api/v0/messages`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  const response = await rawResponse.json().catch(() => ({}));
  return {
    response,
    httpStatus: rawResponse.status
  };
}
async function broadcastAlephMessage2(message, options) {
  const requestBody = { sync: options.sync ?? false, message };
  const maxAttempts = 3;
  for (let index = 0; index < maxAttempts; index += 1) {
    const result = await postBroadcastPayload2(requestBody, {
      apiHost: options.apiHost,
      fetch: options.fetch
    });
    if (result.httpStatus === 202 || normalizeBroadcastStatus(result.httpStatus, result.response?.message_status) !== "unknown" || result.httpStatus >= 200 && result.httpStatus < 300) {
      return result;
    }
    const canRetry = index < maxAttempts - 1 && isRetryableBroadcastFailure({ status: result.httpStatus }, result.response);
    if (!canRetry) {
      throw new Error(`Broadcast failed: ${result.httpStatus} ${JSON.stringify(result.response ?? {})}`);
    }
  }
  throw new Error("Broadcast failed: retry budget exhausted");
}

// ../core/src/runtime.ts
var DEFAULT_SCHEDULER_ALLOCATION_URL = "https://scheduler.api.aleph.cloud/api/v0/allocation";
var DEFAULT_TWO_N_SIX_HASH_URL = "https://api.2n6.me/api/hash";
function asString3(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function asNumber3(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function normalizeIpv6(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  if (!normalized) return null;
  const zoneIndex = normalized.indexOf("%");
  return zoneIndex >= 0 ? normalized.slice(0, zoneIndex) : normalized;
}
function isLikelyGlobalIpv6(value) {
  const normalized = normalizeIpv6(value);
  if (!normalized || normalized === "::" || normalized === "::1") return false;
  const firstHextetText = normalized.split(":", 1)[0];
  if (!firstHextetText) return false;
  const firstHextet = Number.parseInt(firstHextetText, 16);
  if (!Number.isFinite(firstHextet)) return false;
  if ((firstHextet & 65024) === 64512) return false;
  if ((firstHextet & 65472) === 65152) return false;
  if ((firstHextet & 65280) === 65280) return false;
  if ((firstHextet & 65472) === 65216) return false;
  return true;
}
function findCrnByHash(crns, crnHash) {
  return crns.find((crn) => crn.hash === crnHash) ?? null;
}
async function fetchSchedulerAllocation2(itemHash, options) {
  const response = await options.fetch(
    `${options.schedulerAllocationUrl ?? DEFAULT_SCHEDULER_ALLOCATION_URL}/${itemHash}`,
    { cache: "no-cache" }
  );
  if (response.status === 404) return null;
  if (!response.ok) {
    throw new Error(`Scheduler allocation request failed: ${response.status}`);
  }
  const payload = await response.json();
  const node = payload?.node;
  return {
    source: "scheduler",
    crnHash: asString3(node?.node_id),
    crnUrl: asString3(node?.url),
    node: node ? {
      node_id: asString3(node.node_id) ?? void 0,
      url: asString3(node.url) ?? void 0,
      ipv6: asString3(node.ipv6),
      supports_ipv6: typeof node.supports_ipv6 === "boolean" ? node.supports_ipv6 : void 0
    } : null,
    vmIpv6: asString3(payload?.vm_ipv6),
    period: payload?.period ? {
      start_timestamp: asString3(payload.period.start_timestamp) ?? void 0,
      duration_seconds: asNumber3(payload.period.duration_seconds) ?? void 0
    } : null
  };
}
async function fetch2n6WebAccessUrl2(itemHash, options) {
  const response = await options.fetch(
    `${options.twoN6HashUrl ?? DEFAULT_TWO_N_SIX_HASH_URL}/${itemHash}`,
    { cache: "no-cache" }
  );
  if (!response.ok) return null;
  const payload = await response.json();
  return {
    url: normalizeProxyUrl2(payload?.url ?? payload?.subdomain),
    active: typeof payload?.active === "boolean" ? payload.active : null,
    subdomain: asString3(payload?.subdomain)
  };
}
async function fetchCrnExecutionMap2(crnUrl, options) {
  const normalizedCrnUrl = String(crnUrl).replace(/\/+$/, "");
  for (const [version, suffix] of [
    ["v2", "/v2/about/executions/list"],
    ["v1", "/about/executions/list"]
  ]) {
    const requestUrl = `${normalizedCrnUrl}${suffix}`;
    const response = await options.fetch(requestUrl, {
      cache: "no-cache"
    });
    if (response.ok) {
      const payload = await response.json();
      return {
        version,
        payload: payload && typeof payload === "object" ? payload : null,
        requestUrl
      };
    }
    if (response.status !== 404) {
      return {
        version,
        payload: null,
        requestUrl
      };
    }
  }
  return {
    version: "v2",
    payload: null,
    requestUrl: `${normalizedCrnUrl}/v2/about/executions/list`
  };
}
function describeRuntimeAvailability(runtime) {
  const execution = runtime.execution ?? null;
  const mappedPorts2 = runtime.mappedPorts ?? {};
  const hostIpv4 = runtime.hostIpv4 ?? null;
  const ipv6 = runtime.ipv6 ?? null;
  const executionGuestIpv6 = execution?.networking?.ipv6_ip ?? null;
  const proxyUrl = runtime.proxyUrl ?? null;
  const schedulerSource = runtime.allocation?.source ?? null;
  const webAccessActive = runtime.webAccess?.active ?? null;
  const mappedPortCount = Object.keys(mappedPorts2).length;
  if (hostIpv4 && mappedPortCount > 0 && runtime.requirePublicGuestIpv6ForProxy === true && proxyUrl && executionGuestIpv6 && !isLikelyGlobalIpv6(executionGuestIpv6)) {
    return {
      state: "execution-invalid-public-ipv6",
      reason: `The CRN exposed runtime networking, but the guest IPv6 (${executionGuestIpv6}) is not globally routable. Proxy-backed HTTPS activation cannot succeed until the CRN reports a public guest IPv6.`,
      schedulerSource,
      executionSeen: Boolean(execution),
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (hostIpv4 && mappedPortCount > 0) {
    return {
      state: "ready",
      reason: null,
      schedulerSource,
      executionSeen: Boolean(execution),
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (!execution && proxyUrl && webAccessActive === false) {
    return {
      state: "proxy-reserved-inactive",
      reason: "Aleph reserved a proxy URL for the VM, but it is still inactive and the selected CRN has not exposed execution networking yet.",
      schedulerSource,
      executionSeen: false,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (!execution && schedulerSource === "manual") {
    return {
      state: "crn-execution-missing",
      reason: "The deployment is pinned to a specific CRN, but that CRN is not exposing this VM in its execution list yet.",
      schedulerSource,
      executionSeen: false,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (execution && !hostIpv4) {
    return {
      state: "execution-missing-host-ipv4",
      reason: "The CRN exposed an execution record, but it does not include a public host IPv4 yet.",
      schedulerSource,
      executionSeen: true,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  if (execution && mappedPortCount === 0) {
    return {
      state: "execution-missing-port-mappings",
      reason: "The CRN exposed an execution record, but mapped ports are still empty.",
      schedulerSource,
      executionSeen: true,
      webAccessActive,
      mappedPortCount,
      proxyUrl
    };
  }
  return {
    state: "runtime-pending",
    reason: "Aleph has not exposed enough runtime networking details yet.",
    schedulerSource,
    executionSeen: Boolean(execution),
    webAccessActive,
    mappedPortCount,
    proxyUrl
  };
}
async function fetchVmRuntime(args) {
  const crns = args.crns ?? await fetchCrns2({
    url: args.crnListUrl ?? DEFAULT_CRN_LIST_URL2,
    fetch: args.fetch
  });
  const schedulerAllocation = await fetchSchedulerAllocation2(args.itemHash, {
    fetch: args.fetch,
    schedulerAllocationUrl: args.schedulerAllocationUrl
  }).catch(() => null);
  const selectedCrn = args.crnHash ? findCrnByHash(crns, args.crnHash) : null;
  const allocation = schedulerAllocation ?? (selectedCrn ? {
    source: "manual",
    crnHash: selectedCrn.hash,
    crnUrl: selectedCrn.address,
    node: { url: selectedCrn.address },
    vmIpv6: null,
    period: null
  } : null);
  const webAccess = await fetch2n6WebAccessUrl2(args.itemHash, {
    fetch: args.fetch,
    twoN6HashUrl: args.twoN6HashUrl
  }).catch(() => null);
  const webAccessUrl = webAccess?.url ?? null;
  let execution = null;
  let executionLookupBlocked = false;
  if (allocation?.crnUrl) {
    const executionLookup = await fetchCrnExecutionMap2(allocation.crnUrl, {
      fetch: args.fetch
    });
    const executionPayload = executionLookup.payload?.[args.itemHash];
    if (executionPayload && typeof executionPayload === "object") {
      execution = normalizeExecution2(executionPayload, allocation.crnUrl);
      if (!execution.networking.proxy_url && webAccessUrl) {
        execution.networking.proxy_url = webAccessUrl;
      }
    } else if (executionLookup.payload == null) {
      executionLookupBlocked = true;
    }
  }
  const hostIpv4 = execution?.networking?.host_ipv4 ?? execution?.networking?.ipv4 ?? null;
  const ipv6 = execution?.networking?.ipv6_ip ?? execution?.networking?.ipv6 ?? allocation?.vmIpv6 ?? null;
  const mappedPorts2 = execution?.networking?.mapped_ports ?? {};
  const sshPort = mappedPorts2?.["22"]?.host ?? null;
  const proxyUrl = execution?.networking?.proxy_url ?? webAccessUrl ?? null;
  const diagnostics = describeRuntimeAvailability({
    allocation,
    execution,
    webAccess,
    hostIpv4,
    ipv6,
    proxyUrl,
    mappedPorts: mappedPorts2,
    requirePublicGuestIpv6ForProxy: args.requirePublicGuestIpv6ForProxy
  });
  return {
    allocation,
    execution,
    webAccess,
    webAccessUrl,
    hostIpv4,
    ipv6,
    proxyUrl,
    mappedPorts: mappedPorts2,
    diagnostics,
    sshCommand: hostIpv4 && sshPort ? `ssh root@${hostIpv4} -p ${sshPort}` : ipv6 ? `ssh root@${ipv6}` : null,
    selectedCrn,
    executionLookupBlocked
  };
}
async function waitForVmRuntime(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 20));
  const delayMs = Math.max(0, Number(args.delayMs ?? 4e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastRuntime = await fetchVmRuntime(args);
  args.onAttempt?.(lastRuntime, 1, attempts);
  for (let attempt = 0; attempt < attempts - 1; attempt += 1) {
    if (lastRuntime.diagnostics?.state === "ready" || lastRuntime.diagnostics?.state === "execution-invalid-public-ipv6") {
      return lastRuntime;
    }
    await sleep2(delayMs);
    lastRuntime = await fetchVmRuntime(args);
    args.onAttempt?.(lastRuntime, attempt + 2, attempts);
  }
  if (lastRuntime.diagnostics) {
    lastRuntime.diagnostics.timedOut = true;
  }
  return lastRuntime;
}

// ../core/src/crn-control.ts
function bytesToHex(bytes) {
  return Array.from(bytes).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function utf8Hex(value) {
  return bytesToHex(new TextEncoder().encode(value));
}
function normalizeHexSignature(signature) {
  return signature.startsWith("0x") ? signature : `0x${signature}`;
}
function asString4(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function trimTrailingSlashes(value) {
  return value.replace(/\/+$/u, "");
}
function isoTimestampWithMicros(date = /* @__PURE__ */ new Date()) {
  return date.toISOString().replace(/\.(\d{3})Z$/u, ".$1000Z");
}
async function generateEphemeralKeyPair() {
  return globalThis.crypto.subtle.generateKey(
    {
      name: "ECDSA",
      namedCurve: "P-256"
    },
    true,
    ["sign", "verify"]
  );
}
async function exportP256PublicJwk(publicKey) {
  const jwk = await globalThis.crypto.subtle.exportKey("jwk", publicKey);
  return {
    kty: String(jwk.kty ?? "EC"),
    crv: String(jwk.crv ?? "P-256"),
    x: String(jwk.x ?? ""),
    y: String(jwk.y ?? "")
  };
}
async function buildSignedPubKeyHeader(args) {
  const payload = {
    pubkey: await exportP256PublicJwk(args.publicKey),
    alg: "ECDSA",
    domain: args.domain,
    address: args.sender,
    expires: isoTimestampWithMicros(new Date(Date.now() + 24 * 60 * 60 * 1e3)),
    chain: "ETH"
  };
  const payloadJson = JSON.stringify(payload);
  const signature = normalizeHexSignature(await args.signer(args.sender, payloadJson));
  return JSON.stringify({
    sender: args.sender,
    payload: utf8Hex(payloadJson),
    signature,
    content: {
      domain: args.domain
    }
  });
}
async function buildSignedOperationHeader(args) {
  const payload = {
    time: isoTimestampWithMicros(),
    method: args.method,
    path: args.path,
    domain: args.domain
  };
  const payloadJson = JSON.stringify(payload);
  const signature = new Uint8Array(
    await globalThis.crypto.subtle.sign(
      {
        name: "ECDSA",
        hash: "SHA-256"
      },
      args.privateKey,
      new TextEncoder().encode(payloadJson)
    )
  );
  return JSON.stringify({
    payload: utf8Hex(payloadJson),
    signature: bytesToHex(signature)
  });
}
async function fetchInstanceNodeHash(args) {
  const envelope = await fetchMessageEnvelope2(args.instanceHash, {
    fetch: args.fetch,
    apiHost: args.apiHost
  });
  const payload = envelope;
  return asString4(payload?.content?.requirements?.node?.node_hash) ?? asString4(payload?.message?.content?.requirements?.node?.node_hash) ?? null;
}
async function resolveInstanceCrn(args) {
  const providedCrnUrl = asString4(args.crnUrl);
  if (providedCrnUrl) {
    return {
      crnUrl: trimTrailingSlashes(providedCrnUrl),
      crnHash: asString4(args.crnHash),
      source: "provided"
    };
  }
  const allocation = await fetchSchedulerAllocation2(args.instanceHash, {
    fetch: args.fetch,
    schedulerAllocationUrl: args.schedulerAllocationUrl ?? DEFAULT_SCHEDULER_ALLOCATION_URL
  }).catch(() => null);
  if (allocation?.crnUrl) {
    return {
      crnUrl: trimTrailingSlashes(allocation.crnUrl),
      crnHash: asString4(allocation.crnHash),
      source: "scheduler"
    };
  }
  const manualCrnHash = asString4(args.crnHash) ?? await fetchInstanceNodeHash({
    instanceHash: args.instanceHash,
    fetch: args.fetch,
    apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST2
  }).catch(() => null);
  if (manualCrnHash) {
    const crns = await fetchCrns2({
      url: args.crnListUrl ?? DEFAULT_CRN_LIST_URL2,
      fetch: args.fetch
    }).catch(() => []);
    const matchingCrn = crns.find((candidate) => candidate.hash === manualCrnHash);
    if (matchingCrn?.address) {
      return {
        crnUrl: trimTrailingSlashes(matchingCrn.address),
        crnHash: manualCrnHash,
        source: "manual"
      };
    }
  }
  return {
    crnUrl: null,
    crnHash: manualCrnHash,
    source: "missing"
  };
}
async function eraseInstanceOnCrn(args) {
  const resolution = await resolveInstanceCrn({
    instanceHash: args.instanceHash,
    fetch: args.fetch,
    apiHost: args.apiHost,
    crnUrl: args.crnUrl,
    crnHash: args.crnHash,
    crnListUrl: args.crnListUrl,
    schedulerAllocationUrl: args.schedulerAllocationUrl
  });
  if (!resolution.crnUrl) {
    return {
      ...resolution,
      status: "skipped"
    };
  }
  const crnUrl = new URL(resolution.crnUrl);
  const domain = crnUrl.host;
  const path = `/control/machine/${args.instanceHash}/erase`;
  const { privateKey, publicKey } = await generateEphemeralKeyPair();
  const signedPubKeyHeader = await buildSignedPubKeyHeader({
    sender: args.sender,
    signer: args.signer,
    domain,
    publicKey
  });
  const signedOperationHeader = await buildSignedOperationHeader({
    privateKey,
    domain,
    method: "POST",
    path
  });
  const response = await args.fetch(`${trimTrailingSlashes(resolution.crnUrl)}${path}`, {
    method: "POST",
    headers: {
      "X-SignedPubKey": signedPubKeyHeader,
      "X-SignedOperation": signedOperationHeader
    }
  });
  if (response.status === 404) {
    return {
      ...resolution,
      status: "missing"
    };
  }
  if (response.ok) {
    return {
      ...resolution,
      status: "erased"
    };
  }
  const errorBody = await response.json().then((payload) => JSON.stringify(payload)).catch(() => "");
  throw new Error(
    `CRN erase failed for ${args.instanceHash} on ${resolution.crnUrl}: ${response.status}${errorBody ? ` ${errorBody}` : ""}`
  );
}

// ../core/src/forget.ts
function asOptionalReason(value) {
  return typeof value === "string" && value.trim() ? value.trim() : void 0;
}
async function createUnsignedForgetMessage(args) {
  const content = {
    address: args.sender,
    time: args.now ?? Date.now() / 1e3,
    hashes: [...new Set((args.hashes ?? []).filter(Boolean))],
    aggregates: [...new Set((args.aggregates ?? []).filter(Boolean))],
    reason: asOptionalReason(args.reason)
  };
  if (content.hashes.length === 0 && content.aggregates.length === 0) {
    throw new Error("FORGET message requires at least one hash or aggregate key.");
  }
  const itemContent = JSON.stringify(content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "FORGET",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function forgetAlephMessages(args) {
  args.onProgress?.({
    stage: "building-delete-message",
    label: "Building delete message",
    progress: 18,
    status: "info",
    itemHash: null,
    detail: [...new Set((args.hashes ?? []).filter(Boolean))].join(", ") || null,
    error: null,
    timestamp: Date.now()
  });
  const unsignedMessage = await createUnsignedForgetMessage({
    sender: args.sender,
    hashes: args.hashes,
    aggregates: args.aggregates,
    reason: args.reason,
    hasher: args.hasher,
    channel: args.channel,
    now: args.now
  });
  args.onProgress?.({
    stage: "signing-delete-message",
    label: "Waiting for delete signature",
    progress: 42,
    status: "info",
    itemHash: unsignedMessage.item_hash,
    detail: unsignedMessage.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const message = await signAlephMessage(unsignedMessage, args.signer);
  args.onProgress?.({
    stage: "broadcasting-delete",
    label: "Broadcasting delete to Aleph",
    progress: 68,
    status: "warning",
    itemHash: message.item_hash,
    detail: message.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const { response, httpStatus } = await broadcastAlephMessage2(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const status = normalizeBroadcastStatus(httpStatus, response?.message_status);
  args.onProgress?.({
    stage: status === "rejected" ? "error" : "delete-completed",
    label: status === "rejected" ? "Delete rejected by Aleph" : "Delete submitted to Aleph",
    progress: 100,
    status: status === "rejected" ? "error" : "success",
    itemHash: message.item_hash,
    detail: status === "rejected" ? String(response?.details ?? "Aleph rejected this delete request.") : null,
    error: status === "rejected" ? String(response?.details ?? "Aleph rejected this delete request.") : null,
    timestamp: Date.now()
  });
  return {
    sender: args.sender,
    itemHash: message.item_hash,
    response,
    httpStatus,
    status
  };
}

// ../core/src/aggregate-publication.ts
function createPortForwardAggregateContent(args) {
  const existingPorts = normalizeExistingPortForwardEntry(args.existingAggregate?.[args.instanceItemHash]);
  const mergedPorts = mergePortFlagMaps(existingPorts, requestedPortFlags(args.requestedPorts));
  return {
    address: args.sender,
    key: "port-forwarding",
    content: {
      [args.instanceItemHash]: {
        ports: mergedPorts
      }
    },
    time: args.now ?? Date.now() / 1e3
  };
}
async function createUnsignedAggregateMessage(args) {
  const itemContent = JSON.stringify(args.content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "AGGREGATE",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function ensureInstancePortForwards(args) {
  const requestedPorts = requiredInstancePortForwards(args.manifest);
  const aggregate = await fetchPortForwardAggregate(args.sender, {
    apiHost: args.apiHost,
    fetch: args.fetch
  });
  const content = createPortForwardAggregateContent({
    sender: args.sender,
    instanceItemHash: args.instanceItemHash,
    requestedPorts,
    existingAggregate: aggregate
  });
  const unsignedMessage = await createUnsignedAggregateMessage({
    sender: args.sender,
    content,
    hasher: args.hasher,
    channel: args.channel
  });
  const message = await signAlephMessage(unsignedMessage, args.signer);
  const { response, httpStatus } = await broadcastAlephMessage2(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const aggregateStatus = normalizeBroadcastStatus(httpStatus, response.message_status);
  if (aggregateStatus === "rejected") {
    throw new Error(`Port-forward aggregate was rejected by Aleph: ${JSON.stringify(response.details ?? response)}`);
  }
  return {
    aggregateItemHash: message.item_hash,
    aggregateStatus,
    requestedPorts
  };
}

// ../core/src/instance-deployment.ts
var SSH_PUBLIC_KEY_PATTERN = /^(ssh-rsa|ssh-ed25519|ecdsa-sha2-nistp256|ecdsa-sha2-nistp384|ecdsa-sha2-nistp521|sk-ssh-ed25519@openssh\.com|sk-ecdsa-sha2-nistp256@openssh\.com)\s+[A-Za-z0-9+/]+={0,3}(?:\s+.+)?$/;
function toFiniteNumber(value) {
  if (typeof value === "number") return value;
  if (typeof value === "string" && value.trim()) return Number(value);
  return Number.NaN;
}
function normalizeSshPublicKey(value) {
  return value.split(/\r?\n/g).map((line) => line.trim()).filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
}
function isValidSshPublicKey(value) {
  return SSH_PUBLIC_KEY_PATTERN.test(normalizeSshPublicKey(value));
}
function createDeploymentToken() {
  const randomUuid = globalThis.crypto?.randomUUID?.();
  if (typeof randomUuid === "string" && randomUuid.trim()) {
    return randomUuid;
  }
  return `deploy-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}
function appendDeploymentTokenToSshPublicKey(sshPublicKey, ownerAddress, deploymentToken) {
  const normalized = normalizeSshPublicKey(sshPublicKey);
  if (!normalized) return normalized;
  const [algorithm = "", key = ""] = normalized.split(/\s+/, 3);
  const owner = ownerAddress.trim();
  const token = deploymentToken.trim();
  if (!algorithm || !key || !owner || !token) {
    return normalized;
  }
  return `${algorithm} ${key} aleph-bootstrap-config:${owner}:${token}`;
}
function createReleaseMetadata(name, rootfsVersion, deployer = "shared-aleph-tooling") {
  return {
    name,
    rootfs_version: rootfsVersion,
    deployer
  };
}
function tierSpec(pricing, tier) {
  return {
    vcpus: pricing.compute_unit.vcpus * tier.compute_units,
    memoryMiB: pricing.compute_unit.memory_mib * tier.compute_units,
    diskMiB: pricing.compute_unit.disk_mib * tier.compute_units
  };
}
function buildPaymentQuote(tier, pricing, balance) {
  const computeUnitPrice = pricing.price.compute_unit;
  if (!computeUnitPrice) return null;
  const unitPrice = toFiniteNumber(computeUnitPrice.credit);
  if (!Number.isFinite(unitPrice)) return null;
  return {
    required: unitPrice * tier.compute_units,
    available: Number(balance.credit_balance ?? 0),
    computeUnits: tier.compute_units,
    unitPrice,
    label: "credits"
  };
}
function describeRejectedInstanceBroadcast(response) {
  const balanceMessage = extractInsufficientBalanceMessage2(response.details);
  if (balanceMessage) {
    return `Aleph rejected this deployment due to ${balanceMessage}.`;
  }
  const errorCode = typeof response.error_code === "number" ? response.error_code : null;
  return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}.`;
}
function createInstanceContent(args) {
  const sshKey = normalizeSshPublicKey(args.sshPublicKey);
  if (!sshKey) {
    throw new Error("An SSH public key is required.");
  }
  if (!isValidSshPublicKey(sshKey)) {
    throw new Error("SSH public key must be a single valid .pub line.");
  }
  if (!args.rootfsItemHash || !/^[a-fA-F0-9]{64}$/.test(args.rootfsItemHash)) {
    throw new Error("rootfsItemHash must be a 64-character Aleph item hash.");
  }
  return {
    address: args.address,
    time: args.now ?? Date.now() / 1e3,
    allow_amend: false,
    metadata: createReleaseMetadata(args.name.trim(), args.rootfsVersion ?? "custom-rootfs", args.deployer),
    authorized_keys: [sshKey],
    environment: {
      internet: true,
      aleph_api: true,
      hypervisor: "qemu",
      reproducible: false,
      shared_cache: false
    },
    resources: {
      vcpus: Number(args.vcpus),
      memory: Number(args.memoryMiB),
      seconds: Number(args.seconds ?? 30)
    },
    payment: {
      type: "credit"
    },
    requirements: args.crnHash ? {
      node: {
        node_hash: args.crnHash
      }
    } : void 0,
    volumes: [],
    rootfs: {
      parent: {
        ref: args.rootfsItemHash,
        use_latest: true
      },
      persistence: "host",
      size_mib: Number(args.rootfsSizeMiB)
    }
  };
}
async function createUnsignedInstanceMessage(args) {
  const itemContent = JSON.stringify(args.content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "INSTANCE",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function deployInstance(args) {
  args.onProgress?.({
    stage: "building-message",
    label: "Building deployment message",
    progress: 32,
    status: "info",
    detail: args.content.metadata?.name ?? null,
    itemHash: null,
    error: null,
    timestamp: Date.now()
  });
  const unsignedMessage = await createUnsignedInstanceMessage({
    sender: args.sender,
    content: args.content,
    hasher: args.hasher,
    channel: args.channel,
    now: args.now
  });
  args.onProgress?.({
    stage: "signing-message",
    label: "Waiting for MetaMask signature",
    progress: 48,
    status: "info",
    detail: unsignedMessage.item_hash,
    itemHash: unsignedMessage.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const signature = await args.signer(unsignedMessage.sender, [unsignedMessage.chain, unsignedMessage.sender, unsignedMessage.type, unsignedMessage.item_hash].join("\n"));
  const message = {
    ...unsignedMessage,
    signature: signature.startsWith("0x") ? signature : `0x${signature}`
  };
  args.onProgress?.({
    stage: "broadcasting",
    label: "Broadcasting to Aleph",
    progress: 64,
    status: "info",
    detail: message.item_hash,
    itemHash: message.item_hash,
    error: null,
    timestamp: Date.now()
  });
  const { response, httpStatus } = await broadcastAlephMessage2(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const status = httpStatus === 202 ? "pending" : typeof response.message_status === "string" ? response.message_status : "unknown";
  args.onProgress?.({
    stage: status === "processed" ? "deployment-confirmed" : status === "rejected" ? "deployment-rejected" : "waiting-for-aleph",
    label: status === "processed" ? "Deployment accepted by Aleph" : status === "rejected" ? "Deployment rejected by Aleph" : "Deployment submitted to Aleph",
    progress: status === "processed" ? 88 : status === "rejected" ? 100 : 78,
    status: status === "processed" ? "success" : status === "rejected" ? "error" : "warning",
    detail: status === "rejected" ? describeRejectedInstanceBroadcast(response) : null,
    itemHash: message.item_hash,
    error: status === "rejected" ? describeRejectedInstanceBroadcast(response) : null,
    timestamp: Date.now()
  });
  return {
    itemHash: message.item_hash,
    httpStatus,
    status,
    message,
    response,
    rejectionReason: status === "rejected" ? describeRejectedInstanceBroadcast(response) : null
  };
}

// ../core/src/guest.ts
async function defaultHttpProbe(fetch2, url, timeoutMs = 1e4) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const response = await fetch2(url, {
      method: "GET",
      redirect: "follow",
      signal: controller.signal
    });
    clearTimeout(timeout);
    return {
      ok: response.ok,
      status: response.status,
      url: response.url
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : String(error)
    };
  }
}
async function notifyCrnAllocation2(args) {
  const normalizedCrnUrl = typeof args.crnUrl === "string" ? args.crnUrl.trim().replace(/\/+$/, "") : "";
  if (!normalizedCrnUrl) {
    return {
      status: "skipped",
      reason: "No CRN URL available for allocation notification."
    };
  }
  try {
    const response = await args.fetch(
      `${normalizedCrnUrl}/control/allocation/notify`,
      {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify({ instance: args.itemHash })
      }
    );
    const payload = await response.json().catch(() => null);
    const responseText = payload == null ? "" : typeof payload === "string" ? payload : JSON.stringify(payload);
    if (!response.ok) {
      return {
        status: "unconfirmed",
        reason: `CRN allocation notify returned ${response.status}${responseText ? ` ${responseText}` : ""}.`,
        payload
      };
    }
    return {
      status: "confirmed",
      payload
    };
  } catch (error) {
    return {
      status: "unconfirmed",
      reason: error instanceof Error ? error.message : String(error)
    };
  }
}
function isRetryableAllocationNotifyReason(reason) {
  const normalized = String(reason ?? "").toLowerCase();
  return normalized.includes("503") && (normalized.includes("node hash not yet discovered") || normalized.includes("cannot accept targeted allocations"));
}
async function notifyCrnAllocationWithRetry(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 6));
  const delayMs = Math.max(0, Number(args.delayMs ?? 2e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastResult = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    args.onProgress?.({
      stage: "notifying-crn",
      label: "Notifying selected CRN",
      progress: 84,
      status: "info",
      itemHash: args.itemHash,
      detail: `${attempt + 1}/${attempts} ${String(args.crnUrl ?? "").trim() || "selected CRN"}`,
      error: null,
      timestamp: Date.now()
    });
    const result = await notifyCrnAllocation2({
      crnUrl: args.crnUrl,
      itemHash: args.itemHash,
      fetch: args.fetch
    });
    if (result.status === "confirmed" || result.status === "skipped") {
      return result;
    }
    lastResult = result;
    if (!isRetryableAllocationNotifyReason(result.reason)) {
      return result;
    }
    if (attempt < attempts - 1) {
      await sleep2(delayMs);
    }
  }
  return lastResult ?? {
    status: "unconfirmed",
    reason: "CRN allocation notify was not confirmed."
  };
}
async function waitForSetupEndpoint(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 15));
  const delayMs = Math.max(0, Number(args.delayMs ?? 4e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const url = `http://${args.hostIpv4}:${args.setupPort}/health`;
  let result = await defaultHttpProbe(
    args.fetch,
    url,
    Number(args.httpTimeoutMs ?? 1e4)
  );
  args.onAttempt?.(result, 1, attempts);
  for (let attempt = 1; attempt < attempts; attempt += 1) {
    if (result.ok) return result;
    await sleep2(delayMs);
    result = await defaultHttpProbe(
      args.fetch,
      url,
      Number(args.httpTimeoutMs ?? 1e4)
    );
    args.onAttempt?.(result, attempt + 1, attempts);
  }
  return result;
}
async function configureOrbitdbRelaySetup2(args) {
  const controller = new AbortController();
  const timeout = setTimeout(
    () => controller.abort(),
    Number(args.timeoutMs ?? 18e4)
  );
  const payload = {
    public_ipv4: args.hostIpv4,
    public_ipv6: args.publicIpv6 ?? void 0,
    tcp_port: args.tcpPort,
    ws_port: args.wsPort,
    proxy_url: args.proxyUrl ?? void 0,
    metrics_port: args.metricsPort ?? void 0,
    metrics_https_port: args.metricsHttpsPort ?? void 0,
    webrtc_port: args.webrtcPort ?? void 0,
    quic_port: args.quicPort ?? void 0,
    bootstrap_publisher_private_key: args.bootstrapPublisherPrivateKey ?? void 0,
    bootstrap_publisher_libp2p_identity_hex: args.bootstrapPublisherLibp2pIdentityHex ?? void 0,
    bootstrap_owner_private_key: args.bootstrapOwnerPrivateKey ?? void 0,
    bootstrap_owner_authorization_b64: args.bootstrapOwnerAuthorizationBase64 ?? void 0,
    bootstrap_registration_id: args.bootstrapRegistrationId ?? void 0,
    no_start: args.noStart === true ? true : void 0
  };
  try {
    const response = await args.fetch(
      `http://${args.hostIpv4}:${args.setupPort}/configure`,
      {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      }
    );
    const responsePayload = await response.json().catch(() => null);
    if (!response.ok) {
      throw new Error(
        `Relay setup request failed: ${response.status} ${typeof responsePayload === "string" ? responsePayload : JSON.stringify(responsePayload ?? {})}`
      );
    }
    return responsePayload;
  } finally {
    clearTimeout(timeout);
  }
}
async function fetchUcGoPeerMetadata(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 60));
  const delayMs = Math.max(0, Number(args.delayMs ?? 3e3));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  let lastPayload = null;
  let lastError = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(
      () => controller.abort(),
      Number(args.timeoutMs ?? 18e4)
    );
    const requestUrl = args.metadataUrl && args.metadataUrl.trim() ? args.metadataUrl : `http://${args.hostIpv4}:${args.setupPort}/metadata`;
    try {
      const response = await args.fetch(
        requestUrl,
        {
          signal: controller.signal
        }
      );
      const payload = await response.json().catch(() => null);
      lastPayload = payload;
      lastError = null;
      const ready = Boolean(
        args.isReady ? args.isReady({
          payload,
          ok: response.ok,
          status: response.status,
          requestUrl
        }) : response.ok && payload && typeof payload === "object" && payload.status === "ready"
      );
      args.onAttempt?.({
        payload,
        ready,
        attempt: attempt + 1,
        attempts,
        requestUrl,
        ok: response.ok,
        status: response.status,
        error: null
      });
      if (ready) {
        return payload;
      }
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error);
      lastPayload = {
        error: lastError
      };
      args.onAttempt?.({
        payload: null,
        ready: false,
        attempt: attempt + 1,
        attempts,
        requestUrl,
        ok: false,
        status: null,
        error: lastError
      });
    } finally {
      clearTimeout(timeout);
    }
    if (attempt < attempts - 1) {
      await sleep2(delayMs);
    }
  }
  throw new Error(
    `Relay metadata did not become ready after ${attempts} attempts: ${lastError ? lastError : typeof lastPayload === "string" ? lastPayload : JSON.stringify(lastPayload ?? {})}`
  );
}

// ../aleph-bootstrap/src/index.ts
import { recoverMessageAddress } from "viem";
var DEFAULT_ALEPH_API_HOST3 = "https://api.aleph.im";
var DEFAULT_ALEPH_BOOTSTRAP_CHANNEL = "simple-todo";
var DEFAULT_ALEPH_BOOTSTRAP_REF = "simple-todo-bootstrap";
var DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE = "relay-bootstrap";
var DEFAULT_BOOTSTRAP_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
var DEFAULT_BOOTSTRAP_PAGINATION = 50;
var RELAY_BOOTSTRAP_SIGNATURE_SCHEME = "personal_sign";
function serializeOwnerAuthorizationPayload(payload) {
  return JSON.stringify({
    ownerAddress: payload.ownerAddress,
    publisherAddress: payload.publisherAddress,
    peerId: payload.peerId,
    registrationId: payload.registrationId,
    profile: payload.profile,
    version: payload.version,
    instanceItemHash: payload.instanceItemHash,
    issuedAt: payload.issuedAt,
    expiresAt: payload.expiresAt
  });
}
function serializeRelayProofPayload(payload) {
  return JSON.stringify({
    peerId: payload.peerId,
    multiaddrs: dedupeMultiaddrs(payload.multiaddrs),
    browserMultiaddrs: payload.browserMultiaddrs ? dedupeMultiaddrs(payload.browserMultiaddrs) : void 0,
    registrationId: payload.registrationId,
    profile: payload.profile,
    version: payload.version,
    updatedAt: payload.updatedAt
  });
}
function asTrimmedString(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function asNumber4(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function normalizeHost(host) {
  return host.trim().toLowerCase();
}
function normalizeAddress(address) {
  return address.trim().toLowerCase();
}
function normalizeSignature(signature) {
  const trimmed = signature.trim();
  return trimmed.startsWith("0x") ? trimmed : `0x${trimmed}`;
}
function splitMultiaddr(addr) {
  return addr.split("/").filter(Boolean);
}
function isPrivateIpv4(ip) {
  const parts = ip.split(".").map((part) => Number(part));
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) {
    return false;
  }
  if (parts[0] === 10) return true;
  if (parts[0] === 127) return true;
  if (parts[0] === 0) return true;
  if (parts[0] === 169 && parts[1] === 254) return true;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  if (parts[0] === 192 && parts[1] === 168) return true;
  if (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127) return true;
  return false;
}
function isPrivateIpv6(ip) {
  const normalized = ip.trim().toLowerCase();
  return normalized === "::1" || normalized.startsWith("fc") || normalized.startsWith("fd") || normalized.startsWith("fe8") || normalized.startsWith("fe9") || normalized.startsWith("fea") || normalized.startsWith("feb");
}
function isLocalHostname(host) {
  const normalized = normalizeHost(host);
  return normalized === "localhost" || normalized.endsWith(".localhost") || normalized.endsWith(".local");
}
function hasPeerId(addr) {
  return splitMultiaddr(addr).includes("p2p");
}
function isBrowserDialableMultiaddr(addr) {
  const normalized = addr.toLowerCase();
  return normalized.includes("/ws") || normalized.includes("/wss") || normalized.includes("/webtransport") || normalized.includes("/webrtc-direct");
}
function dedupeMultiaddrs(addrs) {
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const value of addrs) {
    const trimmed = value.trim();
    if (!trimmed || seen.has(trimmed)) continue;
    seen.add(trimmed);
    result.push(trimmed);
  }
  return result;
}
function isPublicMultiaddr(addr) {
  const parts = splitMultiaddr(addr);
  for (let index = 0; index < parts.length; index += 1) {
    const protocol = parts[index];
    const value = parts[index + 1];
    if (protocol === "ip4" && value) {
      return !isPrivateIpv4(value);
    }
    if (protocol === "ip6" && value) {
      return !isPrivateIpv6(value);
    }
    if ((protocol === "dns4" || protocol === "dns6" || protocol === "dnsaddr") && value) {
      return !isLocalHostname(value);
    }
  }
  return false;
}
function filterPublicMultiaddrs(addrs, options = {}) {
  return dedupeMultiaddrs(addrs).filter((addr) => {
    if (!isPublicMultiaddr(addr)) return false;
    if (options.requirePeerId !== false && !hasPeerId(addr)) return false;
    if (options.browserDialableOnly && !isBrowserDialableMultiaddr(addr)) {
      return false;
    }
    return true;
  });
}
function normalizeRelayBootstrapContent(value) {
  if (!value || typeof value !== "object") return null;
  const content = value;
  const peerId = asTrimmedString(content.peerId);
  const updatedAt = asNumber4(content.updatedAt);
  if (!peerId || updatedAt == null) return null;
  const multiaddrs = Array.isArray(content.multiaddrs) ? content.multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserMultiaddrs = Array.isArray(content.browserMultiaddrs) ? content.browserMultiaddrs.filter((entry) => typeof entry === "string") : void 0;
  return {
    peerId,
    multiaddrs: dedupeMultiaddrs(multiaddrs),
    browserMultiaddrs: browserMultiaddrs ? dedupeMultiaddrs(browserMultiaddrs) : void 0,
    registrationId: asTrimmedString(content.registrationId) ?? void 0,
    profile: asTrimmedString(content.profile) ?? void 0,
    version: asTrimmedString(content.version) ?? void 0,
    ownerAddress: asTrimmedString(content.ownerAddress) ?? void 0,
    publisherAddress: asTrimmedString(content.publisherAddress) ?? void 0,
    authorization: normalizeRelayBootstrapAuthorizationRecord(content.authorization) ?? void 0,
    relayProof: normalizeRelayBootstrapProofRecord(content.relayProof) ?? void 0,
    updatedAt
  };
}
function normalizeRelayBootstrapAuthorizationPayload(value) {
  if (!value || typeof value !== "object") return null;
  const payload = value;
  const ownerAddress = asTrimmedString(payload.ownerAddress);
  const publisherAddress = asTrimmedString(payload.publisherAddress);
  const peerId = asTrimmedString(payload.peerId);
  const issuedAt = asNumber4(payload.issuedAt);
  const expiresAt = asNumber4(payload.expiresAt) ?? void 0;
  if (!ownerAddress || !publisherAddress || !peerId || issuedAt == null) {
    return null;
  }
  return {
    ownerAddress,
    publisherAddress,
    peerId,
    registrationId: asTrimmedString(payload.registrationId) ?? void 0,
    profile: asTrimmedString(payload.profile) ?? void 0,
    version: asTrimmedString(payload.version) ?? void 0,
    instanceItemHash: asTrimmedString(payload.instanceItemHash) ?? void 0,
    issuedAt,
    expiresAt
  };
}
function normalizeRelayBootstrapAuthorizationRecord(value) {
  if (!value || typeof value !== "object") return null;
  const record = value;
  const scheme = asTrimmedString(record.scheme);
  const signature = asTrimmedString(record.signature);
  const payload = normalizeRelayBootstrapAuthorizationPayload(record.payload);
  if (!scheme || !signature || !payload) return null;
  return { scheme, signature, payload };
}
function normalizeRelayBootstrapProofPayload(value) {
  if (!value || typeof value !== "object") return null;
  const payload = value;
  const peerId = asTrimmedString(payload.peerId);
  const updatedAt = asNumber4(payload.updatedAt);
  if (!peerId || updatedAt == null) return null;
  const multiaddrs = Array.isArray(payload.multiaddrs) ? payload.multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserMultiaddrs = Array.isArray(payload.browserMultiaddrs) ? payload.browserMultiaddrs.filter((entry) => typeof entry === "string") : void 0;
  return {
    peerId,
    multiaddrs: dedupeMultiaddrs(multiaddrs),
    browserMultiaddrs: browserMultiaddrs ? dedupeMultiaddrs(browserMultiaddrs) : void 0,
    registrationId: asTrimmedString(payload.registrationId) ?? void 0,
    profile: asTrimmedString(payload.profile) ?? void 0,
    version: asTrimmedString(payload.version) ?? void 0,
    updatedAt
  };
}
function normalizeRelayBootstrapProofRecord(value) {
  if (!value || typeof value !== "object") return null;
  const record = value;
  const scheme = asTrimmedString(record.scheme);
  const signature = asTrimmedString(record.signature);
  const payload = normalizeRelayBootstrapProofPayload(record.payload);
  if (!scheme || !signature || !payload) return null;
  return { scheme, signature, payload };
}
function normalizeRelayBootstrapPostRecord(value) {
  if (!value || typeof value !== "object") return null;
  const entry = value;
  return {
    hash: asTrimmedString(entry.hash),
    itemHash: asTrimmedString(entry.item_hash),
    address: asTrimmedString(entry.address),
    ref: asTrimmedString(entry.ref),
    type: asTrimmedString(entry.type),
    time: asNumber4(entry.time),
    content: normalizeRelayBootstrapContent(entry.content)
  };
}
function buildRelayBootstrapPostContent(args) {
  const now = args.now ?? Date.now() / 1e3;
  const updatedAt = args.now ?? Date.now();
  return {
    type: args.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE,
    address: args.sender,
    ...args.ref ? { ref: args.ref } : {},
    content: {
      peerId: args.peerId,
      multiaddrs: filterPublicMultiaddrs(args.multiaddrs),
      browserMultiaddrs: args.browserMultiaddrs ? filterPublicMultiaddrs(args.browserMultiaddrs, {
        browserDialableOnly: true
      }) : void 0,
      registrationId: args.registrationId,
      profile: args.profile,
      version: args.version,
      ownerAddress: args.ownerAddress,
      publisherAddress: args.publisherAddress,
      authorization: args.authorization,
      relayProof: args.relayProof,
      updatedAt: Math.round(updatedAt)
    },
    time: now
  };
}
async function createRelayBootstrapPost(args) {
  const nowMillis = args.now ?? Date.now();
  const nowSeconds = nowMillis / 1e3;
  const itemContent = buildRelayBootstrapPostContent({
    sender: args.sender,
    peerId: args.peerId,
    multiaddrs: args.multiaddrs,
    browserMultiaddrs: args.browserMultiaddrs,
    registrationId: args.registrationId,
    ref: args.ref ?? DEFAULT_ALEPH_BOOTSTRAP_REF,
    postType: args.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE,
    profile: args.profile,
    version: args.version,
    ownerAddress: args.ownerAddress,
    publisherAddress: args.publisherAddress,
    authorization: args.authorization,
    relayProof: args.relayProof,
    now: nowMillis
  });
  itemContent.time = nowSeconds;
  const serialized = JSON.stringify(itemContent);
  const itemHash = await args.hasher(serialized);
  return {
    channel: args.channel ?? DEFAULT_ALEPH_BOOTSTRAP_CHANNEL,
    sender: args.sender,
    chain: "ETH",
    type: "POST",
    time: nowSeconds,
    item_type: "inline",
    item_content: serialized,
    item_hash: itemHash
  };
}
async function signRelayBootstrapAuthorization(args) {
  const payload = {
    ownerAddress: args.ownerAddress,
    publisherAddress: args.publisherAddress,
    peerId: args.peerId,
    registrationId: args.registrationId,
    profile: args.profile,
    version: args.version,
    instanceItemHash: args.instanceItemHash,
    issuedAt: args.issuedAt ?? Date.now(),
    expiresAt: args.expiresAt
  };
  const serialized = serializeOwnerAuthorizationPayload(payload);
  const signature = await args.signer(args.ownerAddress, serialized);
  return {
    scheme: RELAY_BOOTSTRAP_SIGNATURE_SCHEME,
    payload,
    signature: normalizeSignature(signature)
  };
}
async function signRelayBootstrapProof(args) {
  const payload = {
    peerId: args.peerId,
    multiaddrs: filterPublicMultiaddrs(args.multiaddrs),
    browserMultiaddrs: args.browserMultiaddrs ? filterPublicMultiaddrs(args.browserMultiaddrs, {
      browserDialableOnly: true
    }) : void 0,
    registrationId: args.registrationId,
    profile: args.profile,
    version: args.version,
    updatedAt: args.updatedAt ?? Date.now()
  };
  const serialized = serializeRelayProofPayload(payload);
  const signature = await args.signer(args.publisherAddress, serialized);
  return {
    scheme: RELAY_BOOTSTRAP_SIGNATURE_SCHEME,
    payload,
    signature: normalizeSignature(signature)
  };
}
async function fetchAlephBootstrapPosts(options = {}) {
  const fetchImpl = options.fetch ?? globalThis.fetch?.bind(globalThis);
  if (typeof fetchImpl !== "function") {
    throw new Error(
      "A fetch implementation is required to query Aleph bootstrap posts."
    );
  }
  const url = new URL(
    "/api/v0/posts.json",
    options.apiHost ?? DEFAULT_ALEPH_API_HOST3
  );
  url.searchParams.set(
    "channels",
    options.channel ?? DEFAULT_ALEPH_BOOTSTRAP_CHANNEL
  );
  url.searchParams.set("refs", options.ref ?? DEFAULT_ALEPH_BOOTSTRAP_REF);
  url.searchParams.set(
    "types",
    options.postType ?? DEFAULT_ALEPH_BOOTSTRAP_POST_TYPE
  );
  url.searchParams.set(
    "pagination",
    String(options.pagination ?? DEFAULT_BOOTSTRAP_PAGINATION)
  );
  url.searchParams.set("page", String(options.page ?? 1));
  const response = await fetchImpl(url.toString(), {
    method: "GET",
    headers: { accept: "application/json" }
  });
  if (!response.ok) {
    throw new Error(`Aleph bootstrap post lookup failed: ${response.status}`);
  }
  const payload = await response.json();
  return (payload.posts ?? []).map((entry) => normalizeRelayBootstrapPostRecord(entry)).filter((entry) => entry != null);
}
function compareRelayBootstrapPostRecency(left, right) {
  const leftUpdatedAt = left.content?.updatedAt ?? 0;
  const rightUpdatedAt = right.content?.updatedAt ?? 0;
  if (leftUpdatedAt !== rightUpdatedAt) return leftUpdatedAt - rightUpdatedAt;
  const leftTime = left.time ?? 0;
  const rightTime = right.time ?? 0;
  return leftTime - rightTime;
}
function relayBootstrapRecordIdentity(post) {
  const content = post.content;
  if (!content) return null;
  if (content.registrationId) return `registration:${content.registrationId}`;
  if (post.address) return `sender:${normalizeAddress(post.address)}`;
  return content.peerId ? `peer:${content.peerId}` : null;
}
function selectCurrentRelayBootstrapPosts(posts, options = {}) {
  const maxAgeMs = options.maxAgeMs ?? DEFAULT_BOOTSTRAP_MAX_AGE_MS;
  const now = options.now ?? Date.now();
  const selected = /* @__PURE__ */ new Map();
  for (const post of posts) {
    const content = post.content;
    if (!content) continue;
    if (now - content.updatedAt > maxAgeMs) continue;
    const identity = relayBootstrapRecordIdentity(post);
    if (!identity) continue;
    const previous = selected.get(identity);
    if (!previous || compareRelayBootstrapPostRecency(post, previous) > 0) {
      selected.set(identity, post);
    }
  }
  return [...selected.values()].sort(
    (left, right) => compareRelayBootstrapPostRecency(right, left)
  );
}

// ../core/src/bootstrap-registration.ts
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function waitForRelayBootstrapRegistration(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 10));
  const delayMs = Math.max(0, Number(args.delayMs ?? 2e3));
  const expectedSender = args.sender?.trim().toLowerCase() || null;
  const expectedRegistrationId = args.registrationId?.trim() || null;
  const expectedPeerId = args.peerId?.trim() || null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const posts = await fetchAlephBootstrapPosts({
      apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST3,
      channel: args.channel,
      ref: args.ref,
      postType: args.postType,
      fetch: args.fetch
    });
    const currentPosts = selectCurrentRelayBootstrapPosts(posts);
    const match = currentPosts.find((post) => {
      if (expectedSender && post.address?.toLowerCase() !== expectedSender) {
        return false;
      }
      if (expectedRegistrationId && post.content?.registrationId === expectedRegistrationId) {
        return true;
      }
      if (expectedPeerId && post.content?.peerId === expectedPeerId) {
        return true;
      }
      return false;
    });
    if (match?.content) {
      const visibleRegistration = {
        itemHash: match.itemHash ?? null,
        hash: match.hash ?? null,
        sender: typeof match.address === "string" ? match.address : null,
        registrationId: match.content.registrationId,
        peerId: match.content.peerId,
        multiaddrs: Array.isArray(match.content.multiaddrs) ? match.content.multiaddrs : [],
        browserMultiaddrs: Array.isArray(match.content.browserMultiaddrs) ? match.content.browserMultiaddrs : []
      };
      args.onAttempt?.(visibleRegistration, attempt + 1, attempts);
      return visibleRegistration;
    }
    args.onAttempt?.(null, attempt + 1, attempts);
    if (attempt < attempts - 1) {
      await sleep(delayMs);
    }
  }
  return null;
}
async function publishRelayBootstrapRegistration(args) {
  const publisherAddress = args.publisherAddress ?? args.sender;
  const ownerAddress = args.ownerAddress;
  let ownerAuthorization = args.ownerAuthorization;
  let relayProof = args.relayProof;
  if (!ownerAuthorization && ownerAddress && args.ownerSigner) {
    ownerAuthorization = await signRelayBootstrapAuthorization({
      ownerAddress,
      publisherAddress,
      peerId: args.peerId,
      registrationId: args.registrationId,
      profile: args.profile,
      version: args.version,
      instanceItemHash: args.instanceItemHash,
      issuedAt: args.authorizationIssuedAt ?? args.now ?? Date.now(),
      expiresAt: args.authorizationExpiresAt,
      signer: args.ownerSigner
    });
  }
  if (!relayProof && args.publisherSigner) {
    relayProof = await signRelayBootstrapProof({
      publisherAddress,
      peerId: args.peerId,
      multiaddrs: args.multiaddrs,
      browserMultiaddrs: args.browserMultiaddrs,
      registrationId: args.registrationId,
      profile: args.profile,
      version: args.version,
      updatedAt: args.now ?? Date.now(),
      signer: args.publisherSigner
    });
  }
  const unsigned = await createRelayBootstrapPost({
    sender: args.sender,
    peerId: args.peerId,
    multiaddrs: args.multiaddrs,
    browserMultiaddrs: args.browserMultiaddrs,
    registrationId: args.registrationId,
    channel: args.channel,
    ref: args.ref,
    postType: args.postType,
    profile: args.profile,
    version: args.version,
    ownerAddress,
    publisherAddress,
    authorization: ownerAuthorization,
    relayProof,
    now: args.now,
    hasher: args.hasher
  });
  const content = JSON.parse(unsigned.item_content);
  if ((content.content?.multiaddrs?.length ?? 0) === 0) {
    return {
      status: "skipped",
      reason: "No public relay multiaddrs remained after filtering.",
      publishedMultiaddrs: [],
      publishedBrowserMultiaddrs: content.content?.browserMultiaddrs ?? []
    };
  }
  const message = await signAlephMessage(unsigned, args.signer);
  const { response, httpStatus } = await broadcastAlephMessage2(message, {
    apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST3,
    sync: args.sync ?? true,
    fetch: args.fetch
  });
  let forgottenHashes = [];
  let forgetResult;
  if (args.forgetPrevious && args.registrationId) {
    const previousPosts = await fetchAlephBootstrapPosts({
      apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST3,
      channel: args.channel,
      ref: args.ref,
      postType: args.postType,
      fetch: args.fetch
    });
    forgottenHashes = previousPosts.filter(
      (post) => post.address?.toLowerCase() === args.sender.toLowerCase() && post.content?.registrationId === args.registrationId && (post.itemHash ?? post.hash) != null && (post.itemHash ?? post.hash) !== unsigned.item_hash
    ).map((post) => post.itemHash ?? post.hash ?? "").filter(Boolean);
    if (forgottenHashes.length > 0) {
      forgetResult = await forgetAlephMessages({
        sender: args.sender,
        hashes: forgottenHashes,
        reason: args.forgetPreviousReason ?? `Replace older relay bootstrap records for ${args.registrationId}`,
        signer: args.signer,
        hasher: args.hasher,
        fetch: args.fetch,
        apiHost: args.apiHost ?? DEFAULT_ALEPH_API_HOST3,
        sync: args.sync ?? true
      });
    }
  }
  return {
    status: "published",
    itemHash: unsigned.item_hash,
    message,
    response,
    httpStatus,
    publishedMultiaddrs: content.content?.multiaddrs ?? [],
    publishedBrowserMultiaddrs: content.content?.browserMultiaddrs ?? [],
    forgottenHashes,
    forgetResult
  };
}

// ../core/src/bootstrap-config.ts
var VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY = "vm-bootstrap-config";
var VM_BOOTSTRAP_CONFIG_SIGNAL_REF = "vm-bootstrap-config";
var VM_BOOTSTRAP_CONFIG_SIGNAL_POST_TYPE = "vm-bootstrap-config-status";
var VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS = 6 * 60 * 60 * 1e3;
function parseJsonObject(value) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
function parseTimestampMs(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value > 1e12 ? value : value * 1e3;
  }
  if (typeof value === "string" && value.trim()) {
    const numeric = Number(value);
    if (Number.isFinite(numeric)) {
      return numeric > 1e12 ? numeric : numeric * 1e3;
    }
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
function normalizeVmBootstrapConfigRecord(deploymentTokenKey, value, options = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value;
  const deploymentToken = typeof candidate.deploymentToken === "string" ? candidate.deploymentToken.trim() : "";
  const profile = typeof candidate.profile === "string" ? candidate.profile.trim() : "";
  const ownerAddress = typeof candidate.ownerAddress === "string" ? candidate.ownerAddress.trim() : "";
  const instanceItemHash = typeof candidate.instanceItemHash === "string" ? candidate.instanceItemHash.trim() : "";
  const createdAt = typeof candidate.createdAt === "string" ? candidate.createdAt.trim() : "";
  const expiresAt = typeof candidate.expiresAt === "string" ? candidate.expiresAt.trim() : "";
  if (!deploymentTokenKey.trim() || !deploymentToken || deploymentToken !== deploymentTokenKey.trim() || !profile || !ownerAddress || !instanceItemHash || !createdAt || !expiresAt) {
    return null;
  }
  const nowMs = Math.max(0, Number(options.nowMs ?? Date.now()));
  const maxRecordAgeMs = Math.max(
    6e4,
    Number(options.maxRecordAgeMs ?? VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS)
  );
  const createdAtMs = parseTimestampMs(createdAt);
  const expiresAtMs = parseTimestampMs(expiresAt);
  if (createdAtMs == null || expiresAtMs == null) return null;
  if (expiresAtMs <= nowMs) return null;
  if (createdAtMs < nowMs - maxRecordAgeMs) return null;
  return candidate;
}
async function fetchVmBootstrapConfigAggregate(address, options) {
  const requestUrl = new URL(`/api/v0/aggregates/${address}.json`, options.apiHost ?? DEFAULT_ALEPH_API_HOST2);
  requestUrl.searchParams.set("keys", VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY);
  const response = await options.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (response.status === 404) return {};
  if (!response.ok) {
    throw new Error(`VM bootstrap config aggregate request failed: ${response.status}`);
  }
  const payload = await response.json();
  const aggregate = payload.data?.[VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY];
  if (!aggregate || typeof aggregate !== "object" || Array.isArray(aggregate)) return {};
  return aggregate;
}
function normalizeVmBootstrapConfigAggregate(aggregate, options = {}) {
  if (!aggregate || typeof aggregate !== "object") return {};
  return Object.fromEntries(
    Object.entries(aggregate).map(([deploymentToken, record]) => [
      deploymentToken,
      normalizeVmBootstrapConfigRecord(deploymentToken, record, options)
    ]).filter((entry) => entry[1] != null)
  );
}
function createVmBootstrapConfigAggregateContent(args) {
  const nowMs = Math.max(0, Number(args.now ?? Date.now() / 1e3) * 1e3);
  const content = normalizeVmBootstrapConfigAggregate(args.existingAggregate, {
    nowMs,
    maxRecordAgeMs: args.maxRecordAgeMs
  });
  content[args.record.deploymentToken] = args.record;
  return {
    address: args.sender,
    key: VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY,
    content,
    time: args.now ?? Date.now() / 1e3
  };
}
async function createUnsignedVmBootstrapConfigAggregateMessage(args) {
  const itemContent = JSON.stringify(args.content);
  const itemHash = await args.hasher(itemContent);
  return {
    sender: args.sender,
    chain: "ETH",
    type: "AGGREGATE",
    item_hash: itemHash,
    item_type: "inline",
    item_content: itemContent,
    time: args.now ?? Date.now() / 1e3,
    channel: args.channel ?? DEFAULT_ALEPH_CHANNEL
  };
}
async function publishVmBootstrapConfigAggregate(args) {
  const unsignedMessage = await createUnsignedVmBootstrapConfigAggregateMessage({
    sender: args.sender,
    content: args.content,
    hasher: args.hasher,
    channel: args.channel
  });
  const message = await signAlephMessage(unsignedMessage, args.signer);
  const { response, httpStatus } = await broadcastAlephMessage2(message, {
    apiHost: args.apiHost,
    sync: args.sync,
    fetch: args.fetch
  });
  const aggregateStatus = httpStatus >= 200 && httpStatus < 300 ? response.message_status ?? "processed" : "unknown";
  if (aggregateStatus === "rejected") {
    throw new Error(`VM bootstrap config aggregate was rejected by Aleph: ${JSON.stringify(response.details ?? response)}`);
  }
  return {
    aggregateItemHash: message.item_hash,
    aggregateStatus
  };
}
function normalizeAggregateMessageHashRecord(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value;
  const itemHash = typeof candidate.item_hash === "string" ? candidate.item_hash.trim() : "";
  if (!itemHash) return null;
  const content = candidate.content && typeof candidate.content === "object" && !Array.isArray(candidate.content) ? candidate.content : typeof candidate.item_content === "string" ? parseJsonObject(candidate.item_content) : null;
  if (!content || content.key !== VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY) return null;
  const timeMs = parseTimestampMs(candidate.time);
  if (timeMs == null) return null;
  return { itemHash, timeMs };
}
async function listStaleVmBootstrapConfigAggregateMessageHashes(args) {
  const address = args.address.trim();
  if (!address) return [];
  const currentAggregateItemHash = args.currentAggregateItemHash?.trim() ?? "";
  const olderThanMs = Math.max(
    6e4,
    Number(args.olderThanMs ?? VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS)
  );
  const cutoffMs = Math.max(0, Number(args.nowMs ?? Date.now()) - olderThanMs);
  const pagination = Math.max(1, Number(args.pagination ?? 100));
  const maxPages = Math.max(1, Number(args.maxPages ?? 10));
  const hashes = /* @__PURE__ */ new Set();
  for (let page = 1; page <= maxPages; page += 1) {
    const requestUrl = new URL("/api/v0/messages.json", args.apiHost ?? DEFAULT_ALEPH_API_HOST2);
    requestUrl.searchParams.set("msgType", "AGGREGATE");
    requestUrl.searchParams.set("addresses", address);
    requestUrl.searchParams.set("message_statuses", "processed,pending,rejected");
    requestUrl.searchParams.set("pagination", String(pagination));
    requestUrl.searchParams.set("page", String(page));
    requestUrl.searchParams.set("sortOrder", "-1");
    const response = await args.fetch(requestUrl.toString(), { cache: "no-cache" });
    if (!response.ok) {
      throw new Error(`VM bootstrap config aggregate history request failed: ${response.status}`);
    }
    const payload = await response.json();
    const messages = Array.isArray(payload.messages) ? payload.messages : [];
    if (messages.length === 0) break;
    for (const message of messages) {
      const normalized = normalizeAggregateMessageHashRecord(message);
      if (!normalized) continue;
      if (normalized.itemHash === currentAggregateItemHash) continue;
      if (normalized.timeMs > cutoffMs) continue;
      hashes.add(normalized.itemHash);
    }
    if (messages.length < pagination) break;
  }
  return [...hashes];
}
async function publishVmBootstrapConfig(args) {
  const aggregate = await fetchVmBootstrapConfigAggregate(args.sender, {
    apiHost: args.apiHost,
    fetch: args.fetch
  });
  const content = createVmBootstrapConfigAggregateContent({
    sender: args.sender,
    record: args.record,
    existingAggregate: aggregate,
    maxRecordAgeMs: VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS
  });
  const result = await publishVmBootstrapConfigAggregate({
    sender: args.sender,
    content,
    signer: args.signer,
    hasher: args.hasher,
    fetch: args.fetch,
    channel: args.channel,
    apiHost: args.apiHost,
    sync: args.sync
  });
  return {
    ...result,
    aggregate: content.content
  };
}
async function deleteVmBootstrapConfig(args) {
  const aggregate = await fetchVmBootstrapConfigAggregate(args.sender, {
    apiHost: args.apiHost,
    fetch: args.fetch
  });
  const content = normalizeVmBootstrapConfigAggregate(aggregate, {
    maxRecordAgeMs: VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS
  });
  delete content[args.deploymentToken];
  const publishResult = await publishVmBootstrapConfigAggregate({
    sender: args.sender,
    content: {
      address: args.sender,
      key: VM_BOOTSTRAP_CONFIG_AGGREGATE_KEY,
      content,
      time: Date.now() / 1e3
    },
    signer: args.signer,
    hasher: args.hasher,
    fetch: args.fetch,
    channel: args.channel,
    apiHost: args.apiHost,
    sync: args.sync
  });
  return {
    ...publishResult,
    aggregate: content
  };
}
function normalizeVmBootstrapConfigSignalRecord(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value;
  const deploymentToken = typeof candidate.deploymentToken === "string" ? candidate.deploymentToken.trim() : "";
  const status = typeof candidate.status === "string" ? candidate.status.trim() : "";
  const profile = typeof candidate.profile === "string" ? candidate.profile.trim() : "";
  const ownerAddress = typeof candidate.ownerAddress === "string" ? candidate.ownerAddress.trim() : "";
  const instanceItemHash = typeof candidate.instanceItemHash === "string" ? candidate.instanceItemHash.trim() : "";
  const updatedAt = typeof candidate.updatedAt === "string" ? candidate.updatedAt.trim() : "";
  if (!deploymentToken || !status || !profile || !ownerAddress || !instanceItemHash || !updatedAt) {
    return null;
  }
  return {
    deploymentToken,
    status,
    profile,
    ownerAddress,
    instanceItemHash,
    updatedAt,
    publisherAddress: typeof candidate.publisherAddress === "string" && candidate.publisherAddress.trim() ? candidate.publisherAddress.trim() : null,
    authorization: candidate.authorization,
    peerId: typeof candidate.peerId === "string" && candidate.peerId.trim() ? candidate.peerId.trim() : null,
    probeMultiaddrs: Array.isArray(candidate.probeMultiaddrs) ? candidate.probeMultiaddrs.filter(
      (entry) => typeof entry === "string" && entry.trim().length > 0
    ) : [],
    browserBootstrapMultiaddrs: Array.isArray(candidate.browserBootstrapMultiaddrs) ? candidate.browserBootstrapMultiaddrs.filter(
      (entry) => typeof entry === "string" && entry.trim().length > 0
    ) : []
  };
}
async function fetchVmBootstrapConfigSignals(args) {
  const requestUrl = new URL("/api/v0/posts.json", args.apiHost ?? DEFAULT_ALEPH_API_HOST2);
  requestUrl.searchParams.set("refs", args.ref ?? VM_BOOTSTRAP_CONFIG_SIGNAL_REF);
  requestUrl.searchParams.set("types", args.postType ?? VM_BOOTSTRAP_CONFIG_SIGNAL_POST_TYPE);
  requestUrl.searchParams.set("pagination", String(Math.max(1, Number(args.pagination ?? 100))));
  requestUrl.searchParams.set("page", String(Math.max(1, Number(args.page ?? 1))));
  requestUrl.searchParams.set("sortOrder", "-1");
  const response = await args.fetch(requestUrl.toString(), { cache: "no-cache" });
  if (!response.ok) {
    throw new Error(`VM bootstrap config signal request failed: ${response.status}`);
  }
  const payload = await response.json();
  const expectedDeploymentToken = args.deploymentToken?.trim() ?? "";
  const expectedOwnerAddress = args.ownerAddress?.trim().toLowerCase() ?? "";
  const expectedInstanceItemHash = args.instanceItemHash?.trim() ?? "";
  return (payload.posts ?? []).map((entry) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
    const parsed = "content" in entry && entry.content && typeof entry.content === "object" && !Array.isArray(entry.content) ? entry.content : "item_content" in entry && typeof entry.item_content === "string" ? parseJsonObject(entry.item_content) : null;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
    const content = "deploymentToken" in parsed ? parsed : "content" in parsed && parsed.content && typeof parsed.content === "object" && !Array.isArray(parsed.content) ? parsed.content : null;
    if (!content || typeof content !== "object" || Array.isArray(content)) return null;
    return normalizeVmBootstrapConfigSignalRecord(content);
  }).filter((entry) => {
    if (!entry) return false;
    if (expectedDeploymentToken && entry.deploymentToken !== expectedDeploymentToken) return false;
    if (expectedOwnerAddress && entry.ownerAddress.toLowerCase() !== expectedOwnerAddress) return false;
    if (expectedInstanceItemHash && entry.instanceItemHash !== expectedInstanceItemHash) return false;
    return true;
  });
}
async function waitForVmBootstrapConfigSignal(args) {
  const attempts = Math.max(1, Number(args.attempts ?? 24));
  const delayMs = Math.max(0, Number(args.delayMs ?? 2500));
  const sleep2 = args.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const expectedStatus = args.expectedStatus ?? "applied";
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const signals = await fetchVmBootstrapConfigSignals({
      deploymentToken: args.deploymentToken,
      ownerAddress: args.ownerAddress,
      instanceItemHash: args.instanceItemHash,
      fetch: args.fetch,
      apiHost: args.apiHost,
      ref: args.ref,
      postType: args.postType
    }).catch(() => []);
    const match = signals.find((entry) => entry.status === expectedStatus) ?? null;
    if (match) return match;
    if (attempt < attempts - 1) {
      await sleep2(delayMs);
    }
  }
  return null;
}

// ../core/src/bootstrap-reconcile.ts
function createRelayBootstrapRegistrationId(profile, instanceName, itemHash) {
  const normalizedName = String(instanceName ?? "").trim();
  const normalizedHash = String(itemHash ?? "").trim();
  if (!normalizedHash) {
    return `relay:${profile}:${normalizedName || "instance"}`;
  }
  return `relay:${profile}:${normalizedName || normalizedHash}:${normalizedHash}`;
}
function secureBootstrapMetadataUrl(proxyUrl) {
  const normalized = String(proxyUrl ?? "").trim();
  if (!normalized) return null;
  try {
    return new URL("/bootstrap/metadata", normalized).toString();
  } catch {
    return null;
  }
}
function extractRelayMetadata(payload) {
  const metadata = payload && typeof payload === "object" && payload.metadata && typeof payload.metadata === "object" ? payload.metadata : null;
  const peerId = typeof metadata?.peer_id === "string" ? metadata.peer_id : null;
  const probeMultiaddrs = Array.isArray(metadata?.probe_multiaddrs) ? metadata.probe_multiaddrs.filter((entry) => typeof entry === "string") : [];
  const browserBootstrapMultiaddrs = Array.isArray(metadata?.browser_bootstrap_multiaddrs) ? metadata.browser_bootstrap_multiaddrs.filter((entry) => typeof entry === "string") : [];
  if (!peerId || probeMultiaddrs.length === 0) return null;
  return {
    peerId,
    probeMultiaddrs,
    browserBootstrapMultiaddrs
  };
}
async function fetchRelayMetadataForRuntime(args) {
  const setupPort = args.runtime.mappedPorts?.["80"]?.host ?? 80;
  const metadataUrl = args.preferSecureMetadata ? secureBootstrapMetadataUrl(args.runtime.proxyUrl) : null;
  if (args.preferSecureMetadata && !metadataUrl) {
    return null;
  }
  const payload = await fetchUcGoPeerMetadata({
    hostIpv4: args.runtime.hostIpv4 ?? "",
    setupPort,
    metadataUrl,
    fetch: args.fetch,
    attempts: args.attempts,
    delayMs: args.delayMs,
    timeoutMs: args.timeoutMs,
    isReady: (result) => extractRelayMetadata(result.payload) != null,
    onAttempt: (result) => {
      args.onAttempt?.({
        ...result,
        metadataUrl,
        hostIpv4: args.runtime.hostIpv4 ?? null,
        setupPort
      });
    }
  }).catch(() => null);
  return extractRelayMetadata(payload);
}

// src/shared/events.ts
function createDeploymentProgressEmitter() {
  const listeners = /* @__PURE__ */ new Set();
  return {
    emit(event) {
      listeners.forEach((listener) => listener(event));
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    clear() {
      listeners.clear();
    }
  };
}

// src/shared/controller.ts
function asJsonFetch(input, init) {
  return fetch(input, init).then(async (response) => ({
    ok: response.ok,
    status: response.status,
    json: async () => await response.json()
  }));
}
function isConfirmedRelaySetupResult(value) {
  return Boolean(
    value && typeof value === "object" && "status" in value && value.status === "configured"
  );
}
function defaultState(props = {}) {
  return {
    ready: false,
    open: Boolean(props.openByDefault),
    wallet: {
      connected: false,
      address: null,
      chainId: null,
      isMetaMask: false
    },
    manifestUrl: props.manifestUrl ?? DEFAULT_MANIFEST_URL,
    manifestJson: props.manifestJson ?? "",
    sshPublicKey: props.sshPublicKey ?? "",
    instanceName: props.instanceName ?? DEFAULT_INSTANCE_NAME,
    tierId: DEFAULT_TIER_ID,
    showAdvanced: Boolean(props.manifestJson?.trim() || props.sshPublicKey?.trim()),
    showInstances: props.showInstances ?? true,
    showPasteManifest: Boolean(props.manifestJson?.trim()),
    busy: {
      connectingWallet: false,
      refreshing: false,
      deploying: false,
      deletingInstanceHash: null,
      deletingRegistrationHash: null
    },
    statusText: "Ready",
    errorText: null,
    manifestState: {
      manifest: null,
      valid: false,
      errors: ["Manifest not loaded yet."]
    },
    manifest: null,
    rootfsResolution: null,
    rootfsVerified: false,
    rootfsHealth: ROOTFS_MISSING_STATE,
    pricingSummary: {
      pricing: null,
      tier: null,
      requiredCredits: null,
      availableCredits: null,
      vcpus: null,
      memoryMiB: null,
      diskMiB: null
    },
    balance: null,
    crns: [],
    selectedCrn: null,
    instances: [],
    bootstrapRegistrations: [],
    orphanBootstrapRegistrations: [],
    lastDeploymentHash: null,
    deploymentProgress: IDLE_DEPLOYMENT_PROGRESS
  };
}
function manifestLoadErrorState(error) {
  const message = error instanceof Error ? error.message : String(error);
  return {
    manifest: null,
    valid: false,
    errors: [message]
  };
}
function isDebugEnabled(props) {
  if (props.debug) {
    return true;
  }
  try {
    return globalThis.localStorage?.getItem("LE_SPACE_UI_DEBUG") === "1";
  } catch {
    return false;
  }
}
async function sha256Hex(payload) {
  const digest = await globalThis.crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(payload)
  );
  return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function mappedPorts(execution) {
  return Object.entries(execution?.networking?.mapped_ports ?? {}).map(
    ([port, mapping]) => ({
      label: `${port}/${mapping.udp ? "udp" : "tcp"}`,
      hostPort: mapping.host ?? null
    })
  );
}
function runtimeMappedPorts(mappedPortsRecord) {
  return Object.entries(mappedPortsRecord ?? {}).map(([port, mapping]) => ({
    label: `${port}/${mapping.udp ? "udp" : "tcp"}`,
    hostPort: mapping.host ?? null
  }));
}
function rootfsHealth(args) {
  if (!args.manifestState.valid || !args.manifestState.manifest) {
    return {
      tone: "error",
      label: "manifest invalid",
      detail: args.manifestState.errors[0] ?? "Manifest could not be parsed."
    };
  }
  if (!args.rootfsVerified) {
    return {
      tone: "error",
      label: "not found on Aleph",
      detail: "The manifest points to a rootfs STORE message that Aleph cannot find. Check that the manifest URL is correct and that the referenced rootfs was not forgotten."
    };
  }
  if (!args.resolution) {
    return {
      tone: "caution",
      label: "verifying rootfs",
      detail: "The rootfs reference is still being resolved."
    };
  }
  if (args.resolution.messageStatus === "processed") {
    return {
      tone: "ok",
      label: "deployable",
      detail: args.resolution.gatewayUrl
    };
  }
  if (args.resolution.messageStatus === "pending" && args.resolution.gatewayStatus === "reachable") {
    return {
      tone: "caution",
      label: "pending but reachable",
      detail: "Gateway probe succeeded even though Aleph still reports pending."
    };
  }
  if (args.resolution.messageStatus === "pending") {
    return {
      tone: "caution",
      label: "pending on Aleph",
      detail: "Wait until the STORE message is processed."
    };
  }
  return {
    tone: "error",
    label: "manifest rootfs not deployable",
    detail: args.resolution.rejectionReason ?? (args.resolution.messageType === "STORE" ? "This manifest points to a rootfs STORE message that exists but is not deployable anymore, for example because it was forgotten or replaced. Double-check the manifest URL." : "Aleph rejected the rootfs reference. Double-check that the manifest URL points to the intended current rootfs.")
  };
}
async function resolveManifest(args) {
  const pasted = resolveManifestSource({ manifestJson: args.manifestJson });
  if (pasted) return pasted;
  return loadRootfsManifest(args.manifestUrl);
}
function relayProfileForManifest(manifest) {
  if (manifest?.profile === "uc-go-peer") return "uc-go-peer";
  if (manifest?.profile === "orbitdb-relay-pinner") {
    return "orbitdb-relay-pinner";
  }
  return null;
}
function registrationIdInstanceItemHash(registrationId) {
  const normalized = String(registrationId ?? "").trim();
  if (!normalized) return null;
  const parts = normalized.split(":").map((part) => part.trim()).filter(Boolean);
  const candidate = parts.at(-1) ?? "";
  return /^[0-9a-f]{64}$/i.test(candidate) ? candidate : null;
}
function relayBootstrapInstanceItemHash(entry) {
  const authorizedInstanceItemHash = typeof entry?.content?.authorization?.payload?.instanceItemHash === "string" ? entry.content.authorization.payload.instanceItemHash.trim() : "";
  if (authorizedInstanceItemHash) {
    return authorizedInstanceItemHash;
  }
  return registrationIdInstanceItemHash(entry?.content?.registrationId);
}
function relayBootstrapMatchesCurrentWallet(entry, normalizedWalletAddress, activeInstanceHashes) {
  const instanceItemHash = relayBootstrapInstanceItemHash(entry);
  if (instanceItemHash && activeInstanceHashes.has(instanceItemHash)) {
    return true;
  }
  const candidateAddresses = [
    entry?.address,
    entry?.content?.ownerAddress,
    entry?.content?.authorization?.payload?.ownerAddress,
    entry?.content?.publisherAddress,
    entry?.content?.authorization?.payload?.publisherAddress
  ];
  return candidateAddresses.some(
    (value) => typeof value === "string" && value.trim().toLowerCase() === normalizedWalletAddress
  );
}
async function inspectInstanceRuntime(args) {
  const details = {
    messageStatus: String(
      args.instance.status ?? (args.instance.confirmed ? "processed" : "unknown")
    ).toLowerCase(),
    allocationSource: null,
    crnUrl: null,
    hostIpv4: null,
    ipv6: null,
    vmIpv4: null,
    webUrl: null,
    sshCommand: null,
    mappedPorts: [],
    execution: null,
    error: null
  };
  const lookup = {
    allocationFound: false,
    allocationSource: null,
    crnUrl: null,
    webUrl: null,
    executionPayloadFound: false,
    executionLookupBlocked: false,
    executionLookupRequestUrl: null,
    executionLookupVersion: null
  };
  if (details.messageStatus === "rejected") {
    return { details, lookup };
  }
  try {
    const allocation = await args.client.fetchSchedulerAllocation(args.instance.item_hash) ?? (() => {
      const nodeHash = args.instance.content?.requirements?.node?.node_hash;
      const crn = args.crns.find((candidate) => candidate.hash === nodeHash);
      return nodeHash ? {
        source: "manual",
        crnHash: nodeHash,
        crnUrl: crn?.address ?? null,
        node: crn ? { url: crn.address } : null,
        vmIpv6: null,
        period: null
      } : null;
    })();
    lookup.allocationFound = Boolean(allocation);
    lookup.allocationSource = allocation?.source ?? null;
    details.allocationSource = allocation?.source ?? null;
    details.crnUrl = allocation?.crnUrl ?? null;
    details.ipv6 = allocation?.vmIpv6 ?? null;
    details.webUrl = await args.client.fetch2n6WebAccessUrl(
      args.instance.item_hash
    );
    lookup.crnUrl = details.crnUrl;
    lookup.webUrl = details.webUrl;
    if (!allocation?.crnUrl) {
      return { details, lookup };
    }
    const executionLookup = await args.client.fetchCrnExecutionMap(
      allocation.crnUrl
    );
    lookup.executionLookupBlocked = executionLookup.blocked;
    lookup.executionLookupRequestUrl = executionLookup.requestUrl ?? null;
    lookup.executionLookupVersion = executionLookup.version ?? null;
    const executionPayload = executionLookup.payload?.[args.instance.item_hash];
    lookup.executionPayloadFound = Boolean(executionPayload);
    if (!executionPayload) {
      return { details, lookup };
    }
    const execution = normalizeExecution(executionPayload, allocation.crnUrl);
    if (!execution.networking.proxy_url && details.webUrl) {
      execution.networking.proxy_url = details.webUrl;
    }
    details.messageStatus = "processed";
    details.execution = execution;
    details.hostIpv4 = execution.networking.host_ipv4 ?? execution.networking.ipv4 ?? null;
    details.ipv6 = execution.networking.ipv6_ip ?? execution.networking.ipv6 ?? details.ipv6;
    details.vmIpv4 = execution.networking.ipv4_ip ?? null;
    details.webUrl = execution.networking.proxy_url ?? details.webUrl;
    details.mappedPorts = mappedPorts(execution);
    details.sshCommand = buildSshCommand(details.hostIpv4, details.mappedPorts);
    return { details, lookup };
  } catch (error) {
    return {
      details: {
        ...details,
        error: error instanceof Error ? error.message : String(error)
      },
      lookup
    };
  }
}
function instanceTimestampMs(instance) {
  const value = instance.reception_time ?? instance.time;
  if (!value) return null;
  if (typeof value === "number") {
    return value > 0 && value < 1e10 ? value * 1e3 : value;
  }
  const parsed = Date.parse(value);
  return Number.isNaN(parsed) ? null : parsed;
}
function compatibleCrnsForTier(crns, state) {
  if (!state.pricingSummary.pricing || !state.pricingSummary.tier) {
    return [];
  }
  const spec = tierSpec(
    state.pricingSummary.pricing,
    state.pricingSummary.tier
  );
  return filterDeployableCrns(crns, { spec });
}
var UI_DEPLOY_WAIT_ATTEMPTS = 60;
var UI_DEPLOY_WAIT_DELAY_MS = 5e3;
var UI_RUNTIME_WAIT_ATTEMPTS = 40;
var UI_RUNTIME_WAIT_DELAY_MS = 5e3;
function hasUsableRuntime(details) {
  return Boolean(details.hostIpv4) || Boolean(details.vmIpv4) || details.mappedPorts.length > 0 || Boolean(details.webUrl) || Boolean(details.execution);
}
function toSharedRootfsManifest(manifest) {
  if (!manifest) {
    return null;
  }
  return {
    profile: manifest.profile,
    version: manifest.version,
    rootfsInstallStrategy: manifest.rootfsInstallStrategy === "thin" || manifest.rootfsInstallStrategy === "prebaked" ? manifest.rootfsInstallStrategy : void 0,
    requiresBootstrapNetwork: manifest.requiresBootstrapNetwork,
    bootstrapSummary: manifest.bootstrapSummary,
    rootfsItemHash: manifest.rootfsItemHash,
    rootfsSizeMiB: manifest.rootfsSizeMiB,
    rootfsSourceSizeBytes: manifest.rootfsSourceSizeBytes,
    requiredPortForwards: manifest.requiredPortForwards,
    createdAt: manifest.createdAt,
    notes: manifest.notes
  };
}
var SponsorRelayController = class {
  state;
  subscribers = /* @__PURE__ */ new Set();
  client;
  refreshTimer = null;
  manifestRefreshTimer = null;
  stopWalletWatch = null;
  props;
  progressEmitter = createDeploymentProgressEmitter();
  runtimeCooldownByHash = /* @__PURE__ */ new Map();
  runtimeDetailsByHash = /* @__PURE__ */ new Map();
  debugEnabled;
  lastCompletedDeploymentHash = null;
  constructor(props = {}) {
    this.props = props;
    this.state = defaultState(props);
    this.debugEnabled = isDebugEnabled(props);
    this.client = createAlephBrowserClient({
      apiHost: props.apiHost,
      crnListUrl: props.crnListUrl,
      schedulerApiHost: props.schedulerApiHost,
      twoN6ApiHost: props.twoN6ApiHost
    });
  }
  subscribeToDeploymentProgress(listener) {
    return this.progressEmitter.subscribe(listener);
  }
  subscribe(subscriber) {
    this.subscribers.add(subscriber);
    return () => {
      this.subscribers.delete(subscriber);
    };
  }
  getState() {
    return this.state;
  }
  updateProps(props) {
    this.props = { ...this.props, ...props };
    this.debugEnabled = isDebugEnabled(this.props);
  }
  emit() {
    const next = this.state;
    this.subscribers.forEach((subscriber) => subscriber(next));
  }
  trace(message, data) {
    if (!this.debugEnabled) {
      return;
    }
    if (data === void 0) {
      console.debug("[le-space/ui]", message);
      return;
    }
    console.debug("[le-space/ui]", message, data);
  }
  patch(patch) {
    this.state = {
      ...this.state,
      ...patch,
      busy: patch.busy ? { ...this.state.busy, ...patch.busy } : this.state.busy,
      wallet: patch.wallet ? { ...this.state.wallet, ...patch.wallet } : this.state.wallet,
      pricingSummary: patch.pricingSummary ? { ...this.state.pricingSummary, ...patch.pricingSummary } : this.state.pricingSummary
    };
    this.emit();
  }
  emitProgress(event) {
    const nextEvent = {
      ...event,
      timestamp: Date.now()
    };
    this.trace(`progress:${nextEvent.stage}`, {
      label: nextEvent.label,
      progress: nextEvent.progress,
      status: nextEvent.status,
      itemHash: nextEvent.itemHash ?? null,
      detail: nextEvent.detail ?? null,
      error: nextEvent.error ?? null
    });
    this.patch({
      deploymentProgress: nextEvent,
      statusText: event.error ?? event.detail ?? event.label,
      errorText: event.status === "error" ? event.error ?? event.detail ?? event.label : this.state.errorText
    });
    this.progressEmitter.emit(nextEvent);
  }
  async configureRelayBootstrapRegistration(args) {
    const profile = relayProfileForManifest(this.state.manifest);
    if (!profile) return;
    if (!this.state.wallet.address) {
      throw new Error("A connected wallet is required to register relay bootstrap addresses.");
    }
    if (!args.runtime.hostIpv4) {
      throw new Error("Relay runtime did not expose a host IPv4 address.");
    }
    let runtime = args.runtime;
    let mappedPorts2 = runtime.mappedPorts ?? {};
    const setupPort = mappedPorts2["80"]?.host ?? null;
    if (!setupPort) {
      throw new Error("Relay runtime did not expose the temporary setup endpoint.");
    }
    let bootstrapSignalRelayMetadata = null;
    if (profile === "orbitdb-relay-pinner") {
      this.emitProgress({
        stage: "deployment-confirmed",
        label: "Configuring relay",
        progress: 93,
        status: "info",
        itemHash: args.itemHash,
        detail: "Waiting for the guest setup endpoint before collecting relay metadata."
      });
      const setupHealth = await waitForSetupEndpoint({
        hostIpv4: args.runtime.hostIpv4,
        setupPort,
        fetch: (url, init) => fetch(url, init),
        attempts: 15,
        delayMs: 4e3,
        httpTimeoutMs: 1e4,
        onAttempt: (result, attempt, attempts) => {
          this.emitProgress({
            stage: "deployment-confirmed",
            label: "Waiting for guest setup",
            progress: 93,
            status: result.ok ? "success" : "info",
            itemHash: args.itemHash,
            detail: result.ok ? `Setup endpoint ${attempt}/${attempts}: ready at http://${args.runtime.hostIpv4}:${setupPort}/health.` : `Setup endpoint ${attempt}/${attempts}: waiting for http://${args.runtime.hostIpv4}:${setupPort}/health.`
          });
        }
      });
      if (!setupHealth.ok) {
        throw new Error(
          `Relay setup endpoint did not become reachable at http://${args.runtime.hostIpv4}:${setupPort}/health.`
        );
      }
      this.emitProgress({
        stage: "deployment-confirmed",
        label: "Applying relay networking",
        progress: 93,
        status: "info",
        itemHash: args.itemHash,
        detail: "Publishing the host port mapping into the guest relay configuration."
      });
      const tcpPort = mappedPorts2["9091"]?.host ?? 0;
      const wsPort = mappedPorts2["9092"]?.host ?? mappedPorts2["443"]?.host ?? 0;
      if (!tcpPort || !wsPort) {
        throw new Error("OrbitDB relay runtime is missing required mapped TCP/WS ports.");
      }
      const configureResult = await configureOrbitdbRelaySetup2({
        hostIpv4: args.runtime.hostIpv4,
        publicIpv6: args.runtime.ipv6,
        setupPort,
        tcpPort,
        wsPort,
        proxyUrl: args.runtime.proxyUrl ?? void 0,
        metricsPort: mappedPorts2["9090"]?.host ?? null,
        metricsHttpsPort: mappedPorts2["443"]?.host ?? null,
        webrtcPort: mappedPorts2["9093"]?.host ?? null,
        quicPort: mappedPorts2["9094"]?.host ?? null,
        fetch: (url, init) => fetch(url, init),
        timeoutMs: 18e4
      });
      if (!isConfirmedRelaySetupResult(configureResult)) {
        throw new Error(
          `Relay guest configuration could not be confirmed at http://${args.runtime.hostIpv4}:${setupPort}/configure.`
        );
      }
    } else {
      if (!args.deploymentToken) {
        throw new Error("Missing deployment token for Aleph bootstrap config handoff.");
      }
      if (runtime.proxyUrl && runtime.webAccess?.active !== true) {
        this.emitProgress({
          stage: "deployment-confirmed",
          label: "Waiting for HTTPS route",
          progress: 93,
          status: "warning",
          itemHash: args.itemHash,
          detail: "The relay received a 2n6 hostname, but it is not active yet. Waiting before handing HTTPS config to the guest."
        });
        let latestRuntime = runtime;
        for (let attempt = 0; attempt < UI_RUNTIME_WAIT_ATTEMPTS; attempt += 1) {
          if (latestRuntime.webAccess?.active === true) {
            break;
          }
          await new Promise(
            (resolve) => globalThis.setTimeout(resolve, UI_RUNTIME_WAIT_DELAY_MS)
          );
          latestRuntime = await fetchVmRuntime({
            itemHash: args.itemHash,
            fetch: (url, init) => fetch(url, init),
            crnHash: runtime.selectedCrn?.hash ?? runtime.allocation?.crnHash ?? void 0,
            crns: this.state.crns,
            crnListUrl: this.props.crnListUrl,
            requirePublicGuestIpv6ForProxy: true
          }).catch(() => latestRuntime);
          this.emitProgress({
            stage: "deployment-confirmed",
            label: "Waiting for HTTPS route",
            progress: 93,
            status: latestRuntime.webAccess?.active === true ? "info" : "warning",
            itemHash: args.itemHash,
            detail: `2n6 activation ${attempt + 1}/${UI_RUNTIME_WAIT_ATTEMPTS}: ${latestRuntime.webAccess?.active === true ? "active" : "still pending"} for ${latestRuntime.proxyUrl ?? runtime.proxyUrl ?? "reserved proxy URL"}.`
          });
          this.trace("deploy:bootstrap-proxy-activation", {
            itemHash: args.itemHash,
            attempt: attempt + 1,
            attempts: UI_RUNTIME_WAIT_ATTEMPTS,
            active: latestRuntime.webAccess?.active === true,
            proxyUrl: latestRuntime.proxyUrl ?? null
          });
        }
        runtime = latestRuntime;
        mappedPorts2 = runtime.mappedPorts ?? mappedPorts2;
      }
      if (!runtime.hostIpv4) {
        throw new Error(
          "Relay runtime lost its host IPv4 address while waiting for HTTPS activation."
        );
      }
      const runtimeHostIpv4 = runtime.hostIpv4;
      const activeProxyUrl = runtime.webAccess?.active === true ? runtime.proxyUrl ?? null : null;
      this.emitProgress({
        stage: "deployment-confirmed",
        label: "Publishing relay config",
        progress: 93,
        status: "info",
        itemHash: args.itemHash,
        detail: "Publishing runtime networking into the Aleph guest bootstrap config aggregate."
      });
      const record = {
        deploymentToken: args.deploymentToken,
        profile,
        ownerAddress: this.state.wallet.address,
        instanceItemHash: args.itemHash,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        expiresAt: new Date(Date.now() + 30 * 6e4).toISOString(),
        status: "pending",
        runtime: {
          publicIpv4: runtimeHostIpv4,
          publicIpv6: runtime.ipv6 ?? null,
          proxyUrl: activeProxyUrl,
          mappedPorts: mappedPorts2
        },
        bootstrap: {
          registrationId: createRelayBootstrapRegistrationId(
            profile,
            this.state.instanceName.trim(),
            args.itemHash
          )
        }
      };
      const bootstrapConfigPublication = await publishVmBootstrapConfig({
        sender: this.state.wallet.address,
        record,
        signer: personalSign,
        hasher: sha256Hex,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        sync: true
      });
      this.trace("deploy:bootstrap-config-published", {
        itemHash: args.itemHash,
        deploymentToken: args.deploymentToken,
        registrationId: record.bootstrap?.registrationId ?? null,
        proxyUrl: record.runtime.proxyUrl ?? null,
        mappedPorts: record.runtime.mappedPorts,
        aggregateItemHash: bootstrapConfigPublication.aggregateItemHash,
        aggregateStatus: bootstrapConfigPublication.aggregateStatus
      });
      this.emitProgress({
        stage: "deployment-confirmed",
        label: "Waiting for guest config",
        progress: 94,
        status: "info",
        itemHash: args.itemHash,
        detail: "Waiting for the relay VM to acknowledge that it consumed the Aleph bootstrap config."
      });
      const bootstrapConfigSignal = await waitForVmBootstrapConfigSignal({
        deploymentToken: args.deploymentToken,
        ownerAddress: this.state.wallet.address,
        instanceItemHash: args.itemHash,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        attempts: 40,
        delayMs: 3e3
      });
      this.trace("deploy:bootstrap-config-signal-visible", {
        itemHash: args.itemHash,
        deploymentToken: args.deploymentToken,
        bootstrapConfigSignal
      });
      if (!bootstrapConfigSignal) {
        throw new Error(
          "The relay VM did not confirm that it applied the Aleph bootstrap config in time."
        );
      }
      bootstrapSignalRelayMetadata = typeof bootstrapConfigSignal.peerId === "string" && bootstrapConfigSignal.peerId.length > 0 && Array.isArray(bootstrapConfigSignal.probeMultiaddrs) && bootstrapConfigSignal.probeMultiaddrs.length > 0 ? {
        peerId: bootstrapConfigSignal.peerId,
        probeMultiaddrs: bootstrapConfigSignal.probeMultiaddrs,
        browserBootstrapMultiaddrs: bootstrapConfigSignal.browserBootstrapMultiaddrs ?? []
      } : null;
      if (runtime.proxyUrl && runtime.webAccess?.active !== true) {
        this.trace("deploy:bootstrap-proxy-fallback", {
          itemHash: args.itemHash,
          deploymentToken: args.deploymentToken,
          proxyUrl: runtime.proxyUrl,
          bootstrapSignalRelayMetadata
        });
        this.emitProgress({
          stage: "deployment-confirmed",
          label: "Continuing without HTTPS route",
          progress: 94,
          status: "warning",
          itemHash: args.itemHash,
          detail: "The 2n6 HTTPS route stayed inactive, so guest setup continued without Caddy. Secure browser routing can be enabled later when the proxy becomes available."
        });
        runtime = {
          ...runtime,
          proxyUrl: null,
          webAccess: runtime.webAccess ? {
            ...runtime.webAccess,
            active: false
          } : runtime.webAccess
        };
      }
    }
    let relayMetadata = bootstrapSignalRelayMetadata;
    if (relayMetadata) {
      this.trace("deploy:relay-metadata-from-bootstrap-signal", {
        itemHash: args.itemHash,
        peerId: relayMetadata.peerId,
        probeMultiaddrCount: relayMetadata.probeMultiaddrs.length,
        browserBootstrapMultiaddrCount: relayMetadata.browserBootstrapMultiaddrs.length
      });
    } else {
      this.emitProgress({
        stage: "publishing-bootstrap",
        label: "Waiting for secure relay metadata",
        progress: 95,
        status: "warning",
        itemHash: args.itemHash,
        detail: "Runtime networking is available. Waiting for the secure relay metadata endpoint to report final public multiaddrs."
      });
      relayMetadata = await fetchRelayMetadataForRuntime({
        runtime,
        fetch: (url, init) => fetch(url, init),
        preferSecureMetadata: profile === "uc-go-peer" && Boolean(runtime.proxyUrl),
        attempts: 80,
        delayMs: 3e3,
        timeoutMs: 24e4,
        onAttempt: (result) => {
          const payload = result.payload && typeof result.payload === "object" ? result.payload : null;
          const metadata = payload?.metadata && typeof payload.metadata === "object" ? payload.metadata : null;
          this.trace("deploy:relay-metadata-attempt", {
            itemHash: args.itemHash,
            attempt: result.attempt,
            attempts: result.attempts,
            requestUrl: result.requestUrl,
            metadataUrl: result.metadataUrl,
            hostIpv4: result.hostIpv4,
            setupPort: result.setupPort,
            ok: result.ok,
            status: result.status,
            ready: result.ready,
            error: result.error ?? null,
            payloadStatus: payload && typeof payload.status === "string" ? payload.status : null,
            peerId: metadata && typeof metadata.peer_id === "string" ? metadata.peer_id : null,
            probeMultiaddrCount: Array.isArray(metadata?.probe_multiaddrs) ? metadata.probe_multiaddrs.length : 0,
            browserBootstrapMultiaddrCount: Array.isArray(
              metadata?.browser_bootstrap_multiaddrs
            ) ? metadata.browser_bootstrap_multiaddrs.length : 0
          });
          this.emitProgress({
            stage: "publishing-bootstrap",
            label: result.ready ? "Secure relay metadata ready" : "Waiting for secure relay metadata",
            progress: 95,
            status: result.ready ? "success" : "warning",
            itemHash: args.itemHash,
            detail: result.ready ? `Relay metadata ${result.attempt}/${result.attempts}: secure endpoint responded and public multiaddrs are available.` : `Relay metadata ${result.attempt}/${result.attempts}: waiting for ${result.metadataUrl}.`
          });
        }
      });
    }
    if (!relayMetadata) {
      await this.refresh().catch(() => void 0);
      const confirmedAfterRefresh = this.state.bootstrapRegistrations.some(
        (entry) => entry.instanceItemHash === args.itemHash && entry.confirmed
      );
      if (confirmedAfterRefresh) {
        this.trace("deploy:relay-metadata-recovered-from-refresh", {
          itemHash: args.itemHash
        });
        return;
      }
      throw new Error("Relay metadata did not include a peer ID and public multiaddrs.");
    }
    const { peerId } = relayMetadata;
    const registrationId = createRelayBootstrapRegistrationId(
      profile,
      this.state.instanceName.trim(),
      args.itemHash
    );
    this.emitProgress({
      stage: "publishing-bootstrap",
      label: "Waiting for guest bootstrap registration",
      progress: 97,
      status: "info",
      itemHash: args.itemHash,
      detail: "Waiting for the relay VM to publish its own bootstrap registration to Aleph."
    });
    const visibleRegistration = await waitForRelayBootstrapRegistration({
      registrationId,
      peerId,
      fetch: asJsonFetch,
      apiHost: this.client.apiHost,
      attempts: 24,
      delayMs: 2500,
      onAttempt: (match, attempt, attempts) => {
        this.emitProgress({
          stage: "publishing-bootstrap",
          label: "Waiting for guest bootstrap registration",
          progress: 97,
          status: match ? "success" : "info",
          itemHash: args.itemHash,
          detail: match ? `Guest bootstrap registration ${attempt}/${attempts}: visible on Aleph.` : `Guest bootstrap registration ${attempt}/${attempts}: still waiting for the relay VM registration on Aleph.`
        });
      }
    });
    this.trace("deploy:bootstrap-registration-visible", {
      itemHash: args.itemHash,
      registrationId,
      peerId,
      visibleRegistration
    });
    if (!visibleRegistration) {
      this.trace("deploy:bootstrap-registration-fallback-start", {
        itemHash: args.itemHash,
        registrationId,
        peerId,
        probeMultiaddrCount: relayMetadata.probeMultiaddrs.length,
        browserBootstrapMultiaddrCount: relayMetadata.browserBootstrapMultiaddrs.length
      });
      this.emitProgress({
        stage: "publishing-bootstrap",
        label: "Publishing bootstrap fallback",
        progress: 98,
        status: "warning",
        itemHash: args.itemHash,
        detail: "Guest bootstrap registration was delayed. Publishing the relay bootstrap record from the browser."
      });
      const fallbackPublication = await publishRelayBootstrapRegistration({
        sender: this.state.wallet.address,
        signer: personalSign,
        hasher: sha256Hex,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        peerId,
        multiaddrs: relayMetadata.probeMultiaddrs,
        browserMultiaddrs: relayMetadata.browserBootstrapMultiaddrs,
        registrationId,
        profile,
        sync: true,
        forgetPrevious: true
      });
      this.trace("deploy:bootstrap-registration-fallback-published", {
        itemHash: args.itemHash,
        registrationId,
        peerId,
        fallbackPublication
      });
      const fallbackVisibleRegistration = await waitForRelayBootstrapRegistration({
        sender: this.state.wallet.address,
        registrationId,
        peerId,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        attempts: 24,
        delayMs: 2500,
        onAttempt: (match, attempt, attempts) => {
          this.emitProgress({
            stage: "publishing-bootstrap",
            label: "Waiting for bootstrap fallback",
            progress: 98,
            status: match ? "success" : "warning",
            itemHash: args.itemHash,
            detail: match ? `Bootstrap fallback ${attempt}/${attempts}: visible on Aleph.` : `Bootstrap fallback ${attempt}/${attempts}: waiting for the browser-published registration on Aleph.`
          });
        }
      });
      this.trace("deploy:bootstrap-registration-fallback-visible", {
        itemHash: args.itemHash,
        registrationId,
        peerId,
        fallbackVisibleRegistration
      });
      if (!fallbackVisibleRegistration) {
        throw new Error(
          "Relay bootstrap registration did not become visible on Aleph."
        );
      }
    }
    if (profile === "uc-go-peer" && args.deploymentToken) {
      let cleanupAggregateItemHash = null;
      await deleteVmBootstrapConfig({
        sender: this.state.wallet.address,
        deploymentToken: args.deploymentToken,
        signer: personalSign,
        hasher: sha256Hex,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        sync: true
      }).then((cleanupResult) => {
        cleanupAggregateItemHash = cleanupResult.aggregateItemHash;
        this.trace("deploy:bootstrap-config-cleanup-complete", {
          itemHash: args.itemHash,
          deploymentToken: args.deploymentToken,
          aggregateItemHash: cleanupResult.aggregateItemHash,
          aggregateStatus: cleanupResult.aggregateStatus
        });
      }).catch((error) => {
        this.trace("deploy:bootstrap-config-cleanup-error", {
          itemHash: args.itemHash,
          deploymentToken: args.deploymentToken,
          error: error instanceof Error ? error.message : String(error)
        });
      });
      await this.cleanupStaleVmBootstrapConfigHistory({
        itemHash: args.itemHash,
        currentAggregateItemHash: cleanupAggregateItemHash,
        stage: "publishing-bootstrap",
        progress: 99
      });
    }
  }
  async cleanupStaleVmBootstrapConfigHistory(args) {
    if (!this.state.wallet.address || !args.currentAggregateItemHash) {
      return;
    }
    const staleHashes = await listStaleVmBootstrapConfigAggregateMessageHashes({
      address: this.state.wallet.address,
      currentAggregateItemHash: args.currentAggregateItemHash,
      olderThanMs: VM_BOOTSTRAP_CONFIG_HISTORY_RETENTION_MS,
      fetch: asJsonFetch,
      apiHost: this.client.apiHost
    }).catch((error) => {
      this.trace("deploy:bootstrap-config-history-scan-error", {
        itemHash: args.itemHash,
        currentAggregateItemHash: args.currentAggregateItemHash,
        error: error instanceof Error ? error.message : String(error)
      });
      return [];
    });
    if (staleHashes.length === 0) {
      return;
    }
    const staleCount = staleHashes.length;
    this.emitProgress({
      stage: args.stage,
      label: "Cleaning up stale handoff history",
      progress: args.progress,
      status: "warning",
      itemHash: args.itemHash,
      detail: `Forgetting ${staleCount} superseded Aleph handoff aggregate message${staleCount === 1 ? "" : "s"} older than 6 hours. MetaMask may request another cleanup signature.`
    });
    this.trace("deploy:bootstrap-config-history-cleanup-start", {
      itemHash: args.itemHash,
      currentAggregateItemHash: args.currentAggregateItemHash,
      staleHashes
    });
    await forgetAlephMessages({
      sender: this.state.wallet.address,
      hashes: staleHashes,
      reason: "Prune stale vm-bootstrap-config aggregate history older than 6 hours",
      signer: personalSign,
      hasher: sha256Hex,
      fetch: asJsonFetch,
      apiHost: this.client.apiHost,
      sync: true
    }).then((cleanupResult) => {
      this.trace("deploy:bootstrap-config-history-cleanup-complete", {
        itemHash: args.itemHash,
        currentAggregateItemHash: args.currentAggregateItemHash,
        staleHashes,
        forgetItemHash: cleanupResult.itemHash,
        forgetStatus: cleanupResult.status
      });
    }).catch((error) => {
      this.trace("deploy:bootstrap-config-history-cleanup-error", {
        itemHash: args.itemHash,
        currentAggregateItemHash: args.currentAggregateItemHash,
        staleHashes,
        error: error instanceof Error ? error.message : String(error)
      });
    });
  }
  syncLatestDeploymentProgress(instances) {
    const itemHash = this.state.lastDeploymentHash;
    if (!itemHash) {
      return;
    }
    const latest = instances.find(
      (entry) => entry.instance.item_hash === itemHash
    );
    if (!latest) {
      return;
    }
    const currentProgress = this.state.deploymentProgress;
    const currentProgressIsForLatestHash = currentProgress.itemHash === itemHash || currentProgress.itemHash == null && currentProgress.stage !== "idle" && currentProgress.stage !== "error";
    const keepTerminalSuccess = this.lastCompletedDeploymentHash === itemHash || currentProgressIsForLatestHash && currentProgress.stage === "completed" && currentProgress.status === "success";
    if (currentProgressIsForLatestHash && currentProgress.stage === "publishing-bootstrap") {
      this.trace("progress:retain-active-phase", {
        reason: "latest refresh would overwrite active relay metadata/bootstrap progress",
        itemHash,
        label: currentProgress.label,
        progress: currentProgress.progress
      });
      return;
    }
    const status = latest.details.messageStatus;
    if (status === "rejected") {
      this.emitProgress({
        stage: "deployment-rejected",
        label: "Deployment rejected",
        progress: 100,
        status: "error",
        itemHash,
        detail: "Aleph rejected the deployment.",
        error: "Aleph rejected the deployment."
      });
      return;
    }
    if (status !== "processed") {
      if (keepTerminalSuccess) {
        this.trace("progress:retain-completed", {
          reason: "latest refresh still reports non-processed status",
          itemHash,
          status
        });
        return;
      }
      const submittedAtMs = instanceTimestampMs(latest.instance);
      const pendingTooLong = submittedAtMs != null && Date.now() - submittedAtMs >= DEPLOYMENT_PENDING_WARNING_MS;
      this.emitProgress({
        stage: "waiting-for-aleph",
        label: pendingTooLong ? "Aleph processing delayed" : "Waiting for Aleph",
        progress: 76,
        status: pendingTooLong ? "warning" : "info",
        itemHash,
        detail: pendingTooLong ? "The instance is still pending on Aleph after several minutes. Retry, inspect the Aleph message, or delete and redeploy." : "Deployment submitted. Waiting for Aleph to process the instance message."
      });
      return;
    }
    if (!hasUsableRuntime(latest.details)) {
      if (keepTerminalSuccess) {
        this.trace("progress:retain-completed", {
          reason: "latest refresh lacks runtime details after completed state",
          itemHash
        });
        return;
      }
      this.emitProgress({
        stage: "deployment-confirmed",
        label: "Waiting for runtime",
        progress: 88,
        status: "warning",
        itemHash,
        detail: "Aleph processed the deployment. Waiting for scheduler/runtime allocation details."
      });
      return;
    }
    const hasConfirmedBootstrapRegistration = this.state.bootstrapRegistrations.some(
      (entry) => entry.instanceItemHash === itemHash && entry.confirmed
    );
    if (hasConfirmedBootstrapRegistration) {
      this.emitProgress({
        stage: "completed",
        label: "Relay ready",
        progress: 100,
        status: "success",
        itemHash,
        detail: "Runtime networking is available and the relay bootstrap registration is confirmed on Aleph."
      });
      return;
    }
    this.emitProgress({
      stage: "deployment-confirmed",
      label: "Runtime ready",
      progress: 92,
      status: "info",
      itemHash,
      detail: "Deployment processed and runtime networking is available. Finishing relay setup and bootstrap verification."
    });
  }
  canSkipRuntimeRefresh(instance) {
    if (instance.item_hash === this.state.lastDeploymentHash) {
      return false;
    }
    const cooldownUntil = this.runtimeCooldownByHash.get(instance.item_hash);
    if (!cooldownUntil) {
      return false;
    }
    return cooldownUntil > Date.now();
  }
  noteRuntimeRefreshResult(instance, details) {
    const hasRuntimeData = Boolean(details.crnUrl) || Boolean(details.hostIpv4) || Boolean(details.vmIpv4) || details.mappedPorts.length > 0 || Boolean(details.webUrl) || Boolean(details.execution);
    if (hasRuntimeData || details.error || details.messageStatus !== "processed") {
      this.runtimeCooldownByHash.delete(instance.item_hash);
      return;
    }
    const timestampMs = instanceTimestampMs(instance);
    const isRecent = timestampMs != null && Date.now() - timestampMs < RECENT_INSTANCE_RUNTIME_GRACE_MS;
    if (isRecent) {
      this.runtimeCooldownByHash.delete(instance.item_hash);
      return;
    }
    this.runtimeCooldownByHash.set(
      instance.item_hash,
      Date.now() + STALE_INSTANCE_ALLOCATION_COOLDOWN_MS
    );
  }
  rememberRuntimeDetails(itemHash, details) {
    if (!hasUsableRuntime(details)) {
      return;
    }
    this.runtimeDetailsByHash.set(itemHash, {
      ...details,
      mappedPorts: [...details.mappedPorts]
    });
  }
  mergeRememberedRuntimeDetails(itemHash, details) {
    const remembered = this.runtimeDetailsByHash.get(itemHash);
    if (!remembered) {
      return details;
    }
    if (details.messageStatus === "processed" && hasUsableRuntime(details)) {
      return details;
    }
    this.trace("runtime:retain-known-details", {
      itemHash,
      currentStatus: details.messageStatus,
      rememberedStatus: remembered.messageStatus,
      currentHasRuntime: hasUsableRuntime(details)
    });
    return {
      ...details,
      ...remembered,
      error: details.error ?? remembered.error
    };
  }
  async init() {
    this.trace("init:start", {
      launcherMode: this.props.launcherMode ?? "floating",
      manifestUrl: this.state.manifestUrl
    });
    this.stopWalletWatch = watchWallet(() => {
      this.trace("wallet:changed");
      void this.refreshWalletDerivedState();
    });
    await this.refresh();
    this.refreshTimer = setInterval(() => {
      void this.refresh();
    }, REFRESH_INTERVAL_MS);
    this.patch({ ready: true });
    this.trace("init:ready");
  }
  destroy() {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    if (this.manifestRefreshTimer) clearTimeout(this.manifestRefreshTimer);
    this.stopWalletWatch?.();
  }
  setOpen(open) {
    this.patch({ open });
  }
  toggleOpen() {
    this.patch({ open: !this.state.open });
  }
  setManifestUrl(manifestUrl) {
    this.patch({ manifestUrl });
    this.queueManifestRefresh();
  }
  setManifestJson(manifestJson) {
    this.patch({
      manifestJson,
      showAdvanced: this.state.showAdvanced || Boolean(manifestJson.trim()),
      showPasteManifest: this.state.showPasteManifest || Boolean(manifestJson.trim())
    });
    this.queueManifestRefresh();
  }
  setShowAdvanced(showAdvanced) {
    this.patch({ showAdvanced });
  }
  setShowPasteManifest(showPasteManifest) {
    this.patch({ showPasteManifest });
  }
  setSshPublicKey(sshPublicKey) {
    this.patch({
      sshPublicKey,
      showAdvanced: this.state.showAdvanced || Boolean(sshPublicKey.trim())
    });
  }
  setInstanceName(instanceName) {
    this.patch({ instanceName });
  }
  setTierId(tierId) {
    this.patch({ tierId });
    this.recomputePricingSummary();
  }
  recomputePricingSummary() {
    const pricing = this.state.pricingSummary.pricing;
    const tier = pricing?.tiers.find((entry) => entry.id === this.state.tierId) ?? pricing?.tiers[0] ?? null;
    const balance = this.state.balance;
    const quote = pricing && tier && balance ? buildPaymentQuote(tier, pricing, balance) : null;
    const spec = pricing && tier ? tierSpec(pricing, tier) : null;
    const selectedCrn = compatibleCrnsForTier(this.state.crns, {
      ...this.state,
      pricingSummary: {
        ...this.state.pricingSummary,
        pricing,
        tier
      }
    })[0] ?? null;
    this.patch({
      pricingSummary: {
        pricing,
        tier,
        requiredCredits: quote?.required ?? null,
        availableCredits: quote?.available ?? balance?.credit_balance ?? null,
        vcpus: spec?.vcpus ?? null,
        memoryMiB: spec?.memoryMiB ?? null,
        diskMiB: spec?.diskMiB ?? null
      },
      selectedCrn
    });
  }
  queueManifestRefresh() {
    if (!this.state.ready) {
      return;
    }
    if (this.manifestRefreshTimer) {
      clearTimeout(this.manifestRefreshTimer);
    }
    this.manifestRefreshTimer = setTimeout(() => {
      this.manifestRefreshTimer = null;
      void this.refresh();
    }, MANIFEST_SOURCE_REFRESH_DEBOUNCE_MS);
  }
  async connectWallet() {
    this.patch({
      busy: { connectingWallet: true },
      errorText: null,
      statusText: "Connecting MetaMask"
    });
    try {
      const wallet = await connectWallet();
      this.patch({
        wallet,
        busy: { connectingWallet: false },
        statusText: "Wallet connected"
      });
      await this.refresh();
    } catch (error) {
      this.patch({
        busy: { connectingWallet: false },
        errorText: error instanceof Error ? error.message : String(error),
        statusText: "Wallet connection failed"
      });
    }
  }
  async refreshWalletDerivedState() {
    if (!this.state.wallet.connected) {
      return;
    }
    try {
      const wallet = await connectWallet();
      this.patch({ wallet });
      await this.refresh();
    } catch {
      this.patch({
        wallet: {
          connected: false,
          address: null,
          chainId: null,
          isMetaMask: false
        }
      });
    }
  }
  async refresh() {
    this.trace("refresh:start", {
      wallet: this.state.wallet.address,
      manifestUrl: this.state.manifestUrl,
      showInstances: this.state.showInstances
    });
    this.patch({
      busy: { refreshing: true },
      errorText: null,
      statusText: "Refreshing relay sponsor data"
    });
    try {
      const [pricingSummary, crns] = await Promise.all([
        fetchInstancePricing(this.client.apiHost),
        this.client.fetchCrns()
      ]);
      const manifestState = await resolveManifest({
        manifestUrl: this.state.manifestUrl,
        manifestJson: this.state.manifestJson
      }).catch((error) => manifestLoadErrorState(error));
      const manifest = manifestState.manifest;
      let balance = this.state.balance;
      let instances = [];
      let bootstrapRegistrations = [];
      let orphanBootstrapRegistrations = [];
      if (this.state.wallet.address) {
        const [nextBalance, rawInstances, rawBootstrapPosts] = await Promise.all([
          this.client.fetchBalance(this.state.wallet.address),
          this.state.showInstances ? this.client.fetchInstances(this.state.wallet.address) : Promise.resolve([]),
          fetchAlephBootstrapPosts({
            apiHost: this.client.apiHost,
            fetch
          }).catch(() => [])
        ]);
        balance = nextBalance;
        instances = await Promise.all(
          rawInstances.map(async (instance) => {
            const inspected = this.canSkipRuntimeRefresh(instance) ? {
              details: {
                messageStatus: String(
                  instance.status ?? (instance.confirmed ? "processed" : "pending")
                ).toLowerCase(),
                allocationSource: null,
                crnUrl: null,
                hostIpv4: null,
                ipv6: null,
                vmIpv4: null,
                webUrl: null,
                sshCommand: null,
                mappedPorts: [],
                execution: null,
                error: null
              },
              lookup: {
                allocationFound: false,
                allocationSource: null,
                crnUrl: null,
                webUrl: null,
                executionPayloadFound: false,
                executionLookupBlocked: false,
                executionLookupRequestUrl: null,
                executionLookupVersion: null
              }
            } : await inspectInstanceRuntime({
              client: this.client,
              instance,
              crns
            });
            const details = inspected.details;
            const mergedDetails = this.mergeRememberedRuntimeDetails(
              instance.item_hash,
              details
            );
            if (this.debugEnabled && instance.item_hash === this.state.lastDeploymentHash) {
              this.trace("runtime:inspect-result", {
                itemHash: instance.item_hash,
                messageStatus: details.messageStatus,
                hostIpv4: details.hostIpv4,
                vmIpv4: details.vmIpv4,
                mappedPorts: details.mappedPorts,
                error: details.error,
                lookup: inspected.lookup
              });
            }
            this.rememberRuntimeDetails(instance.item_hash, mergedDetails);
            this.noteRuntimeRefreshResult(instance, mergedDetails);
            return {
              instance,
              details: mergedDetails
            };
          })
        );
        const normalizedWalletAddress = this.state.wallet.address.toLowerCase();
        const activeInstanceHashes = new Set(
          instances.map((entry) => entry.instance.item_hash)
        );
        bootstrapRegistrations = selectCurrentRelayBootstrapPosts(rawBootstrapPosts).filter(
          (entry) => relayBootstrapMatchesCurrentWallet(
            entry,
            normalizedWalletAddress,
            activeInstanceHashes
          )
        ).map((entry) => {
          const instanceItemHash = relayBootstrapInstanceItemHash(entry);
          const messageHash = entry.itemHash ?? entry.hash ?? null;
          return {
            messageHash,
            hash: entry.hash ?? null,
            itemHash: entry.itemHash ?? null,
            address: entry.address ?? null,
            time: entry.time ?? null,
            instanceItemHash,
            confirmed: Boolean(
              instanceItemHash && activeInstanceHashes.has(instanceItemHash)
            ),
            content: entry.content ? {
              peerId: entry.content.peerId,
              registrationId: entry.content.registrationId,
              multiaddrs: Array.isArray(entry.content.multiaddrs) ? entry.content.multiaddrs : [],
              browserMultiaddrs: Array.isArray(entry.content.browserMultiaddrs) ? entry.content.browserMultiaddrs : [],
              ownerAddress: typeof entry.content.ownerAddress === "string" ? entry.content.ownerAddress : void 0,
              publisherAddress: typeof entry.content.publisherAddress === "string" ? entry.content.publisherAddress : void 0,
              updatedAt: entry.content.updatedAt
            } : null
          };
        });
        orphanBootstrapRegistrations = bootstrapRegistrations.filter(
          (entry) => !entry.confirmed
        );
      }
      let rootfsVerified = false;
      let rootfsResolution = null;
      if (manifestState.valid && manifest) {
        rootfsVerified = await verifyRootfsExists(
          manifest.rootfsItemHash,
          this.client.apiHost
        );
        rootfsResolution = await resolveRootfsReference(
          manifest.rootfsItemHash,
          this.client.apiHost
        );
      }
      this.patch({
        manifestState,
        manifest,
        rootfsVerified,
        rootfsResolution,
        rootfsHealth: rootfsHealth({
          manifestState,
          rootfsVerified,
          resolution: rootfsResolution
        }),
        pricingSummary: {
          ...this.state.pricingSummary,
          pricing: pricingSummary.pricing
        },
        balance,
        crns,
        instances,
        bootstrapRegistrations,
        orphanBootstrapRegistrations,
        busy: { refreshing: false },
        statusText: "Relay sponsor data ready"
      });
      this.trace("refresh:success", {
        manifestValid: manifestState.valid,
        rootfsVerified,
        instances: instances.length
      });
      this.recomputePricingSummary();
      this.syncLatestDeploymentProgress(instances);
    } catch (error) {
      this.trace("refresh:error", error);
      this.patch({
        busy: { refreshing: false },
        errorText: error instanceof Error ? error.message : String(error),
        statusText: "Refresh failed"
      });
    }
  }
  async deploy() {
    this.trace("deploy:start", {
      wallet: this.state.wallet.address,
      instanceName: this.state.instanceName,
      tierId: this.state.tierId,
      selectedCrn: this.state.selectedCrn?.name ?? null,
      manifestRootfsItemHash: this.state.manifest?.rootfsItemHash ?? null,
      requiredPortForwards: this.state.manifest?.requiredPortForwards ?? []
    });
    if (!this.state.wallet.address) {
      this.patch({ errorText: "Connect MetaMask before deploying." });
      return;
    }
    if (!this.state.manifest || this.state.rootfsHealth.tone !== "ok" || !this.state.pricingSummary.pricing || !this.state.pricingSummary.tier) {
      this.patch({
        errorText: this.state.rootfsHealth.tone === "error" ? `Cannot deploy: ${this.state.rootfsHealth.detail ?? this.state.rootfsHealth.label}` : "Manifest, rootfs, and pricing must be ready before deploying."
      });
      return;
    }
    this.patch({
      busy: { deploying: true },
      errorText: null,
      statusText: "Broadcasting deployment"
    });
    try {
      this.emitProgress({
        stage: "validating",
        label: "Validating deployment",
        progress: 5,
        status: "info",
        detail: "Checking wallet, manifest, rootfs, pricing, and SSH key."
      });
      const spec = tierSpec(
        this.state.pricingSummary.pricing,
        this.state.pricingSummary.tier
      );
      const compatibleCrns2 = compatibleCrnsForTier(this.state.crns, {
        ...this.state,
        pricingSummary: {
          ...this.state.pricingSummary,
          pricing: this.state.pricingSummary.pricing,
          tier: this.state.pricingSummary.tier
        }
      });
      const preferredCrnHash = this.state.selectedCrn?.hash ?? null;
      const orderedCrns = [
        ...compatibleCrns2.filter((crn) => crn.hash === preferredCrnHash),
        ...compatibleCrns2.filter((crn) => crn.hash !== preferredCrnHash)
      ].slice(0, 5);
      if (orderedCrns.length === 0) {
        throw new Error("No compatible CRN is currently available for this tier.");
      }
      const attemptErrors = [];
      let lastError = null;
      for (const [candidateIndex, candidateCrn] of orderedCrns.entries()) {
        let attemptItemHash = null;
        let attemptDeploymentToken = null;
        let attemptProfile = null;
        const crnAttemptLabel = `CRN ${candidateIndex + 1}/${orderedCrns.length}`;
        const crnDisplayName = candidateCrn.name ?? candidateCrn.hash;
        this.emitProgress({
          stage: "selecting-crn",
          label: `Selecting ${crnAttemptLabel}`,
          progress: 18,
          status: "info",
          detail: `Trying ${crnDisplayName}`
        });
        try {
          const profile = relayProfileForManifest(this.state.manifest);
          attemptProfile = profile;
          const sshPublicKey = profile === "uc-go-peer" ? appendDeploymentTokenToSshPublicKey(
            this.state.sshPublicKey.trim(),
            this.state.wallet.address,
            attemptDeploymentToken = createDeploymentToken()
          ) : this.state.sshPublicKey.trim();
          const content = createInstanceContent({
            address: this.state.wallet.address,
            name: this.state.instanceName.trim(),
            sshPublicKey,
            rootfsItemHash: this.state.manifest.rootfsItemHash,
            rootfsSizeMiB: Math.max(
              this.state.manifest.rootfsSizeMiB,
              spec.diskMiB
            ),
            vcpus: spec.vcpus,
            memoryMiB: spec.memoryMiB,
            rootfsVersion: this.state.manifest.version,
            crnHash: candidateCrn.hash
          });
          const result = await deployInstance({
            sender: this.state.wallet.address,
            content,
            hasher: sha256Hex,
            signer: personalSign,
            fetch: (url, init) => fetch(url, init),
            apiHost: this.client.apiHost,
            sync: false,
            onProgress: (event) => {
              this.emitProgress(event);
            }
          });
          attemptItemHash = result.itemHash;
          this.patch({
            statusText: `Deployment submitted: ${result.itemHash}`,
            lastDeploymentHash: result.itemHash
          });
          this.trace("deploy:broadcasted", {
            ...result,
            crnHash: candidateCrn.hash,
            crnName: candidateCrn.name
          });
          this.lastCompletedDeploymentHash = null;
          const inspection = await waitForDeploymentResult2(result.itemHash, {
            rootfsRef: this.state.manifest.rootfsItemHash,
            apiHost: this.client.apiHost,
            fetch: (url, init) => fetch(url, init),
            attempts: UI_DEPLOY_WAIT_ATTEMPTS,
            delayMs: UI_DEPLOY_WAIT_DELAY_MS,
            onAttempt: (inspectionResult, attempt, attempts) => {
              if (inspectionResult.status === "processed") {
                this.emitProgress({
                  stage: "deployment-confirmed",
                  label: "Deployment accepted by Aleph",
                  progress: 82,
                  status: "success",
                  itemHash: result.itemHash,
                  detail: `Aleph processing ${attempt}/${attempts}: instance message processed.`
                });
                return;
              }
              if (inspectionResult.status === "rejected") {
                this.emitProgress({
                  stage: "deployment-rejected",
                  label: "Deployment rejected",
                  progress: 100,
                  status: "error",
                  itemHash: result.itemHash,
                  detail: inspectionResult.rejectionReason ?? "Aleph rejected the deployment.",
                  error: inspectionResult.rejectionReason ?? "Aleph rejected the deployment."
                });
                return;
              }
              this.emitProgress({
                stage: "waiting-for-aleph",
                label: "Waiting for Aleph",
                progress: 76,
                status: "info",
                itemHash: result.itemHash,
                detail: `Aleph processing ${attempt}/${attempts}: waiting for the instance message to be processed.`
              });
            }
          });
          if (inspection.status !== "processed") {
            throw new Error(
              inspection.rejectionReason ?? `Deployment ${result.itemHash} stayed ${inspection.status} on Aleph.`
            );
          }
          this.trace("deploy:aleph-processed", inspection);
          if ((this.state.manifest.requiredPortForwards?.length ?? 0) > 0) {
            this.emitProgress({
              stage: "refreshing-instances",
              label: "Publishing port forwards",
              progress: 86,
              status: "info",
              itemHash: result.itemHash,
              detail: "Publishing the required Aleph port-forward aggregate from the manifest."
            });
            await ensureInstancePortForwards({
              sender: this.state.wallet.address,
              instanceItemHash: result.itemHash,
              manifest: toSharedRootfsManifest(this.state.manifest),
              signer: personalSign,
              hasher: sha256Hex,
              fetch: (url, init) => fetch(url, init),
              apiHost: this.client.apiHost,
              sync: true
            });
            this.trace("deploy:port-forwards-published", {
              itemHash: result.itemHash,
              requiredPortForwards: this.state.manifest.requiredPortForwards
            });
          }
          if (candidateCrn.address) {
            this.trace("deploy:notifying-crn", {
              itemHash: result.itemHash,
              crnName: candidateCrn.name,
              crnHash: candidateCrn.hash,
              crnUrl: candidateCrn.address
            });
            await notifyCrnAllocationWithRetry({
              crnUrl: candidateCrn.address,
              itemHash: result.itemHash,
              fetch: (url, init) => fetch(url, init),
              onProgress: (event) => {
                this.emitProgress(event);
              }
            });
          }
          this.emitProgress({
            stage: "deployment-confirmed",
            label: "Waiting for runtime",
            progress: 90,
            status: "warning",
            itemHash: result.itemHash,
            detail: "Aleph accepted the deployment. Waiting for runtime networking and mapped ports."
          });
          const runtime = await waitForVmRuntime({
            itemHash: result.itemHash,
            fetch: (url, init) => fetch(url, init),
            crnHash: candidateCrn.hash,
            crns: this.state.crns,
            crnListUrl: this.props.crnListUrl,
            requirePublicGuestIpv6ForProxy: true,
            attempts: UI_RUNTIME_WAIT_ATTEMPTS,
            delayMs: UI_RUNTIME_WAIT_DELAY_MS,
            onAttempt: (runtime2, attempt, attempts) => {
              if (runtime2.diagnostics?.state === "ready") {
                this.emitProgress({
                  stage: "deployment-confirmed",
                  label: "Runtime ready",
                  progress: 92,
                  status: "info",
                  itemHash: result.itemHash,
                  detail: `Runtime ${attempt}/${attempts}: networking and mapped ports are now available.`
                });
                return;
              }
              if (runtime2.diagnostics?.state === "execution-invalid-public-ipv6") {
                this.emitProgress({
                  stage: "deployment-confirmed",
                  label: "Rejecting unusable runtime",
                  progress: 91,
                  status: "warning",
                  itemHash: result.itemHash,
                  detail: runtime2.diagnostics?.reason ? `Runtime ${attempt}/${attempts}: ${runtime2.diagnostics.reason} Cleaning up this CRN attempt before retrying another relay host.` : `Runtime ${attempt}/${attempts}: the CRN exposed unusable guest networking. Cleaning up this CRN attempt before retrying another relay host.`
                });
                return;
              }
              this.emitProgress({
                stage: "deployment-confirmed",
                label: "Waiting for runtime",
                progress: 90,
                status: "warning",
                itemHash: result.itemHash,
                detail: runtime2.diagnostics?.reason ? `Runtime ${attempt}/${attempts}: ${runtime2.diagnostics.reason}` : `Runtime ${attempt}/${attempts}: waiting for CRN runtime networking and mapped ports.`
              });
            }
          });
          if (runtime.diagnostics?.state !== "ready") {
            throw new Error(
              runtime.diagnostics?.reason ?? "Deployment was processed, but runtime networking never exposed mapped ports."
            );
          }
          this.trace("deploy:runtime-ready", runtime);
          this.rememberRuntimeDetails(result.itemHash, {
            messageStatus: "processed",
            allocationSource: runtime.allocation?.source ?? null,
            crnUrl: runtime.allocation?.crnUrl ?? runtime.execution?.crnUrl ?? null,
            hostIpv4: runtime.hostIpv4 ?? null,
            ipv6: runtime.ipv6 ?? null,
            vmIpv4: runtime.execution?.networking?.ipv4_ip ?? null,
            webUrl: runtime.webAccessUrl ?? runtime.proxyUrl ?? runtime.execution?.networking?.proxy_url ?? null,
            sshCommand: runtime.sshCommand ?? null,
            mappedPorts: runtime.execution != null ? mappedPorts(runtime.execution) : runtimeMappedPorts(runtime.mappedPorts),
            execution: runtime.execution ?? null,
            error: null
          });
          await this.configureRelayBootstrapRegistration({
            itemHash: result.itemHash,
            runtime,
            deploymentToken: attemptDeploymentToken
          });
          this.patch({
            busy: { deploying: false }
          });
          this.emitProgress({
            stage: "refreshing-instances",
            label: "Refreshing instances",
            progress: 99,
            status: "info",
            itemHash: result.itemHash,
            detail: "Reloading deployments and runtime state."
          });
          await this.refresh();
          this.lastCompletedDeploymentHash = result.itemHash;
          this.emitProgress({
            stage: "completed",
            label: "Relay ready",
            progress: 100,
            status: "success",
            itemHash: result.itemHash,
            detail: "Relay runtime, setup, metadata, and bootstrap registration are confirmed."
          });
          return;
        } catch (error) {
          lastError = error instanceof Error ? error : new Error(String(error));
          const attemptLabel = crnDisplayName;
          const failedDueToInvalidIpv6 = /not globally routable|public guest IPv6/i.test(lastError.message);
          attemptErrors.push(`${attemptLabel}: ${lastError.message}`);
          this.trace("deploy:crn-attempt-error", {
            crnHash: candidateCrn.hash,
            crnName: candidateCrn.name,
            itemHash: attemptItemHash,
            error: lastError.message
          });
          if (attemptItemHash && attemptDeploymentToken && attemptProfile && !failedDueToInvalidIpv6) {
            try {
              const latestRuntime = await fetchVmRuntime({
                itemHash: attemptItemHash,
                fetch: (url, init) => fetch(url, init),
                crnHash: candidateCrn.hash,
                crns: this.state.crns,
                crnListUrl: this.props.crnListUrl,
                requirePublicGuestIpv6ForProxy: true
              });
              if (latestRuntime.diagnostics?.state === "ready") {
                const reconciledRelayMetadata = await fetchRelayMetadataForRuntime({
                  runtime: latestRuntime,
                  fetch: (url, init) => fetch(url, init),
                  preferSecureMetadata: attemptProfile === "uc-go-peer" && Boolean(latestRuntime.proxyUrl),
                  attempts: 3,
                  delayMs: 1e3,
                  timeoutMs: 15e3
                }).catch(() => null);
                if (reconciledRelayMetadata) {
                  const registrationId = createRelayBootstrapRegistrationId(
                    attemptProfile,
                    this.state.instanceName.trim(),
                    attemptItemHash
                  );
                  const visibleRegistration = await waitForRelayBootstrapRegistration({
                    registrationId,
                    peerId: reconciledRelayMetadata.peerId,
                    fetch: asJsonFetch,
                    apiHost: this.client.apiHost,
                    attempts: 3,
                    delayMs: 1e3
                  }).catch(() => null);
                  if (visibleRegistration) {
                    this.trace("deploy:recovered-after-error", {
                      itemHash: attemptItemHash,
                      registrationId,
                      peerId: reconciledRelayMetadata.peerId,
                      error: lastError.message
                    });
                    this.rememberRuntimeDetails(attemptItemHash, {
                      messageStatus: "processed",
                      allocationSource: latestRuntime.allocation?.source ?? null,
                      crnUrl: latestRuntime.allocation?.crnUrl ?? latestRuntime.execution?.crnUrl ?? null,
                      hostIpv4: latestRuntime.hostIpv4 ?? null,
                      ipv6: latestRuntime.ipv6 ?? null,
                      vmIpv4: latestRuntime.execution?.networking?.ipv4_ip ?? null,
                      webUrl: latestRuntime.webAccessUrl ?? latestRuntime.proxyUrl ?? latestRuntime.execution?.networking?.proxy_url ?? null,
                      sshCommand: latestRuntime.sshCommand ?? null,
                      mappedPorts: latestRuntime.execution != null ? mappedPorts(latestRuntime.execution) : runtimeMappedPorts(latestRuntime.mappedPorts),
                      execution: latestRuntime.execution ?? null,
                      error: null
                    });
                    this.patch({
                      busy: { deploying: false }
                    });
                    await this.refresh();
                    this.lastCompletedDeploymentHash = attemptItemHash;
                    this.emitProgress({
                      stage: "completed",
                      label: "Relay ready",
                      progress: 100,
                      status: "success",
                      itemHash: attemptItemHash,
                      detail: "The relay completed startup after a transient UI polling error. Runtime and bootstrap registration are confirmed."
                    });
                    return;
                  }
                }
              }
            } catch (reconcileError) {
              this.trace("deploy:recovery-check-error", {
                itemHash: attemptItemHash,
                error: reconcileError instanceof Error ? reconcileError.message : String(reconcileError)
              });
            }
            await this.refresh().catch(() => void 0);
            const recoveredRegistration = this.state.bootstrapRegistrations.some(
              (entry) => entry.instanceItemHash === attemptItemHash && entry.confirmed
            );
            if (recoveredRegistration) {
              this.trace("deploy:recovered-from-refresh-state", {
                itemHash: attemptItemHash,
                error: lastError.message
              });
              this.patch({
                busy: { deploying: false }
              });
              this.lastCompletedDeploymentHash = attemptItemHash;
              this.emitProgress({
                stage: "completed",
                label: "Relay ready",
                progress: 100,
                status: "success",
                itemHash: attemptItemHash,
                detail: "The relay completed startup after a transient browser-side polling error. Runtime and bootstrap registration are confirmed."
              });
              return;
            }
          }
          if (attemptItemHash) {
            this.emitProgress({
              stage: "deployment-confirmed",
              label: failedDueToInvalidIpv6 ? "Rejecting unusable runtime" : "Cleaning up failed attempt",
              progress: failedDueToInvalidIpv6 ? 91 : 16,
              status: "warning",
              itemHash: attemptItemHash,
              detail: failedDueToInvalidIpv6 ? `${attemptLabel} exposed runtime networking that cannot support proxy-backed HTTPS. Cleaning up this attempt before retrying another CRN.` : `${attemptLabel} failed: ${lastError.message} Cleaning up this attempt before retrying another CRN.`
            });
            if (attemptDeploymentToken) {
              let cleanupAggregateItemHash = null;
              this.emitProgress({
                stage: "deployment-confirmed",
                label: "Cleaning up failed attempt",
                progress: 17,
                status: "warning",
                itemHash: attemptItemHash,
                detail: "Removing bootstrap configuration for the failed attempt. MetaMask may request a cleanup signature."
              });
              this.trace("deploy:bootstrap-config-cleanup-start", {
                itemHash: attemptItemHash,
                deploymentToken: attemptDeploymentToken
              });
              await deleteVmBootstrapConfig({
                sender: this.state.wallet.address,
                deploymentToken: attemptDeploymentToken,
                signer: personalSign,
                hasher: sha256Hex,
                fetch: asJsonFetch,
                apiHost: this.client.apiHost,
                sync: true
              }).then((cleanupResult) => {
                cleanupAggregateItemHash = cleanupResult.aggregateItemHash;
                this.trace("deploy:bootstrap-config-cleanup-complete", {
                  itemHash: attemptItemHash,
                  deploymentToken: attemptDeploymentToken,
                  aggregateItemHash: cleanupResult.aggregateItemHash,
                  aggregateStatus: cleanupResult.aggregateStatus
                });
              }).catch((cleanupError) => {
                this.trace("deploy:bootstrap-config-cleanup-error", {
                  itemHash: attemptItemHash,
                  deploymentToken: attemptDeploymentToken,
                  error: cleanupError instanceof Error ? cleanupError.message : String(cleanupError)
                });
              });
              await this.cleanupStaleVmBootstrapConfigHistory({
                itemHash: attemptItemHash,
                currentAggregateItemHash: cleanupAggregateItemHash,
                stage: "deployment-confirmed",
                progress: 18
              });
            }
            this.emitProgress({
              stage: "deployment-confirmed",
              label: "Cleaning up failed attempt",
              progress: 18,
              status: "warning",
              itemHash: attemptItemHash,
              detail: "Forgetting the failed deployment attempt on Aleph. MetaMask may request another cleanup signature."
            });
            this.trace("deploy:forget-failed-attempt-start", {
              itemHash: attemptItemHash,
              crnHash: candidateCrn.hash,
              crnName: candidateCrn.name
            });
            await forgetAlephMessages({
              sender: this.state.wallet.address,
              hashes: [attemptItemHash],
              reason: `Discard failed Sponsor Relay deployment attempt on ${attemptLabel}`,
              signer: personalSign,
              hasher: sha256Hex,
              fetch: (url, init) => fetch(url, init).then(async (response) => ({
                ok: response.ok,
                status: response.status,
                json: async () => await response.json()
              })),
              apiHost: this.client.apiHost
            }).catch((cleanupError) => {
              this.trace("deploy:cleanup-error", {
                itemHash: attemptItemHash,
                error: cleanupError instanceof Error ? cleanupError.message : String(cleanupError)
              });
            });
            this.trace("deploy:forget-failed-attempt-complete", {
              itemHash: attemptItemHash,
              crnHash: candidateCrn.hash,
              crnName: candidateCrn.name
            });
          }
          if (candidateIndex < orderedCrns.length - 1) {
            this.emitProgress({
              stage: "selecting-crn",
              label: "Retrying on next CRN",
              progress: 20,
              status: "warning",
              itemHash: attemptItemHash,
              detail: `${attemptLabel} was discarded: ${lastError.message}`,
              error: lastError.message
            });
            continue;
          }
        }
      }
      throw new Error(
        attemptErrors.length > 0 ? `All compatible CRNs failed. ${attemptErrors.join(" | ")}` : lastError?.message ?? "All compatible CRNs failed."
      );
    } catch (error) {
      this.trace("deploy:error", error);
      this.patch({
        busy: { deploying: false },
        errorText: error instanceof Error ? error.message : String(error),
        statusText: "Deployment failed"
      });
      this.emitProgress({
        stage: "error",
        label: "Deployment failed",
        progress: 100,
        status: "error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
  async deleteInstance(instanceHash) {
    this.trace("delete:start", { instanceHash });
    if (!this.state.wallet.address) {
      this.patch({ errorText: "Connect MetaMask before deleting instances." });
      return;
    }
    const linkedRegistrationHashes = Array.from(
      new Set(
        this.state.bootstrapRegistrations.filter((entry) => entry.instanceItemHash === instanceHash).map(
          (entry) => entry.messageHash?.trim() ?? entry.itemHash?.trim() ?? entry.hash?.trim() ?? null
        ).filter((value) => Boolean(value))
      )
    );
    const hashesToForget = Array.from(
      /* @__PURE__ */ new Set([instanceHash, ...linkedRegistrationHashes])
    );
    const linkedRegistrationCount = linkedRegistrationHashes.length;
    const knownInstance = this.state.instances.find(
      (entry) => entry.instance.item_hash === instanceHash
    );
    this.patch({
      busy: { deletingInstanceHash: instanceHash },
      errorText: null,
      statusText: `Deleting ${instanceHash}`
    });
    try {
      this.emitProgress({
        stage: "validating",
        label: "Resolving CRN for delete",
        progress: 6,
        status: "warning",
        itemHash: instanceHash,
        detail: linkedRegistrationCount > 0 ? `Preparing CRN erase and Aleph FORGET for the instance and ${linkedRegistrationCount} linked bootstrap registration${linkedRegistrationCount === 1 ? "" : "s"}.` : "Preparing CRN erase and Aleph FORGET."
      });
      const eraseResult = await eraseInstanceOnCrn({
        sender: this.state.wallet.address,
        signer: personalSign,
        instanceHash,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        crnUrl: knownInstance?.details.crnUrl,
        crnHash: knownInstance?.instance.content?.requirements?.node?.node_hash ?? null,
        crnListUrl: this.props.crnListUrl,
        schedulerAllocationUrl: this.client.schedulerApiHost ? `${this.client.schedulerApiHost.replace(/\/+$/u, "")}/api/v0/allocation` : void 0
      });
      this.emitProgress({
        stage: "broadcasting-delete",
        label: eraseResult.status === "erased" ? "Erased VM on CRN" : eraseResult.status === "missing" ? "VM already absent on CRN" : "CRN erase skipped",
        progress: 34,
        status: eraseResult.status === "skipped" ? "warning" : "info",
        itemHash: instanceHash,
        detail: eraseResult.status === "erased" ? `Erased runtime on ${eraseResult.crnUrl ?? "selected CRN"} before sending FORGET.` : eraseResult.status === "missing" ? `The CRN no longer reports this VM on ${eraseResult.crnUrl ?? "the selected node"}, so the delete flow can continue with FORGET.` : "Could not resolve a CRN endpoint for this instance, so the delete flow is falling back to FORGET-only cleanup."
      });
      await forgetAlephMessages({
        sender: this.state.wallet.address,
        hashes: hashesToForget,
        reason: linkedRegistrationCount > 0 ? `Deleted instance and ${linkedRegistrationCount} linked relay bootstrap registration${linkedRegistrationCount === 1 ? "" : "s"} from Sponsor Relay panel` : "Deleted from Sponsor Relay panel",
        signer: personalSign,
        hasher: sha256Hex,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        onProgress: (event) => {
          this.emitProgress(event);
        }
      });
      this.patch({
        busy: { deletingInstanceHash: null },
        statusText: `Deletion submitted for ${instanceHash}`
      });
      this.emitProgress({
        stage: "refreshing-instances",
        label: "Refreshing instances after delete",
        progress: 92,
        status: "info",
        itemHash: instanceHash,
        detail: linkedRegistrationCount > 0 ? "Reloading current deployments and relay bootstrap registrations." : "Reloading current deployments."
      });
      await this.refresh();
      this.trace("delete:submitted", {
        instanceHash,
        linkedRegistrationHashes
      });
      this.emitProgress({
        stage: "completed",
        label: "Delete completed",
        progress: 100,
        status: "success",
        itemHash: instanceHash,
        detail: linkedRegistrationCount > 0 ? `Delete request submitted, including ${linkedRegistrationCount} linked bootstrap registration${linkedRegistrationCount === 1 ? "" : "s"}, and state refreshed.` : "Delete request submitted and deployments refreshed.",
        error: null
      });
    } catch (error) {
      this.trace("delete:error", error);
      this.patch({
        busy: { deletingInstanceHash: null },
        errorText: error instanceof Error ? error.message : String(error),
        statusText: "Delete failed"
      });
    }
  }
  async deleteBootstrapRegistration(registrationHash) {
    this.trace("registration-delete:start", { registrationHash });
    if (!this.state.wallet.address) {
      this.patch({
        errorText: "Connect MetaMask before forgetting registrations."
      });
      return;
    }
    this.patch({
      busy: { deletingRegistrationHash: registrationHash },
      errorText: null,
      statusText: `Forgetting registration ${registrationHash}`
    });
    try {
      this.emitProgress({
        stage: "validating",
        label: "Validating registration cleanup",
        progress: 6,
        status: "warning",
        itemHash: registrationHash,
        detail: "Preparing Aleph FORGET message for the orphan bootstrap registration."
      });
      await forgetAlephMessages({
        sender: this.state.wallet.address,
        hashes: [registrationHash],
        reason: "Deleted orphan relay bootstrap registration from Sponsor Relay panel",
        signer: personalSign,
        hasher: sha256Hex,
        fetch: asJsonFetch,
        apiHost: this.client.apiHost,
        onProgress: (event) => {
          this.emitProgress(event);
        }
      });
      this.patch({
        busy: { deletingRegistrationHash: null },
        statusText: `Deletion submitted for ${registrationHash}`
      });
      this.emitProgress({
        stage: "refreshing-instances",
        label: "Refreshing registrations after delete",
        progress: 92,
        status: "info",
        itemHash: registrationHash,
        detail: "Reloading deployments and relay bootstrap registrations."
      });
      await this.refresh();
      this.trace("registration-delete:submitted", { registrationHash });
      this.emitProgress({
        stage: "completed",
        label: "Registration cleanup completed",
        progress: 100,
        status: "success",
        itemHash: registrationHash,
        detail: "Orphan relay bootstrap registration forgotten and state refreshed.",
        error: null
      });
    } catch (error) {
      this.trace("registration-delete:error", error);
      this.patch({
        busy: { deletingRegistrationHash: null },
        errorText: error instanceof Error ? error.message : String(error),
        statusText: "Registration cleanup failed"
      });
    }
  }
};
function createSponsorRelayController(props = {}) {
  return new SponsorRelayController(props);
}

// src/react/hooks/useSponsorRelayController.ts
import { useEffect, useMemo, useSyncExternalStore } from "react";
function useSponsorRelayController(props) {
  const controller = useMemo(
    () => createSponsorRelayController(props),
    [
      props.apiHost,
      props.crnListUrl,
      props.debug,
      props.instanceName,
      props.manifestJson,
      props.manifestUrl,
      props.openByDefault,
      props.schedulerApiHost,
      props.showInstances,
      props.sshPublicKey,
      props.twoN6ApiHost
    ]
  );
  useEffect(() => {
    controller.updateProps({
      debug: props.debug
    });
  }, [controller, props.debug]);
  useEffect(() => {
    void controller.init();
    return () => {
      controller.destroy();
    };
  }, [controller]);
  const state = useSyncExternalStore(
    (onStoreChange) => controller.subscribe(() => onStoreChange()),
    () => controller.getState(),
    () => controller.getState()
  );
  return { controller, state };
}

// src/react/SponsorRelayFab.tsx
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var basePanelStyle = {
  position: "fixed",
  zIndex: 9999,
  width: "min(28rem, calc(100vw - 2rem))",
  overflow: "auto",
  border: "1px solid var(--le-space-sponsor-relay-panel-border, rgba(199, 210, 254, 0.22))",
  borderRadius: "1.4rem",
  background: "var(--le-space-sponsor-relay-panel-bg, rgba(49, 46, 129, 0.94))",
  color: "#f8fafc",
  boxShadow: "var(--le-space-sponsor-relay-panel-shadow, 0 28px 80px rgba(49, 46, 129, 0.34))",
  padding: "1rem",
  fontFamily: '"DM Sans", "Inter", sans-serif'
};
var fieldStyle = {
  width: "100%",
  borderRadius: "0.8rem",
  border: "1px solid rgba(255,255,255,0.16)",
  background: "rgba(248,250,252,0.98)",
  color: "#111827",
  padding: "0.7rem 0.85rem",
  fontFamily: '"DM Sans", "Inter", sans-serif',
  fontSize: "0.98rem",
  lineHeight: 1.45
};
var secondaryButtonStyle = {
  borderRadius: "0.95rem",
  border: "1px solid rgba(255,255,255,0.22)",
  background: "rgba(255,255,255,0.10)",
  color: "#f8fafc",
  padding: "0.72rem 0.95rem",
  fontFamily: '"DM Sans", "Inter", sans-serif',
  fontSize: "0.92rem",
  fontWeight: 700,
  lineHeight: 1.1,
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.06)",
  backdropFilter: "blur(8px)"
};
var primaryButtonStyle = {
  borderRadius: "0.95rem",
  border: "1px solid rgba(251, 191, 36, 0.42)",
  background: "linear-gradient(135deg, #f6c453 0%, #f59e0b 100%)",
  color: "#281606",
  padding: "0.82rem 1rem",
  fontFamily: '"DM Sans", "Inter", sans-serif',
  fontSize: "0.96rem",
  fontWeight: 800,
  lineHeight: 1.1,
  boxShadow: "0 10px 24px rgba(245, 158, 11, 0.24)"
};
var dangerButtonStyle = {
  borderRadius: "0.95rem",
  border: "1px solid rgba(248, 113, 113, 0.45)",
  background: "rgba(239, 68, 68, 0.18)",
  color: "#ffe2e2",
  padding: "0.72rem 0.95rem",
  fontFamily: '"DM Sans", "Inter", sans-serif',
  fontSize: "0.9rem",
  fontWeight: 700,
  lineHeight: 1.1
};
var warningButtonStyle = {
  borderRadius: "0.95rem",
  border: "1px solid rgba(251, 146, 60, 0.4)",
  background: "rgba(251, 146, 60, 0.16)",
  color: "#fed7aa",
  padding: "0.72rem 0.95rem",
  fontFamily: '"DM Sans", "Inter", sans-serif',
  fontSize: "0.9rem",
  fontWeight: 700,
  lineHeight: 1.1
};
var themedLauncherBackground = "linear-gradient(135deg, var(--le-space-sponsor-relay-launcher-start, #4f46e5) 0%, var(--le-space-sponsor-relay-launcher-end, #6366f1) 100%)";
var themedLauncherBorder = "var(--le-space-sponsor-relay-launcher-border, rgba(199, 210, 254, 0.42))";
var themedLauncherBadgeBackground = "var(--le-space-sponsor-relay-launcher-badge-bg, rgba(49, 46, 129, 0.92))";
var themedLauncherBadgeBorder = "var(--le-space-sponsor-relay-launcher-badge-border, rgba(191, 219, 254, 0.24))";
var themedLauncherDot = "var(--le-space-sponsor-relay-launcher-dot, #f59e0b)";
function progressToneColor(status) {
  switch (status) {
    case "success":
      return "#37d67a";
    case "warning":
      return "#ffc83f";
    case "error":
      return "#e91315";
    default:
      return "#0176ce";
  }
}
function progressBadgeLabel(stage) {
  switch (stage) {
    case "building-delete-message":
    case "signing-delete-message":
    case "broadcasting-delete":
    case "delete-completed":
      return "DELETE";
    case "error":
      return "ERROR";
    case "completed":
      return "DONE";
    default:
      return "DEPLOY";
  }
}
var COMPLETED_PROGRESS_VISIBLE_MS = 12e3;
var POLLING_STAGES = /* @__PURE__ */ new Set([
  "waiting-for-aleph",
  "deployment-confirmed",
  "publishing-bootstrap",
  "refreshing-instances"
]);
function isDeploymentProgressVisible(state) {
  const stage = state.deploymentProgress.stage;
  if (stage === "idle") {
    return false;
  }
  if (stage === "error") {
    return true;
  }
  if (stage === "completed") {
    return Date.now() - state.deploymentProgress.timestamp < COMPLETED_PROGRESS_VISIBLE_MS;
  }
  return true;
}
function pollingIndicator(state) {
  if (state.busy.refreshing) {
    return {
      label: "Checking relay state",
      detail: state.statusText || "Refreshing relay sponsor data from Aleph and the selected CRN."
    };
  }
  if (!POLLING_STAGES.has(state.deploymentProgress.stage)) {
    return null;
  }
  return {
    label: state.deploymentProgress.label || "Polling relay state",
    detail: state.deploymentProgress.detail || state.statusText || "Waiting for the next confirmed relay state from Aleph."
  };
}
function launcherIndicator(state) {
  if (state.deploymentProgress.stage !== "idle" && state.deploymentProgress.stage !== "completed") {
    return {
      label: state.deploymentProgress.progress > 0 ? `${Math.round(state.deploymentProgress.progress)}%` : progressBadgeLabel(state.deploymentProgress.stage),
      detail: state.deploymentProgress.label,
      tone: state.deploymentProgress.status
    };
  }
  if (state.deploymentProgress.stage === "completed" && isDeploymentProgressVisible(state)) {
    return {
      label: "DONE",
      detail: state.deploymentProgress.label,
      tone: state.deploymentProgress.status === "error" ? "error" : "success"
    };
  }
  if (state.errorText) {
    return {
      label: "ERR",
      detail: state.errorText,
      tone: "error"
    };
  }
  if (!state.wallet.connected) {
    return {
      label: "WALLET",
      detail: "Connect MetaMask",
      tone: "warning"
    };
  }
  if (state.rootfsHealth.tone === "error") {
    return {
      label: "ROOTFS",
      detail: state.rootfsHealth.label,
      tone: "error"
    };
  }
  if (state.rootfsHealth.tone === "caution") {
    return {
      label: "CHECK",
      detail: state.rootfsHealth.label,
      tone: "warning"
    };
  }
  if (state.busy.refreshing) {
    return {
      label: "SYNC",
      detail: "Refreshing relay state",
      tone: "info"
    };
  }
  return {
    label: "READY",
    detail: state.selectedCrn?.name ?? "Ready to deploy",
    tone: "success"
  };
}
function SponsorRelayFab(props) {
  const { controller, state } = useSponsorRelayController(props);
  const explicitVersion = typeof props.version === "string" ? props.version.trim() : "";
  const resolvedVersion = explicitVersion || UI_PACKAGE_VERSION;
  const versionLabel = resolvedVersion.startsWith("v") ? resolvedVersion : `v${resolvedVersion}`;
  const launcherMode = props.launcherMode ?? "floating";
  const indicator = launcherIndicator(state);
  const confirmedRegistrationByInstanceHash = new Map(
    (state.bootstrapRegistrations ?? []).filter((entry) => entry.confirmed && entry.instanceItemHash).map((entry) => [entry.instanceItemHash, entry])
  );
  const orphanRegistrations = state.orphanBootstrapRegistrations ?? [];
  const [successFlash, setSuccessFlash] = React.useState(false);
  const [hovered, setHovered] = React.useState(false);
  const launcherRef = React.useRef(null);
  const [inlinePanelStyle, setInlinePanelStyle] = React.useState(null);
  const [compactInlineLabel, setCompactInlineLabel] = React.useState(false);
  React.useEffect(() => {
    if (state.deploymentProgress.stage !== "completed" || state.deploymentProgress.status !== "success") {
      return;
    }
    setSuccessFlash(true);
    const timeout = window.setTimeout(() => {
      setSuccessFlash(false);
    }, 1400);
    return () => {
      window.clearTimeout(timeout);
    };
  }, [
    state.deploymentProgress.stage,
    state.deploymentProgress.status,
    state.deploymentProgress.timestamp
  ]);
  React.useEffect(() => {
    if (state.deploymentProgress.stage !== "completed") {
      return;
    }
    const timeout = window.setTimeout(() => {
      setSuccessFlash(false);
    }, COMPLETED_PROGRESS_VISIBLE_MS);
    return () => {
      window.clearTimeout(timeout);
    };
  }, [state.deploymentProgress.stage, state.deploymentProgress.timestamp]);
  React.useEffect(() => {
    if (launcherMode !== "inline" || !state.open) {
      return;
    }
    const updateInlinePanelStyle = () => {
      const launcher = launcherRef.current;
      if (launcher == null) {
        return;
      }
      const rect = launcher.getBoundingClientRect();
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      const anchorRight = Math.max(16, viewportWidth - rect.right);
      const top = Math.max(72, rect.bottom + 12);
      setInlinePanelStyle({
        ...basePanelStyle,
        top,
        right: anchorRight,
        maxHeight: `calc(100vh - ${Math.min(viewportHeight - 16, top + 16)}px)`,
        width: "min(30rem, calc(100vw - 1.5rem))"
      });
    };
    updateInlinePanelStyle();
    window.addEventListener("resize", updateInlinePanelStyle);
    window.addEventListener("scroll", updateInlinePanelStyle, true);
    return () => {
      window.removeEventListener("resize", updateInlinePanelStyle);
      window.removeEventListener("scroll", updateInlinePanelStyle, true);
    };
  }, [launcherMode, state.open]);
  React.useEffect(() => {
    if (launcherMode !== "inline") {
      setCompactInlineLabel(false);
      return;
    }
    const updateCompactInlineLabel = () => {
      setCompactInlineLabel(window.innerWidth < 1240);
    };
    updateCompactInlineLabel();
    window.addEventListener("resize", updateCompactInlineLabel);
    return () => {
      window.removeEventListener("resize", updateCompactInlineLabel);
    };
  }, [launcherMode]);
  const progressActive = state.deploymentProgress.stage !== "idle" && state.deploymentProgress.stage !== "completed" && state.deploymentProgress.stage !== "error";
  const deploymentProgressVisible = isDeploymentProgressVisible(state);
  const pollingState = pollingIndicator(state);
  const pulseScale = progressActive ? 1.03 : hovered ? 1.015 : 1;
  const pulseShadow = progressActive ? `0 0 0 4px ${progressToneColor(indicator.tone)}22, 0 12px 28px rgba(15, 23, 42, 0.22)` : successFlash ? `0 0 0 5px rgba(55, 214, 122, 0.22), 0 14px 32px rgba(55, 214, 122, 0.22)` : launcherMode === "inline" ? hovered ? "var(--le-space-sponsor-relay-launcher-hover-shadow, 0 14px 30px rgba(79, 70, 229, 0.28))" : "var(--le-space-sponsor-relay-launcher-shadow, 0 10px 24px rgba(99, 102, 241, 0.22))" : void 0;
  const inlineButtonBackground = themedLauncherBackground;
  const inlineButtonBorder = `1px solid ${themedLauncherBorder}`;
  const inlineBadgeBackground = themedLauncherBadgeBackground;
  const inlineBadgeBorder = `1px solid ${themedLauncherBadgeBorder}`;
  const panelStyle = launcherMode === "inline" ? inlinePanelStyle ?? {
    ...basePanelStyle,
    top: "4.75rem",
    right: "1rem",
    maxHeight: "calc(100vh - 6rem)",
    width: "min(30rem, calc(100vw - 1.5rem))"
  } : {
    ...basePanelStyle,
    right: "1.4rem",
    bottom: "11.5rem",
    maxHeight: "calc(100vh - 12.5rem)"
  };
  const launcherLabel = launcherMode === "inline" && compactInlineLabel ? "Relay" : "Sponsor Relay";
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("style", { children: `@keyframes leSpaceRelayPulse { 0%, 100% { transform: scale(1); opacity: 0.74; } 50% { transform: scale(1.22); opacity: 1; } }` }),
    /* @__PURE__ */ jsxs(
      "button",
      {
        ref: launcherRef,
        type: "button",
        onClick: () => controller.toggleOpen(),
        onMouseEnter: () => setHovered(true),
        onMouseLeave: () => setHovered(false),
        onFocus: () => setHovered(true),
        onBlur: () => setHovered(false),
        title: indicator.detail ?? "Sponsor Relay",
        style: {
          position: launcherMode === "floating" ? "fixed" : "relative",
          right: launcherMode === "floating" ? "1.4rem" : void 0,
          bottom: launcherMode === "floating" ? "5.8rem" : void 0,
          zIndex: launcherMode === "floating" ? 1e4 : "auto",
          borderRadius: "999px",
          border: launcherMode === "floating" ? `2px solid ${themedLauncherBorder}` : inlineButtonBorder,
          background: launcherMode === "floating" ? themedLauncherBackground : inlineButtonBackground,
          color: "white",
          minHeight: launcherMode === "floating" ? void 0 : "2.25rem",
          padding: launcherMode === "floating" ? "0.9rem 1.2rem" : "0.42rem 0.56rem 0.42rem 0.76rem",
          fontFamily: '"Epilogue", sans-serif',
          fontWeight: 700,
          fontSize: launcherMode === "floating" ? "0.84rem" : "0.73rem",
          textTransform: "uppercase",
          letterSpacing: "0.08em",
          cursor: "pointer",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          gap: launcherMode === "floating" ? "0.45rem" : "0.34rem",
          boxShadow: pulseShadow,
          transform: `translateY(${hovered && !progressActive ? "-1px" : "0"}) scale(${pulseScale})`,
          transition: "transform 180ms ease, box-shadow 220ms ease, background 220ms ease, border-color 220ms ease"
        },
        children: [
          /* @__PURE__ */ jsxs(
            "span",
            {
              style: {
                display: "inline-flex",
                alignItems: "center",
                gap: "0.36rem"
              },
              children: [
                /* @__PURE__ */ jsx(
                  "span",
                  {
                    "aria-hidden": "true",
                    style: {
                      width: launcherMode === "floating" ? "0.5rem" : "0.42rem",
                      height: launcherMode === "floating" ? "0.5rem" : "0.42rem",
                      borderRadius: "999px",
                      background: launcherMode === "floating" ? "rgba(255,255,255,0.96)" : themedLauncherDot,
                      boxShadow: launcherMode === "floating" ? "0 0 0 3px rgba(255,255,255,0.22)" : "0 0 0 3px var(--le-space-sponsor-relay-launcher-dot-ring, rgba(245, 158, 11, 0.18))"
                    }
                  }
                ),
                /* @__PURE__ */ jsx("span", { children: launcherLabel })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "span",
            {
              style: {
                display: "inline-flex",
                alignItems: "center",
                gap: "0.36rem",
                padding: launcherMode === "floating" ? "0.2rem 0.42rem" : "0.21rem 0.5rem",
                minWidth: launcherMode === "floating" ? void 0 : "3.8rem",
                borderRadius: "999px",
                background: launcherMode === "floating" ? "rgba(15, 23, 42, 0.18)" : inlineBadgeBackground,
                border: launcherMode === "floating" ? "1px solid rgba(255,255,255,0.18)" : inlineBadgeBorder,
                fontSize: launcherMode === "floating" ? "0.62rem" : "0.61rem",
                fontWeight: launcherMode === "floating" ? 700 : 800,
                lineHeight: 1,
                letterSpacing: "0.08em",
                justifyContent: "center",
                boxShadow: launcherMode === "floating" ? void 0 : `inset 0 1px 0 rgba(255,255,255,0.08), 0 6px 16px ${progressToneColor(indicator.tone)}22`
              },
              children: [
                /* @__PURE__ */ jsx(
                  "span",
                  {
                    "aria-hidden": "true",
                    style: {
                      width: "0.42rem",
                      height: "0.42rem",
                      borderRadius: "999px",
                      background: progressToneColor(indicator.tone),
                      boxShadow: `0 0 0 ${progressActive ? "4px" : "3px"} ${progressToneColor(indicator.tone)}22`,
                      transform: `scale(${progressActive ? 1.12 : successFlash ? 1.18 : 1})`,
                      transition: "transform 180ms ease, box-shadow 220ms ease",
                      animation: pollingState ? "leSpaceRelayPulse 1.6s ease-in-out infinite" : void 0
                    }
                  }
                ),
                /* @__PURE__ */ jsx("span", { children: indicator.label })
              ]
            }
          )
        ]
      }
    ),
    state.open ? /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          onClick: () => controller.setOpen(false),
          style: {
            position: "fixed",
            inset: 0,
            zIndex: 9998,
            background: "radial-gradient(circle at 88% 82%, var(--le-space-sponsor-relay-backdrop-accent, rgba(79, 70, 229, 0.2)), transparent 34%)"
          }
        }
      ),
      /* @__PURE__ */ jsxs("aside", { style: panelStyle, children: [
        /* @__PURE__ */ jsxs(
          "div",
          {
            style: {
              display: "flex",
              justifyContent: "space-between",
              gap: "0.75rem",
              alignItems: "center"
            },
            children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsxs(
                  "div",
                  {
                    style: {
                      display: "flex",
                      alignItems: "center",
                      gap: "0.45rem",
                      color: "#9fb2ca",
                      fontSize: "0.72rem",
                      textTransform: "uppercase",
                      letterSpacing: "0.08em"
                    },
                    children: [
                      /* @__PURE__ */ jsx("span", { children: "Aleph VM credit deployer" }),
                      /* @__PURE__ */ jsx(
                        "span",
                        {
                          style: {
                            fontSize: "0.62rem",
                            letterSpacing: "0.04em",
                            textTransform: "none",
                            color: "rgba(191, 219, 254, 0.82)"
                          },
                          children: versionLabel
                        }
                      )
                    ]
                  }
                ),
                /* @__PURE__ */ jsx(
                  "h2",
                  {
                    style: {
                      margin: "0.2rem 0 0",
                      fontFamily: '"Epilogue", sans-serif'
                    },
                    children: "Sponsor Relay"
                  }
                )
              ] }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  style: secondaryButtonStyle,
                  onClick: () => void controller.refresh(),
                  children: state.busy.refreshing ? "Syncing" : "Refresh"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsx("p", { style: { color: "#9fb2ca" }, children: state.statusText }),
        state.errorText ? /* @__PURE__ */ jsx("p", { style: { color: "#ffd9d9" }, children: state.errorText }) : null,
        pollingState ? /* @__PURE__ */ jsxs(
          "div",
          {
            "aria-live": "polite",
            style: {
              marginTop: "0.25rem",
              marginBottom: "0.8rem",
              padding: "0.7rem 0.8rem",
              borderRadius: "1rem",
              border: "1px solid rgba(125, 211, 252, 0.18)",
              background: "linear-gradient(180deg, rgba(59, 130, 246, 0.12), rgba(59, 130, 246, 0.05))",
              display: "grid",
              gap: "0.28rem"
            },
            children: [
              /* @__PURE__ */ jsxs(
                "div",
                {
                  style: {
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "0.45rem"
                  },
                  children: [
                    /* @__PURE__ */ jsx(
                      "span",
                      {
                        "aria-hidden": "true",
                        style: {
                          width: "0.62rem",
                          height: "0.62rem",
                          borderRadius: "999px",
                          background: progressToneColor("info"),
                          boxShadow: `0 0 0 3px ${progressToneColor("info")}22`,
                          animation: "leSpaceRelayPulse 1.6s ease-in-out infinite"
                        }
                      }
                    ),
                    /* @__PURE__ */ jsx("strong", { style: { fontSize: "0.88rem" }, children: pollingState.label })
                  ]
                }
              ),
              /* @__PURE__ */ jsx("small", { style: { color: "#9fb2ca", lineHeight: 1.35 }, children: pollingState.detail })
            ]
          }
        ) : null,
        deploymentProgressVisible ? /* @__PURE__ */ jsxs(
          "div",
          {
            style: {
              marginTop: "0.85rem",
              padding: "0.75rem 0.8rem",
              borderRadius: "1rem",
              border: "1px solid rgba(255,255,255,0.1)",
              background: "linear-gradient(180deg, rgba(255,255,255,0.05), rgba(255,255,255,0.03))",
              boxShadow: "inset 0 1px 0 rgba(255,255,255,0.04)"
            },
            children: [
              /* @__PURE__ */ jsxs(
                "div",
                {
                  style: {
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "0.75rem",
                    alignItems: "center"
                  },
                  children: [
                    /* @__PURE__ */ jsxs(
                      "div",
                      {
                        style: {
                          display: "flex",
                          gap: "0.5rem",
                          alignItems: "center",
                          minWidth: 0
                        },
                        children: [
                          /* @__PURE__ */ jsx(
                            "span",
                            {
                              style: {
                                display: "inline-flex",
                                alignItems: "center",
                                justifyContent: "center",
                                minWidth: "3.9rem",
                                padding: "0.22rem 0.45rem",
                                borderRadius: "999px",
                                background: `${progressToneColor(state.deploymentProgress.status)}22`,
                                color: progressToneColor(
                                  state.deploymentProgress.status
                                ),
                                fontSize: "0.64rem",
                                fontWeight: 800,
                                letterSpacing: "0.08em",
                                textTransform: "uppercase"
                              },
                              children: progressBadgeLabel(state.deploymentProgress.stage)
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            "strong",
                            {
                              style: {
                                fontSize: "0.84rem",
                                lineHeight: 1.2,
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                textOverflow: "ellipsis"
                              },
                              children: state.deploymentProgress.label
                            }
                          )
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      "span",
                      {
                        style: {
                          fontSize: "0.72rem",
                          color: "#9fb2ca",
                          fontFamily: '"DM Mono", monospace'
                        },
                        children: [
                          String(
                            Math.round(state.deploymentProgress.progress)
                          ).padStart(3, " "),
                          "%"
                        ]
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ jsx(
                "div",
                {
                  style: {
                    marginTop: "0.5rem",
                    width: "100%",
                    height: "0.34rem",
                    borderRadius: "999px",
                    background: "rgba(255,255,255,0.08)",
                    overflow: "hidden"
                  },
                  children: /* @__PURE__ */ jsx(
                    "div",
                    {
                      style: {
                        width: `${Math.max(0, Math.min(100, state.deploymentProgress.progress))}%`,
                        height: "100%",
                        borderRadius: "999px",
                        background: progressToneColor(
                          state.deploymentProgress.status
                        ),
                        transition: "width 180ms ease"
                      }
                    }
                  )
                }
              ),
              /* @__PURE__ */ jsxs(
                "div",
                {
                  style: {
                    marginTop: "0.45rem",
                    display: "grid",
                    gap: "0.28rem"
                  },
                  children: [
                    state.deploymentProgress.itemHash ? /* @__PURE__ */ jsxs(
                      "div",
                      {
                        style: {
                          color: "#9fb2ca",
                          fontSize: "0.7rem",
                          fontFamily: '"DM Mono", monospace',
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis"
                        },
                        children: [
                          "hash ",
                          shortHash(state.deploymentProgress.itemHash, 10, 8)
                        ]
                      }
                    ) : null,
                    state.deploymentProgress.detail ? /* @__PURE__ */ jsx(
                      "div",
                      {
                        style: {
                          color: "#9fb2ca",
                          fontSize: "0.72rem",
                          lineHeight: 1.3,
                          fontFamily: state.deploymentProgress.detail.includes("0x") || state.deploymentProgress.detail.includes("Qm") ? '"DM Mono", monospace' : void 0
                        },
                        children: state.deploymentProgress.detail
                      }
                    ) : null,
                    state.deploymentProgress.error ? /* @__PURE__ */ jsx(
                      "div",
                      {
                        style: {
                          color: "#ffd9d9",
                          fontSize: "0.72rem",
                          lineHeight: 1.3
                        },
                        children: state.deploymentProgress.error
                      }
                    ) : null
                  ]
                }
              )
            ]
          }
        ) : null,
        /* @__PURE__ */ jsxs(
          "div",
          {
            style: { display: "grid", gap: "0.75rem", marginTop: "0.9rem" },
            children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  style: fieldStyle,
                  value: state.instanceName,
                  onChange: (event) => controller.setInstanceName(event.currentTarget.value),
                  placeholder: "Instance name"
                }
              ),
              /* @__PURE__ */ jsx(
                "select",
                {
                  style: fieldStyle,
                  value: state.pricingSummary.tier?.id ?? state.tierId,
                  onChange: (event) => controller.setTierId(event.currentTarget.value),
                  children: (state.pricingSummary.pricing?.tiers?.length ? state.pricingSummary.pricing.tiers : [{ id: state.tierId, compute_units: 1 }]).map((tier) => {
                    const unit = state.pricingSummary.pricing?.compute_unit;
                    const vcpus = unit ? unit.vcpus * tier.compute_units : null;
                    const memoryMiB = unit ? unit.memory_mib * tier.compute_units : null;
                    const diskMiB = unit ? unit.disk_mib * tier.compute_units : null;
                    return /* @__PURE__ */ jsx("option", { value: tier.id, children: `${tier.id} ${formatTierSpecLabel(vcpus, memoryMiB, diskMiB)}` }, tier.id);
                  })
                }
              ),
              /* @__PURE__ */ jsx(
                "div",
                {
                  style: {
                    color: "#9fb2ca",
                    fontSize: "0.74rem",
                    lineHeight: 1.35,
                    marginTop: "-0.15rem"
                  },
                  children: formatTierSpecLabel(
                    state.pricingSummary.vcpus,
                    state.pricingSummary.memoryMiB,
                    state.pricingSummary.diskMiB
                  )
                }
              ),
              /* @__PURE__ */ jsxs(
                "details",
                {
                  open: state.showAdvanced,
                  onToggle: (event) => controller.setShowAdvanced(
                    event.currentTarget.open
                  ),
                  children: [
                    /* @__PURE__ */ jsx("summary", { children: "Advanced" }),
                    /* @__PURE__ */ jsxs(
                      "div",
                      {
                        style: {
                          display: "grid",
                          gap: "0.75rem",
                          marginTop: "0.65rem"
                        },
                        children: [
                          /* @__PURE__ */ jsx(
                            "input",
                            {
                              style: fieldStyle,
                              value: state.manifestUrl,
                              onChange: (event) => controller.setManifestUrl(event.currentTarget.value),
                              placeholder: "Manifest URL"
                            }
                          ),
                          /* @__PURE__ */ jsx(
                            "textarea",
                            {
                              style: fieldStyle,
                              rows: 3,
                              value: state.sshPublicKey,
                              onChange: (event) => controller.setSshPublicKey(event.currentTarget.value),
                              placeholder: "SSH public key"
                            }
                          ),
                          /* @__PURE__ */ jsxs(
                            "details",
                            {
                              open: state.showPasteManifest,
                              onToggle: (event) => controller.setShowPasteManifest(
                                event.currentTarget.open
                              ),
                              children: [
                                /* @__PURE__ */ jsx("summary", { children: "Paste Manifest" }),
                                /* @__PURE__ */ jsx(
                                  "textarea",
                                  {
                                    style: { ...fieldStyle, marginTop: "0.65rem" },
                                    rows: 7,
                                    value: state.manifestJson,
                                    onChange: (event) => controller.setManifestJson(event.currentTarget.value)
                                  }
                                )
                              ]
                            }
                          )
                        ]
                      }
                    )
                  ]
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { style: { display: "grid", gap: "0.55rem", marginTop: "1rem" }, children: [
          /* @__PURE__ */ jsxs("div", { children: [
            formatNumber(state.pricingSummary.availableCredits, 0),
            " credits available"
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            formatNumber(state.pricingSummary.requiredCredits, 0),
            " credits required"
          ] }),
          /* @__PURE__ */ jsx("div", { children: state.rootfsHealth.label }),
          /* @__PURE__ */ jsx("div", { children: state.selectedCrn?.name ?? shortHash(state.selectedCrn?.hash) }),
          /* @__PURE__ */ jsxs("div", { children: [
            "Ports",
            " ",
            joinRequiredPortForwards(
              state.manifest?.requiredPortForwards ?? []
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: () => void (state.wallet.connected ? controller.deploy() : controller.connectWallet()),
            disabled: state.wallet.connected ? state.busy.deploying || state.rootfsHealth.tone !== "ok" : state.busy.connectingWallet,
            style: { ...primaryButtonStyle, width: "100%", marginTop: "1rem" },
            children: state.wallet.connected ? state.busy.deploying ? "Deploying\u2026" : "Deploy Relay" : "Connect MetaMask"
          }
        ),
        state.lastDeploymentHash ? /* @__PURE__ */ jsxs("p", { children: [
          "Latest deployment: ",
          shortHash(state.lastDeploymentHash)
        ] }) : null,
        state.showInstances ? /* @__PURE__ */ jsxs(
          "div",
          {
            style: { marginTop: "1rem", display: "grid", gap: "0.7rem" },
            children: [
              state.instances.map((entry) => {
                const confirmedRegistration = confirmedRegistrationByInstanceHash.get(
                  entry.instance.item_hash
                ) ?? null;
                return /* @__PURE__ */ jsxs("details", { open: true, children: [
                  /* @__PURE__ */ jsx("summary", { children: /* @__PURE__ */ jsxs(
                    "span",
                    {
                      style: {
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "0.55rem",
                        flexWrap: "wrap"
                      },
                      children: [
                        (entry.instance.content?.metadata?.name ?? "relay") + " \xB7 " + shortHash(entry.instance.item_hash),
                        confirmedRegistration ? /* @__PURE__ */ jsxs(
                          "span",
                          {
                            style: {
                              display: "inline-flex",
                              alignItems: "center",
                              gap: "0.32rem",
                              padding: "0.16rem 0.45rem",
                              borderRadius: "999px",
                              background: "rgba(34, 197, 94, 0.16)",
                              color: "#86efac",
                              fontSize: "0.7rem",
                              fontWeight: 700
                            },
                            children: [
                              /* @__PURE__ */ jsx(
                                "span",
                                {
                                  "aria-hidden": "true",
                                  style: {
                                    width: "0.45rem",
                                    height: "0.45rem",
                                    borderRadius: "999px",
                                    background: "#22c55e",
                                    boxShadow: "0 0 0 3px rgba(34, 197, 94, 0.18)"
                                  }
                                }
                              ),
                              "Aleph bootstrap registered"
                            ]
                          }
                        ) : null
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxs(
                    "div",
                    {
                      style: {
                        display: "grid",
                        gap: "0.35rem",
                        marginTop: "0.55rem"
                      },
                      children: [
                        /* @__PURE__ */ jsxs("div", { children: [
                          "Status: ",
                          entry.details.messageStatus
                        ] }),
                        confirmedRegistration ? /* @__PURE__ */ jsxs("div", { children: [
                          "Bootstrap registration:",
                          " ",
                          shortHash(
                            confirmedRegistration.messageHash ?? confirmedRegistration.content?.registrationId ?? "confirmed",
                            14,
                            8
                          )
                        ] }) : null,
                        /* @__PURE__ */ jsxs("div", { children: [
                          "Host IPv4: ",
                          entry.details.hostIpv4 ?? "-"
                        ] }),
                        /* @__PURE__ */ jsxs("div", { children: [
                          "IPv6: ",
                          entry.details.ipv6 ?? "-"
                        ] }),
                        /* @__PURE__ */ jsxs("div", { children: [
                          "VM IPv4: ",
                          entry.details.vmIpv4 ?? "-"
                        ] }),
                        /* @__PURE__ */ jsxs("div", { children: [
                          "SSH: ",
                          entry.details.sshCommand ?? "-"
                        ] }),
                        /* @__PURE__ */ jsxs("div", { children: [
                          "Ports: ",
                          joinMappedPorts(entry.details.mappedPorts)
                        ] }),
                        /* @__PURE__ */ jsxs("div", { children: [
                          "Submitted:",
                          " ",
                          formatDateTime(
                            entry.instance.reception_time ?? entry.instance.time
                          )
                        ] }),
                        /* @__PURE__ */ jsx(
                          "button",
                          {
                            type: "button",
                            style: dangerButtonStyle,
                            onClick: () => void controller.deleteInstance(
                              entry.instance.item_hash
                            ),
                            children: state.busy.deletingInstanceHash === entry.instance.item_hash ? "Deleting\u2026" : "Delete"
                          }
                        )
                      ]
                    }
                  )
                ] }, entry.instance.item_hash);
              }),
              orphanRegistrations.length > 0 ? /* @__PURE__ */ jsxs(
                "div",
                {
                  style: {
                    display: "grid",
                    gap: "0.7rem",
                    padding: "0.85rem",
                    borderRadius: "1rem",
                    border: "1px solid rgba(248, 113, 113, 0.22)",
                    background: "linear-gradient(180deg, rgba(127, 29, 29, 0.18), rgba(69, 10, 10, 0.12))"
                  },
                  children: [
                    /* @__PURE__ */ jsxs("div", { style: { display: "grid", gap: "0.2rem" }, children: [
                      /* @__PURE__ */ jsx("strong", { children: "Orphan bootstrap registrations" }),
                      /* @__PURE__ */ jsx("small", { style: { color: "#fecaca", lineHeight: 1.35 }, children: "Current-wallet registrations without a matching instance. Forget them directly from here." })
                    ] }),
                    orphanRegistrations.map((entry) => {
                      const registrationHash = entry.messageHash ?? entry.hash ?? null;
                      return /* @__PURE__ */ jsxs(
                        "div",
                        {
                          style: {
                            display: "grid",
                            gap: "0.35rem",
                            padding: "0.75rem",
                            borderRadius: "0.9rem",
                            background: "rgba(15, 23, 42, 0.22)",
                            border: "1px solid rgba(255,255,255,0.08)"
                          },
                          children: [
                            /* @__PURE__ */ jsx("div", { style: { fontWeight: 700 }, children: (entry.content?.registrationId ?? "registration") + " \xB7 " + shortHash(registrationHash ?? "unknown") }),
                            /* @__PURE__ */ jsxs("div", { children: [
                              "Peer: ",
                              entry.content?.peerId ?? "-"
                            ] }),
                            /* @__PURE__ */ jsxs("div", { children: [
                              "Linked instance:",
                              " ",
                              entry.instanceItemHash ? shortHash(entry.instanceItemHash) : "missing"
                            ] }),
                            /* @__PURE__ */ jsxs("div", { children: [
                              "Browser multiaddrs:",
                              " ",
                              String(entry.content?.browserMultiaddrs?.length ?? 0)
                            ] }),
                            /* @__PURE__ */ jsxs("div", { children: [
                              "Updated:",
                              " ",
                              formatDateTime(entry.content?.updatedAt ?? entry.time)
                            ] }),
                            /* @__PURE__ */ jsx(
                              "button",
                              {
                                type: "button",
                                style: warningButtonStyle,
                                disabled: !registrationHash || state.busy.deletingRegistrationHash === registrationHash,
                                onClick: () => registrationHash ? void controller.deleteBootstrapRegistration(
                                  registrationHash
                                ) : void 0,
                                children: state.busy.deletingRegistrationHash === registrationHash ? "Forgetting\u2026" : "Forget registration"
                              }
                            )
                          ]
                        },
                        registrationHash ?? entry.content?.registrationId ?? `orphan-${entry.content?.peerId ?? "unknown"}`
                      );
                    })
                  ]
                }
              ) : null
            ]
          }
        ) : null
      ] })
    ] }) : null
  ] });
}
export {
  SponsorRelayFab,
  SponsorRelayFab as default,
  useSponsorRelayController
};
