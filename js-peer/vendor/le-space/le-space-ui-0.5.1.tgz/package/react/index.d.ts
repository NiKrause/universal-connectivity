import * as react_jsx_runtime from 'react/jsx-runtime';

type MessageStatus = 'processed' | 'pending' | 'rejected' | 'unknown';
interface BalanceResponse {
    address: string;
    balance: string;
    locked_amount: string;
    details?: Record<string, string>;
    credit_balance: number;
}
interface Price {
    payg?: string | number | null;
    holding?: string | number | null;
    fixed?: string | number | null;
    credit?: string | number | null;
}
interface ComputeUnit {
    vcpus: number;
    memory_mib: number;
    disk_mib: number;
}
interface Tier {
    id: string;
    compute_units: number;
    vram?: number | null;
    model?: string | null;
}
interface InstancePricing {
    price: {
        storage?: Price;
        compute_unit?: Price;
    };
    compute_unit: ComputeUnit;
    tiers: Tier[];
}
interface CrnUsage {
    cpu?: {
        count?: number;
    };
    mem?: {
        available_kB?: number;
    };
    disk?: {
        available_kB?: number;
    };
    active?: boolean;
}
interface CrnLocation {
    city?: string | null;
    region?: string | null;
    country?: string | null;
    country_code?: string | null;
}
interface Crn {
    hash: string;
    name: string;
    address: string;
    score?: number | string | null;
    performance?: number | string | null;
    decentralization?: number | string | null;
    qemu_support?: boolean;
    confidential_support?: boolean;
    gpu_support?: boolean;
    system_usage?: CrnUsage | null;
    payment_receiver_address?: string | null;
    version?: string | null;
    city?: string | null;
    region?: string | null;
    country?: string | null;
    country_code?: string | null;
    location?: CrnLocation | string | null;
    resolved_ip?: string | null;
    geo_source?: string | null;
}
type PaymentMode = 'hold' | 'credit';
interface InstanceMessage {
    item_hash: string;
    sender: string;
    chain: string;
    type: 'INSTANCE';
    channel?: string;
    content?: {
        metadata?: {
            name?: string;
        };
        payment?: {
            type?: PaymentMode;
            chain?: string;
        };
        rootfs?: {
            parent?: {
                ref?: string;
            };
            size_mib?: number;
        };
        requirements?: {
            node?: {
                node_hash?: string;
            };
        };
    };
    time?: string | number;
    reception_time?: string;
    confirmed?: boolean;
    status?: string;
}
interface InstancePortMapping {
    host?: number;
    tcp?: boolean;
    udp?: boolean;
}
interface InstanceExecutionStatus {
    defined_at?: string | null;
    preparing_at?: string | null;
    prepared_at?: string | null;
    starting_at?: string | null;
    started_at?: string | null;
    stopping_at?: string | null;
    stopped_at?: string | null;
}
interface InstanceExecutionNetworking {
    ipv4?: string | null;
    ipv6?: string | null;
    ipv4_network?: string | null;
    host_ipv4?: string | null;
    ipv6_network?: string | null;
    ipv6_ip?: string | null;
    ipv4_ip?: string | null;
    proxy_url?: string | null;
    mapped_ports?: Record<string, InstancePortMapping>;
}
interface InstanceExecution {
    crnUrl: string;
    version: 'v1' | 'v2';
    running?: boolean;
    networking: InstanceExecutionNetworking;
    status?: InstanceExecutionStatus | null;
}
interface RootfsRequiredPortForward {
    port: number;
    tcp?: boolean;
    udp?: boolean;
    purpose?: string;
}
interface RootfsManifest {
    profile?: string;
    version: string;
    rootfsInstallStrategy?: 'thin' | 'prebaked' | string;
    requiresBootstrapNetwork?: boolean;
    bootstrapSummary?: string;
    requiredPortForwards?: RootfsRequiredPortForward[];
    rootfsItemHash: string;
    rootfsSizeMiB: number;
    rootfsSourceSizeBytes?: number;
    createdAt: string;
    notes?: string;
}
interface RootfsManifestState {
    manifest: RootfsManifest | null;
    valid: boolean;
    errors: string[];
}
type GatewayProbeStatus = 'reachable' | 'timeout' | 'error' | 'unavailable' | 'unknown';
interface RootfsResolution {
    itemHash: string;
    messageStatus: MessageStatus;
    messageType: string | null;
    cid: string | null;
    receptionTime?: string | null;
    rejectionErrorCode?: number | null;
    rejectionReason?: string | null;
    gatewayUrl: string | null;
    gatewayStatus: GatewayProbeStatus;
    gatewayError?: string | null;
}

type DeploymentProgressStage = "idle" | "validating" | "loading-manifest" | "verifying-rootfs" | "loading-pricing" | "loading-balance" | "selecting-crn" | "building-message" | "signing-message" | "broadcasting" | "notifying-crn" | "waiting-for-aleph" | "deployment-confirmed" | "deployment-rejected" | "publishing-bootstrap" | "building-delete-message" | "signing-delete-message" | "broadcasting-delete" | "delete-completed" | "refreshing-instances" | "completed" | "error";
interface DeploymentProgressEvent {
    stage: DeploymentProgressStage;
    label: string;
    progress: number;
    status: "info" | "success" | "warning" | "error";
    itemHash?: string | null;
    detail?: string | null;
    error?: string | null;
    timestamp: number;
}
type DeploymentProgressListener = (event: DeploymentProgressEvent) => void;

type SponsorRelayHealthTone = 'ok' | 'caution' | 'error' | 'idle';
interface SponsorRelayProps {
    debug?: boolean;
    manifestUrl?: string;
    manifestJson?: string;
    sshPublicKey?: string;
    instanceName?: string;
    showInstances?: boolean;
    openByDefault?: boolean;
    launcherMode?: 'floating' | 'inline';
    version?: string;
    apiHost?: string;
    crnListUrl?: string;
    schedulerApiHost?: string;
    twoN6ApiHost?: string;
}
interface SponsorRelayWalletState {
    connected: boolean;
    address: string | null;
    chainId: string | null;
    isMetaMask: boolean;
}
interface SponsorRelayPricingSummary {
    pricing: InstancePricing | null;
    tier: Tier | null;
    requiredCredits: number | null;
    availableCredits: number | null;
    vcpus: number | null;
    memoryMiB: number | null;
    diskMiB: number | null;
}
interface SponsorRelayRootfsHealth {
    tone: SponsorRelayHealthTone;
    label: string;
    detail: string | null;
}
interface CompactInstanceDetails {
    messageStatus: string;
    allocationSource: string | null;
    crnUrl: string | null;
    hostIpv4: string | null;
    ipv6: string | null;
    vmIpv4: string | null;
    webUrl: string | null;
    sshCommand: string | null;
    mappedPorts: Array<{
        label: string;
        hostPort: number | null;
    }>;
    execution: InstanceExecution | null;
    error: string | null;
}
interface CompactInstanceRecord {
    instance: InstanceMessage;
    details: CompactInstanceDetails;
}
interface CompactBootstrapRegistrationRecord {
    messageHash: string | null;
    hash: string | null;
    itemHash: string | null;
    address: string | null;
    time: number | null;
    instanceItemHash: string | null;
    confirmed: boolean;
    content: {
        peerId: string;
        registrationId?: string;
        multiaddrs: string[];
        browserMultiaddrs?: string[];
        ownerAddress?: string;
        publisherAddress?: string;
        updatedAt: number;
    } | null;
}
interface SponsorRelayState {
    ready: boolean;
    open: boolean;
    wallet: SponsorRelayWalletState;
    manifestUrl: string;
    manifestJson: string;
    sshPublicKey: string;
    instanceName: string;
    tierId: string;
    showAdvanced: boolean;
    showInstances: boolean;
    showPasteManifest: boolean;
    busy: {
        connectingWallet: boolean;
        refreshing: boolean;
        deploying: boolean;
        deletingInstanceHash: string | null;
        deletingRegistrationHash: string | null;
    };
    statusText: string;
    errorText: string | null;
    manifestState: RootfsManifestState;
    manifest: RootfsManifest | null;
    rootfsResolution: RootfsResolution | null;
    rootfsVerified: boolean;
    rootfsHealth: SponsorRelayRootfsHealth;
    pricingSummary: SponsorRelayPricingSummary;
    balance: BalanceResponse | null;
    crns: Crn[];
    selectedCrn: Crn | null;
    instances: CompactInstanceRecord[];
    bootstrapRegistrations: CompactBootstrapRegistrationRecord[];
    orphanBootstrapRegistrations: CompactBootstrapRegistrationRecord[];
    lastDeploymentHash: string | null;
    deploymentProgress: DeploymentProgressEvent;
}
type SponsorRelaySubscriber = (state: SponsorRelayState) => void;

declare class SponsorRelayController {
    private state;
    private subscribers;
    private client;
    private refreshTimer;
    private manifestRefreshTimer;
    private stopWalletWatch;
    private props;
    private progressEmitter;
    private runtimeCooldownByHash;
    private runtimeDetailsByHash;
    private debugEnabled;
    private lastCompletedDeploymentHash;
    constructor(props?: SponsorRelayProps);
    subscribeToDeploymentProgress(listener: DeploymentProgressListener): () => void;
    subscribe(subscriber: SponsorRelaySubscriber): () => void;
    getState(): SponsorRelayState;
    updateProps(props: Partial<SponsorRelayProps>): void;
    private emit;
    private trace;
    private patch;
    private emitProgress;
    private configureRelayBootstrapRegistration;
    private cleanupStaleVmBootstrapConfigHistory;
    private syncLatestDeploymentProgress;
    private canSkipRuntimeRefresh;
    private noteRuntimeRefreshResult;
    private rememberRuntimeDetails;
    private mergeRememberedRuntimeDetails;
    init(): Promise<void>;
    destroy(): void;
    setOpen(open: boolean): void;
    toggleOpen(): void;
    setManifestUrl(manifestUrl: string): void;
    setManifestJson(manifestJson: string): void;
    setShowAdvanced(showAdvanced: boolean): void;
    setShowPasteManifest(showPasteManifest: boolean): void;
    setSshPublicKey(sshPublicKey: string): void;
    setInstanceName(instanceName: string): void;
    setTierId(tierId: string): void;
    private recomputePricingSummary;
    private queueManifestRefresh;
    connectWallet(): Promise<void>;
    private refreshWalletDerivedState;
    refresh(): Promise<void>;
    deploy(): Promise<void>;
    deleteInstance(instanceHash: string): Promise<void>;
    deleteBootstrapRegistration(registrationHash: string): Promise<void>;
}

declare function SponsorRelayFab(props: SponsorRelayProps): react_jsx_runtime.JSX.Element;

declare function useSponsorRelayController(props: SponsorRelayProps): {
    controller: SponsorRelayController;
    state: SponsorRelayState;
};

export { SponsorRelayFab, SponsorRelayFab as default, useSponsorRelayController };
