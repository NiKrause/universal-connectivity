interface RootfsRequiredPortForward {
    port: number;
    tcp?: boolean;
    udp?: boolean;
    purpose?: string;
}
type MessageStatus = 'processed' | 'pending' | 'rejected' | 'unknown';
type GatewayProbeStatus = 'reachable' | 'timeout' | 'error' | 'unavailable' | 'unknown';
type RootfsInstallStrategy = 'thin' | 'prebaked';
interface RootfsManifest {
    profile?: string;
    version: string;
    rootfsInstallStrategy?: RootfsInstallStrategy;
    requiresBootstrapNetwork?: boolean;
    bootstrapSummary?: string;
    rootfsItemHash?: string;
    rootfsCid?: string;
    rootfsSizeMiB: number;
    rootfsSourceSizeBytes?: number;
    requiredPortForwards?: RootfsRequiredPortForward[];
    createdAt: string;
    notes?: string;
}
interface RootfsManifestState {
    manifest: RootfsManifest | null;
    valid: boolean;
    errors: string[];
}
interface PortForwardFlags {
    tcp: boolean;
    udp: boolean;
}
interface PortForwardAggregateEntry {
    ports?: Record<string, PortForwardFlags>;
}
type PortForwardAggregate = Record<string, PortForwardAggregateEntry>;
interface RootfsResolution {
    itemHash: string;
    messageStatus: MessageStatus;
    messageType: string | null;
    cid: string | null;
    receptionTime?: string | null;
    rejectionErrorCode?: number | null;
    rejectionReason?: string | null;
    gatewayUrl: string | null;
    gatewayStatus: GatewayProbeStatus;
    gatewayError?: string | null;
}

interface PortMapping {
    host?: number;
    tcp?: boolean;
    udp?: boolean;
}
interface CrnSystemUsage {
    cpu?: {
        count?: number;
    };
    mem?: {
        available_kB?: number;
    };
    disk?: {
        available_kB?: number;
    };
    active?: boolean;
}
interface CrnRecord {
    hash: string;
    name?: string;
    address?: string;
    score?: number | string | null;
    qemu_support?: boolean;
    city?: string | null;
    region?: string | null;
    country?: string | null;
    country_code?: string | null;
    resolved_ip?: string | null;
    geo_source?: string | null;
    system_usage?: CrnSystemUsage | null;
}
type ReferenceStatus = 'processed' | 'pending' | 'rejected' | 'unknown' | 'missing';
interface RuntimeMetadata {
    hostIpv4?: string | null;
    ipv6?: string | null;
    proxyUrl?: string | null;
    mappedPorts?: Record<string, PortMapping>;
}
interface MessageReference {
    itemHash: string;
    status: ReferenceStatus;
    type: string | null;
}
interface InstanceAllocationNode {
    node_id?: string;
    url?: string;
    ipv6?: string | null;
    supports_ipv6?: boolean;
}
interface InstanceAllocationPeriod {
    start_timestamp?: string;
    duration_seconds?: number;
}
interface InstanceAllocation {
    source: 'scheduler' | 'manual';
    crnHash?: string | null;
    crnUrl?: string | null;
    node?: InstanceAllocationNode | null;
    vmIpv6?: string | null;
    period?: InstanceAllocationPeriod | null;
}
interface InstanceExecutionStatus {
    defined_at?: string | null;
    preparing_at?: string | null;
    prepared_at?: string | null;
    starting_at?: string | null;
    started_at?: string | null;
    stopping_at?: string | null;
    stopped_at?: string | null;
}
interface InstanceExecutionNetworking {
    ipv4?: string | null;
    ipv6?: string | null;
    ipv4_network?: string | null;
    host_ipv4?: string | null;
    ipv6_network?: string | null;
    ipv6_ip?: string | null;
    ipv4_ip?: string | null;
    proxy_url?: string | null;
    mapped_ports?: Record<string, PortMapping>;
}
interface InstanceExecution {
    crnUrl: string;
    version: 'v1' | 'v2';
    running?: boolean;
    networking: InstanceExecutionNetworking;
    status?: InstanceExecutionStatus | null;
}
interface InstanceWebAccess {
    url?: string | null;
    active?: boolean | null;
    subdomain?: string | null;
}
interface RuntimeDiagnostics {
    state: string;
    reason: string | null;
    timedOut?: boolean;
    schedulerSource?: string | null;
    executionSeen?: boolean;
    webAccessActive?: boolean | null;
    mappedPortCount?: number;
    proxyUrl?: string | null;
}
interface InstanceRuntimeDetails {
    messageStatus: 'processed' | 'pending' | 'rejected' | 'unknown';
    allocation: InstanceAllocation | null;
    execution: InstanceExecution | null;
    webAccess?: InstanceWebAccess | null;
    webAccessUrl?: string | null;
    hostIpv4?: string | null;
    ipv6?: string | null;
    proxyUrl?: string | null;
    mappedPorts?: Record<string, PortMapping>;
    diagnostics?: RuntimeDiagnostics | null;
    sshCommand?: string | null;
    selectedCrn?: CrnRecord | null;
    executionLookupBlocked?: boolean;
    error?: string | null;
}

interface DeploymentResult {
    itemHash: string;
    httpStatus?: number;
    status: "processed" | "pending" | "rejected" | "unknown";
    message?: AlephBroadcastMessage;
    response?: AlephBroadcastResponse;
    rejectionReason?: string | null;
}
type DeploymentProgressStage = "idle" | "validating" | "loading-manifest" | "verifying-rootfs" | "loading-pricing" | "loading-balance" | "selecting-crn" | "building-message" | "signing-message" | "broadcasting" | "notifying-crn" | "waiting-for-aleph" | "deployment-confirmed" | "deployment-rejected" | "publishing-bootstrap" | "building-delete-message" | "signing-delete-message" | "broadcasting-delete" | "delete-completed" | "refreshing-instances" | "completed" | "error";
interface DeploymentProgressEvent {
    stage: DeploymentProgressStage;
    label: string;
    progress: number;
    status: "info" | "success" | "warning" | "error";
    itemHash?: string | null;
    detail?: string | null;
    error?: string | null;
    timestamp: number;
}
type DeploymentProgressListener = (event: DeploymentProgressEvent) => void;
type AlephSenderChain = "ETH";
type AlephMessageType = "INSTANCE" | "FORGET" | "AGGREGATE" | "STORE" | "POST";
interface AlephBroadcastMessage {
    sender: string;
    chain: AlephSenderChain;
    signature: string;
    type: AlephMessageType;
    item_hash: string;
    item_type: "inline";
    item_content: string;
    time: number;
    channel: string;
}
interface AlephBroadcastResponse {
    publication_status?: {
        status: string;
        failed?: unknown[];
    };
    message_status?: "processed" | "pending" | "rejected" | "unknown";
    details?: unknown;
    [key: string]: unknown;
}
interface AlephAggregateContent<T = Record<string, unknown>> {
    address: string;
    key: string;
    content: T;
    time: number;
}
interface AlephInstanceContent {
    address: string;
    time: number;
    allow_amend: boolean;
    metadata?: {
        name: string;
        [key: string]: string | number | boolean;
    };
    authorized_keys?: string[];
    environment: {
        internet: boolean;
        aleph_api: boolean;
        reproducible?: boolean;
        shared_cache?: boolean;
        hypervisor: "qemu";
        trusted_execution?: Record<string, unknown>;
    };
    resources: {
        vcpus: number;
        memory: number;
        seconds: number;
    };
    payment: {
        chain?: string;
        receiver?: string;
        type: string;
    };
    requirements?: {
        node?: {
            node_hash: string;
        };
    };
    volumes: unknown[];
    rootfs: {
        parent: {
            ref: string;
            use_latest?: boolean;
        };
        persistence: "host" | "store";
        size_mib: number;
    };
}
interface DeploymentIntent {
    ownerAddress: string;
    messageTime: number;
    itemHash: string;
    paymentType: string;
    rootfsRef: string;
    rootfsSizeMiB: number;
    computeUnits: number;
    vcpus: number;
    memoryMiB: number;
    crnHash: string | null;
    channel: string;
    expiresAt: number;
    maxCost: string;
}
interface DeploymentIntentEnvelope {
    intent: DeploymentIntent;
    intentHash: string;
}
interface MessageInspectionResult {
    status: "processed" | "pending" | "rejected" | "unknown";
    errorCode: number | null;
    details: Record<string, unknown> | null;
    rejectionReason: string | null;
}
interface DeploymentInspectionResult extends MessageInspectionResult {
    references: MessageReference[];
}
type MessageSigner = (sender: string, payload: string) => Promise<string>;
type MessageHasher = (payload: string) => Promise<string> | string;

type VmBootstrapConfigStatus = 'pending' | 'applied' | 'expired' | 'failed';
type VmBootstrapConfigSignalType = 'applied';
interface VmBootstrapConfigRuntime {
    publicIpv4: string;
    publicIpv6?: string | null;
    proxyUrl?: string | null;
    mappedPorts: Record<string, PortMapping>;
}
interface VmBootstrapConfigBootstrap {
    registrationId?: string | null;
    ownerAuthorizationBase64?: string | null;
}
interface VmBootstrapConfigRecord {
    deploymentToken: string;
    profile: string;
    ownerAddress: string;
    instanceItemHash: string;
    createdAt: string;
    expiresAt: string;
    status: VmBootstrapConfigStatus;
    runtime: VmBootstrapConfigRuntime;
    bootstrap?: VmBootstrapConfigBootstrap | null;
}
type VmBootstrapConfigAggregate = Record<string, VmBootstrapConfigRecord>;
interface VmBootstrapConfigSignalRecord {
    deploymentToken: string;
    status: VmBootstrapConfigSignalType;
    profile: string;
    ownerAddress: string;
    instanceItemHash: string;
    updatedAt: string;
    publisherAddress?: string | null;
    authorization?: unknown;
    peerId?: string | null;
    probeMultiaddrs?: string[];
    browserBootstrapMultiaddrs?: string[];
}

export type { AlephAggregateContent, AlephBroadcastMessage, AlephBroadcastResponse, AlephInstanceContent, AlephMessageType, AlephSenderChain, CrnRecord, CrnSystemUsage, DeploymentInspectionResult, DeploymentIntent, DeploymentIntentEnvelope, DeploymentProgressEvent, DeploymentProgressListener, DeploymentProgressStage, DeploymentResult, GatewayProbeStatus, InstanceAllocation, InstanceAllocationNode, InstanceAllocationPeriod, InstanceExecution, InstanceExecutionNetworking, InstanceExecutionStatus, InstanceRuntimeDetails, InstanceWebAccess, MessageHasher, MessageInspectionResult, MessageReference, MessageSigner, MessageStatus, PortForwardAggregate, PortForwardAggregateEntry, PortForwardFlags, PortMapping, ReferenceStatus, RootfsInstallStrategy, RootfsManifest, RootfsManifestState, RootfsRequiredPortForward, RootfsResolution, RuntimeDiagnostics, RuntimeMetadata, VmBootstrapConfigAggregate, VmBootstrapConfigBootstrap, VmBootstrapConfigRecord, VmBootstrapConfigRuntime, VmBootstrapConfigSignalRecord, VmBootstrapConfigSignalType, VmBootstrapConfigStatus };
