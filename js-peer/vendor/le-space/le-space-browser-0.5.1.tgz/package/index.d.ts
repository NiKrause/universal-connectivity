type BrowserExtractionPhase = 'planned' | 'scaffolded';
interface BrowserPackagePlan {
    phase: BrowserExtractionPhase;
    modules: string[];
}
declare const BROWSER_PACKAGE_PLAN: BrowserPackagePlan;
interface EthereumProviderLike {
    request<T = unknown>(args: {
        method: string;
        params?: unknown[] | Record<string, unknown>;
    }): Promise<T>;
}
interface EthereumTransactionRequest {
    from: string;
    to: string;
    data?: `0x${string}`;
    value?: bigint;
}
type PaymentChain = 'BASE' | 'AVAX' | 'ETH';
interface EvmChainConfig {
    alephChain: PaymentChain;
    chainIdHex: `0x${string}`;
    chainName: string;
    rpcUrls: string[];
    blockExplorerUrls: string[];
    nativeCurrency: {
        name: string;
        symbol: string;
        decimals: number;
    };
}
interface PrepaidReservation {
    intentHash: string;
    ownerAddress: string;
    reservedAmount: bigint;
    expiresAt: number;
    consumed: boolean;
    expired: boolean;
}
interface PrepaidVaultSnapshot {
    totalDeposited: bigint;
    availableBalance: bigint;
    reservedBalance: bigint;
    currentReservation: PrepaidReservation | null;
}
type MessageStatus = 'processed' | 'pending' | 'rejected' | 'unknown';
type ReferenceStatus = MessageStatus | 'missing';
type AlephSenderChain = 'ETH';
type AlephMessageType = 'INSTANCE' | 'FORGET' | 'AGGREGATE';
interface BalanceResponse {
    address: string;
    balance: string;
    locked_amount: string;
    details?: Record<string, string>;
    credit_balance: number;
}
interface Price {
    payg?: string | number | null;
    holding?: string | number | null;
    fixed?: string | number | null;
    credit?: string | number | null;
}
interface ComputeUnit {
    vcpus: number;
    memory_mib: number;
    disk_mib: number;
}
interface Tier {
    id: string;
    compute_units: number;
    vram?: number | null;
    model?: string | null;
}
interface InstancePricing {
    price: {
        storage?: Price;
        compute_unit?: Price;
    };
    compute_unit: ComputeUnit;
    tiers: Tier[];
}
interface PricingState {
    pricing: InstancePricing | null;
    fetchedAt: number | null;
}
interface CrnUsage {
    cpu?: {
        count?: number;
    };
    mem?: {
        available_kB?: number;
    };
    disk?: {
        available_kB?: number;
    };
    active?: boolean;
}
interface CrnLocation {
    city?: string | null;
    region?: string | null;
    country?: string | null;
    country_code?: string | null;
}
interface Crn {
    hash: string;
    name: string;
    address: string;
    score?: number | string | null;
    performance?: number | string | null;
    decentralization?: number | string | null;
    qemu_support?: boolean;
    confidential_support?: boolean;
    gpu_support?: boolean;
    system_usage?: CrnUsage | null;
    payment_receiver_address?: string | null;
    version?: string | null;
    city?: string | null;
    region?: string | null;
    country?: string | null;
    country_code?: string | null;
    location?: CrnLocation | string | null;
    resolved_ip?: string | null;
    geo_source?: string | null;
}
interface CrnListResponse {
    crns: Crn[];
}
type PaymentMode = 'hold' | 'credit';
interface InstanceMessage {
    item_hash: string;
    sender: string;
    chain: string;
    type: 'INSTANCE';
    channel?: string;
    content?: {
        metadata?: {
            name?: string;
        };
        payment?: {
            type?: PaymentMode;
            chain?: string;
        };
        rootfs?: {
            parent?: {
                ref?: string;
            };
            size_mib?: number;
        };
        requirements?: {
            node?: {
                node_hash?: string;
            };
        };
    };
    time?: string | number;
    reception_time?: string;
    confirmed?: boolean;
    status?: string;
}
interface AlephMessageEnvelope {
    status?: unknown;
    type?: unknown;
    error_code?: unknown;
    details?: unknown;
    message?: {
        type?: unknown;
    } | null;
    messages?: Array<{
        type?: unknown;
    }> | null;
    [key: string]: unknown;
}
interface MessageReference {
    itemHash: string;
    status: ReferenceStatus;
    type: string | null;
}
interface DeploymentInspectionResult {
    status: MessageStatus;
    errorCode: number | null;
    details: Record<string, unknown> | null;
    rejectionReason: string | null;
    references: MessageReference[];
}
interface InstanceAllocationNode {
    node_id?: string;
    url?: string;
    ipv6?: string | null;
    supports_ipv6?: boolean;
}
interface InstanceAllocationPeriod {
    start_timestamp?: string;
    duration_seconds?: number;
}
interface InstanceAllocation {
    source: 'scheduler' | 'manual';
    crnHash?: string | null;
    crnUrl?: string | null;
    node?: InstanceAllocationNode | null;
    vmIpv6?: string | null;
    period?: InstanceAllocationPeriod | null;
}
interface InstancePortMapping {
    host?: number;
    tcp?: boolean;
    udp?: boolean;
}
interface InstanceExecutionStatus {
    defined_at?: string | null;
    preparing_at?: string | null;
    prepared_at?: string | null;
    starting_at?: string | null;
    started_at?: string | null;
    stopping_at?: string | null;
    stopped_at?: string | null;
}
interface InstanceExecutionNetworking {
    ipv4?: string | null;
    ipv6?: string | null;
    ipv4_network?: string | null;
    host_ipv4?: string | null;
    ipv6_network?: string | null;
    ipv6_ip?: string | null;
    ipv4_ip?: string | null;
    proxy_url?: string | null;
    mapped_ports?: Record<string, InstancePortMapping>;
}
interface InstanceExecution {
    crnUrl: string;
    version: 'v1' | 'v2';
    running?: boolean;
    networking: InstanceExecutionNetworking;
    status?: InstanceExecutionStatus | null;
}
interface CrnExecutionLookupResult {
    payload: Record<string, unknown> | null;
    blocked: boolean;
    requestUrl?: string;
    version?: 'v1' | 'v2';
}
interface AllocationNotifyResult {
    status: 'confirmed' | 'unconfirmed';
}
interface RelaySetupRequest {
    hostIpv4: string;
    publicIpv6?: string | null;
    setupPort: number;
    tcpPort: number;
    wsPort: number;
    proxyUrl?: string | null;
    metricsPort?: number | null;
    metricsHttpsPort?: number | null;
    webrtcPort?: number | null;
    quicPort?: number | null;
}
interface RelaySetupResult {
    status: 'configured' | 'unconfirmed';
}
interface AlephBroadcastMessage {
    sender: string;
    chain: AlephSenderChain;
    signature: string;
    type: AlephMessageType;
    item_hash: string;
    item_type: 'inline';
    item_content: string;
    time: number;
    channel: string;
}
interface AlephBroadcastResponse {
    publication_status?: {
        status: string;
        failed?: unknown[];
    };
    message_status?: MessageStatus;
    [key: string]: unknown;
}
interface BroadcastResult {
    response: AlephBroadcastResponse;
    httpStatus: number;
}
interface AlephBrowserClient {
    apiHost: string;
    crnListUrl: string;
    schedulerApiHost: string;
    fetchBalance(address: string): Promise<BalanceResponse>;
    fetchCrns(): Promise<Crn[]>;
    fetchInstances(address: string): Promise<InstanceMessage[]>;
    fetch2n6WebAccessUrl(itemHash: string): Promise<string | null>;
    fetchMessageEnvelope(itemHash: string): Promise<AlephMessageEnvelope | null>;
    fetchSchedulerAllocation(itemHash: string): Promise<InstanceAllocation | null>;
    fetchCrnExecutionMap(crnUrl: string): Promise<CrnExecutionLookupResult>;
    notifyCrnAllocation(crnUrl: string, itemHash: string): Promise<AllocationNotifyResult>;
    configureOrbitdbRelaySetup(args: RelaySetupRequest): Promise<RelaySetupResult>;
    inspectDeploymentResult(itemHash: string, rootfsRef?: string): Promise<DeploymentInspectionResult>;
    waitForDeploymentResult(itemHash: string, rootfsRef?: string, attempts?: number, delayMs?: number): Promise<DeploymentInspectionResult>;
    broadcastInstanceMessage(message: AlephBroadcastMessage, sync?: boolean): Promise<BroadcastResult>;
    broadcastAlephMessage(message: AlephBroadcastMessage, sync?: boolean): Promise<BroadcastResult>;
}
interface RootfsRequiredPortForward {
    port: number;
    tcp?: boolean;
    udp?: boolean;
    purpose?: string;
}
interface RootfsManifest {
    profile?: string;
    version: string;
    rootfsInstallStrategy?: 'thin' | 'prebaked' | string;
    requiresBootstrapNetwork?: boolean;
    bootstrapSummary?: string;
    requiredPortForwards?: RootfsRequiredPortForward[];
    rootfsItemHash: string;
    rootfsSizeMiB: number;
    rootfsSourceSizeBytes?: number;
    createdAt: string;
    notes?: string;
}
interface RootfsManifestState {
    manifest: RootfsManifest | null;
    valid: boolean;
    errors: string[];
}
type GatewayProbeStatus = 'reachable' | 'timeout' | 'error' | 'unavailable' | 'unknown';
interface RootfsResolution {
    itemHash: string;
    messageStatus: MessageStatus;
    messageType: string | null;
    cid: string | null;
    receptionTime?: string | null;
    rejectionErrorCode?: number | null;
    rejectionReason?: string | null;
    gatewayUrl: string | null;
    gatewayStatus: GatewayProbeStatus;
    gatewayError?: string | null;
}

declare function fetchWithTimeout(input: RequestInfo | URL, init?: RequestInit, timeoutMs?: number): Promise<Response>;

declare const DEFAULT_ALEPH_API_HOST = "https://api.aleph.im";
declare const DEFAULT_CRN_LIST_URL = "https://crns-list.aleph.sh/crns.json";
declare const DEFAULT_ALEPH_SCHEDULER_API_HOST = "https://scheduler.api.aleph.cloud";
declare const DEFAULT_2N6_API_HOST = "https://api.2n6.me";
type CrnExecutionV1Payload = {
    networking?: {
        ipv4?: unknown;
        ipv6?: unknown;
    } | null;
};
type CrnExecutionV2Payload = {
    networking?: {
        ipv4_network?: unknown;
        host_ipv4?: unknown;
        ipv6_network?: unknown;
        ipv6_ip?: unknown;
        ipv4_ip?: unknown;
        proxy_url?: unknown;
        proxyUrl?: unknown;
        web_access_url?: unknown;
        webAccessUrl?: unknown;
        proxy_hostname?: unknown;
        proxyHostname?: unknown;
        domain?: unknown;
        hostname?: unknown;
        mapped_ports?: Record<string, {
            host?: unknown;
            tcp?: unknown;
            udp?: unknown;
        }> | null;
    } | null;
    web_access?: {
        url?: unknown;
        proxy_url?: unknown;
        hostname?: unknown;
        domain?: unknown;
    } | null;
    webAccess?: {
        url?: unknown;
        proxy_url?: unknown;
        hostname?: unknown;
        domain?: unknown;
    } | null;
    status?: {
        defined_at?: unknown;
        preparing_at?: unknown;
        prepared_at?: unknown;
        starting_at?: unknown;
        started_at?: unknown;
        stopping_at?: unknown;
        stopped_at?: unknown;
    } | null;
    running?: unknown;
};
declare function normalizeMessageStatus(status: unknown): MessageStatus;
declare function fetchBalance(address: string, apiHost?: string): Promise<BalanceResponse>;
declare function fetchCrns(url?: string): Promise<Crn[]>;
declare function fetchInstances(address: string, apiHost?: string): Promise<InstanceMessage[]>;
declare function fetch2n6WebAccessUrl(itemHash: string, twoN6ApiHost?: string): Promise<string | null>;
declare function fetchSchedulerAllocation(itemHash: string, schedulerApiHost?: string): Promise<InstanceAllocation | null>;
declare function fetchCrnExecutionMap(crnUrl: string): Promise<CrnExecutionLookupResult>;
declare function normalizeExecution(item: CrnExecutionV1Payload | CrnExecutionV2Payload, crnUrl: string): InstanceExecution;
declare function notifyCrnAllocation(crnUrl: string, itemHash: string): Promise<AllocationNotifyResult>;
declare function configureOrbitdbRelaySetup(args: RelaySetupRequest): Promise<RelaySetupResult>;
declare function fetchMessageEnvelope(itemHash: string, apiHost?: string): Promise<AlephMessageEnvelope | null>;
declare function inspectDeploymentResult(itemHash: string, rootfsRef?: string, apiHost?: string): Promise<DeploymentInspectionResult>;
declare function waitForDeploymentResult(itemHash: string, rootfsRef?: string, apiHost?: string, attempts?: number, delayMs?: number): Promise<DeploymentInspectionResult>;
declare function broadcastInstanceMessage(message: AlephBroadcastMessage, apiHost?: string, sync?: boolean): Promise<BroadcastResult>;
declare function broadcastAlephMessage(message: AlephBroadcastMessage, apiHost?: string, sync?: boolean): Promise<BroadcastResult>;

interface CreateAlephBrowserClientOptions {
    apiHost?: string;
    crnListUrl?: string;
    schedulerApiHost?: string;
    twoN6ApiHost?: string;
}
declare function createAlephBrowserClient(options?: CreateAlephBrowserClientOptions): AlephBrowserClient;

declare function ethCall(to: string, data: `0x${string}`, provider: EthereumProviderLike | null | undefined): Promise<string>;
declare function sendTransaction(tx: EthereumTransactionRequest, provider: EthereumProviderLike | null | undefined): Promise<string>;
declare function personalSign(address: string, message: string, provider: EthereumProviderLike | null | undefined): Promise<string>;

declare function paymentChainFromChainId(chainId: string | null, chainConfig: Record<PaymentChain, EvmChainConfig>): PaymentChain | null;
declare function formatBudgetUnits(value: bigint, decimals?: number): number;
declare function loadPrepaidReservation(args: {
    ownerAddress: string;
    intentHash: string;
    vaultAddress: string;
    provider: EthereumProviderLike | null | undefined;
}): Promise<PrepaidReservation | null>;
declare function loadPrepaidVaultSnapshot(args: {
    ownerAddress: string;
    currentIntentHash?: string | null;
    vaultAddress: string;
    provider: EthereumProviderLike | null | undefined;
}): Promise<PrepaidVaultSnapshot>;
declare function approvePrepaidBudget(args: {
    ownerAddress: string;
    amount: bigint;
    tokenAddress: string;
    vaultAddress: string;
    provider: EthereumProviderLike | null | undefined;
}): Promise<string>;
declare function depositPrepaidBudget(args: {
    ownerAddress: string;
    amount: bigint;
    vaultAddress: string;
    provider: EthereumProviderLike | null | undefined;
}): Promise<string>;
declare function reserveDeploymentBudget(args: {
    ownerAddress: string;
    intentHash: string;
    amount: bigint;
    expiresAt: number;
    vaultAddress: string;
    provider: EthereumProviderLike | null | undefined;
}): Promise<string>;
declare function consumeDeploymentReservation(args: {
    ownerAddress: string;
    intentHash: string;
    amount: bigint;
    vaultAddress: string;
    provider: EthereumProviderLike | null | undefined;
}): Promise<string>;
declare function refundExpiredReservation(args: {
    ownerAddress: string;
    intentHash: string;
    vaultAddress: string;
    provider: EthereumProviderLike | null | undefined;
}): Promise<string>;

declare const ITEM_HASH_RE: RegExp;
declare const DEFAULT_ROOTFS_MANIFEST_URL = "./rootfs-manifest.json";
declare const DEFAULT_IPFS_GATEWAY_BASE_URL = "https://ipfs.aleph.cloud/ipfs/";
interface LoadRootfsManifestOptions {
    baseUrl?: string | URL;
}
declare function validateRootfsManifest(manifest: RootfsManifest | null): RootfsManifestState;
declare function loadRootfsManifest(url?: string | URL, options?: LoadRootfsManifestOptions): Promise<RootfsManifestState>;
declare function verifyRootfsExists(itemHash: string, apiHost?: string): Promise<boolean>;
declare function resolveRootfsReference(itemHash: string, apiHost?: string, gatewayBaseUrl?: string): Promise<RootfsResolution | null>;

declare const DEFAULT_ALEPH_AGGREGATE_ADDRESS = "0xFba561a84A537fCaa567bb7A2257e7142701ae2A";
declare function parseInstancePricing(payload: unknown): InstancePricing;
declare function fetchInstancePricing(apiHost?: string, aggregateAddress?: string): Promise<PricingState>;

export { type AlephBroadcastMessage, type AlephBroadcastResponse, type AlephBrowserClient, type AlephMessageEnvelope, type AlephMessageType, type AlephSenderChain, type AllocationNotifyResult, BROWSER_PACKAGE_PLAN, type BalanceResponse, type BroadcastResult, type BrowserExtractionPhase, type BrowserPackagePlan, type ComputeUnit, type CreateAlephBrowserClientOptions, type Crn, type CrnExecutionLookupResult, type CrnListResponse, type CrnLocation, type CrnUsage, DEFAULT_2N6_API_HOST, DEFAULT_ALEPH_AGGREGATE_ADDRESS, DEFAULT_ALEPH_API_HOST, DEFAULT_ALEPH_SCHEDULER_API_HOST, DEFAULT_CRN_LIST_URL, DEFAULT_IPFS_GATEWAY_BASE_URL, DEFAULT_ROOTFS_MANIFEST_URL, type DeploymentInspectionResult, type EthereumProviderLike, type EthereumTransactionRequest, type EvmChainConfig, type GatewayProbeStatus, ITEM_HASH_RE, type InstanceAllocation, type InstanceAllocationNode, type InstanceAllocationPeriod, type InstanceExecution, type InstanceExecutionNetworking, type InstanceExecutionStatus, type InstanceMessage, type InstancePortMapping, type InstancePricing, type LoadRootfsManifestOptions, type MessageReference, type MessageStatus, type PaymentChain, type PaymentMode, type PrepaidReservation, type PrepaidVaultSnapshot, type Price, type PricingState, type ReferenceStatus, type RelaySetupRequest, type RelaySetupResult, type RootfsManifest, type RootfsManifestState, type RootfsRequiredPortForward, type RootfsResolution, type Tier, approvePrepaidBudget, broadcastAlephMessage, broadcastInstanceMessage, configureOrbitdbRelaySetup, consumeDeploymentReservation, createAlephBrowserClient, depositPrepaidBudget, ethCall, fetch2n6WebAccessUrl, fetchBalance, fetchCrnExecutionMap, fetchCrns, fetchInstancePricing, fetchInstances, fetchMessageEnvelope, fetchSchedulerAllocation, fetchWithTimeout, formatBudgetUnits, inspectDeploymentResult, loadPrepaidReservation, loadPrepaidVaultSnapshot, loadRootfsManifest, normalizeExecution, normalizeMessageStatus, notifyCrnAllocation, parseInstancePricing, paymentChainFromChainId, personalSign, refundExpiredReservation, reserveDeploymentBudget, resolveRootfsReference, sendTransaction, validateRootfsManifest, verifyRootfsExists, waitForDeploymentResult };
