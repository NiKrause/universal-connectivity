// src/types.ts
var BROWSER_PACKAGE_PLAN = {
  phase: "scaffolded",
  modules: ["http", "aleph-api", "client", "evm", "rootfs", "pricing"]
};

// src/http.ts
async function fetchWithTimeout(input, init = {}, timeoutMs = 15e3) {
  const controller = new AbortController();
  const timeout = globalThis.setTimeout(() => controller.abort(), timeoutMs);
  try {
    if (input instanceof URL) {
      const url = new URL(input.toString());
      url.searchParams.set("_ts", String(Date.now()));
      return await fetch(url, {
        ...init,
        cache: init.cache ?? "no-store",
        signal: init.signal ?? controller.signal
      });
    }
    if (typeof input === "string") {
      let requestInput = input;
      try {
        const url = new URL(input, globalThis.location?.href);
        url.searchParams.set("_ts", String(Date.now()));
        requestInput = url;
      } catch {
      }
      return await fetch(requestInput, {
        ...init,
        cache: init.cache ?? "no-store",
        signal: init.signal ?? controller.signal
      });
    }
    return await fetch(input, {
      ...init,
      cache: init.cache ?? "no-store",
      signal: init.signal ?? controller.signal
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error(`Request timed out after ${timeoutMs / 1e3}s.`);
    }
    throw error;
  } finally {
    globalThis.clearTimeout(timeout);
  }
}

// src/aleph-api.ts
var DEFAULT_ALEPH_API_HOST = "https://api.aleph.im";
var DEFAULT_CRN_LIST_URL = "https://crns-list.aleph.sh/crns.json";
var DEFAULT_ALEPH_SCHEDULER_API_HOST = "https://scheduler.api.aleph.cloud";
var DEFAULT_2N6_API_HOST = "https://api.2n6.me";
function normalizeMessageStatus(status) {
  if (typeof status !== "string") return "unknown";
  const normalized = status.toLowerCase();
  if (normalized === "processed" || normalized === "pending" || normalized === "rejected") {
    return normalized;
  }
  return "unknown";
}
function asString(value) {
  return typeof value === "string" && value.trim() ? value : null;
}
function asNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function isUnconfirmedNetworkError(error) {
  const message = error instanceof Error ? error.message : String(error);
  return error instanceof TypeError || message.includes("Failed to fetch") || message.includes("Request timed out");
}
function normalizeProxyUrl(value) {
  const stringValue = asString(value);
  if (!stringValue) return null;
  if (/^https?:\/\//i.test(stringValue)) return stringValue;
  return `https://${stringValue}`;
}
function extractProxyUrl(value, networking) {
  const networkingCandidates = [
    networking?.proxy_url,
    networking?.proxyUrl,
    networking?.web_access_url,
    networking?.webAccessUrl,
    networking?.proxy_hostname,
    networking?.proxyHostname,
    networking?.domain,
    networking?.hostname
  ];
  for (const candidate of networkingCandidates) {
    const normalized = normalizeProxyUrl(candidate);
    if (normalized) return normalized;
  }
  for (const entry of [value.web_access, value.webAccess]) {
    const normalized = normalizeProxyUrl(entry?.url) ?? normalizeProxyUrl(entry?.proxy_url) ?? normalizeProxyUrl(entry?.hostname) ?? normalizeProxyUrl(entry?.domain);
    if (normalized) return normalized;
  }
  return null;
}
async function fetchBalance(address, apiHost = DEFAULT_ALEPH_API_HOST) {
  const response = await fetchWithTimeout(`${apiHost}/api/v0/addresses/${address}/balance`, {
    cache: "no-cache"
  });
  if (!response.ok) throw new Error(`Balance request failed: ${response.status}`);
  return await response.json();
}
async function fetchCrns(url = DEFAULT_CRN_LIST_URL) {
  const requestUrl = new URL(url);
  requestUrl.searchParams.set("filter_inactive", "true");
  const response = await fetchWithTimeout(requestUrl, { cache: "no-cache" });
  if (!response.ok) throw new Error(`CRN list request failed: ${response.status}`);
  const payload = await response.json();
  return payload.crns ?? [];
}
async function fetchInstances(address, apiHost = DEFAULT_ALEPH_API_HOST) {
  const url = new URL("/api/v0/messages.json", apiHost);
  url.searchParams.set("msgTypes", "INSTANCE");
  url.searchParams.set("addresses", address);
  url.searchParams.set("message_statuses", "processed,pending,rejected");
  url.searchParams.set("pagination", "100");
  url.searchParams.set("page", "1");
  url.searchParams.set("sortOrder", "-1");
  const response = await fetchWithTimeout(url, { cache: "no-cache" });
  if (!response.ok) throw new Error(`Instance list request failed: ${response.status}`);
  const payload = await response.json();
  return (payload.messages ?? []).map((message) => ({
    ...message,
    status: typeof message.status === "string" && message.status.trim() ? message.status : message.confirmed ? "processed" : "pending"
  }));
}
async function fetch2n6WebAccessUrl(itemHash, twoN6ApiHost = DEFAULT_2N6_API_HOST) {
  const requestUrl = new URL(`/api/hash/${itemHash}`, twoN6ApiHost).toString();
  try {
    const response = await fetchWithTimeout(requestUrl, { cache: "no-cache" });
    if (response.status === 404 || !response.ok) {
      return null;
    }
    const payload = await response.json();
    return normalizeProxyUrl(payload.url ?? payload.subdomain);
  } catch {
    return null;
  }
}
async function fetchSchedulerAllocation(itemHash, schedulerApiHost = DEFAULT_ALEPH_SCHEDULER_API_HOST) {
  const response = await fetchWithTimeout(`${schedulerApiHost}/api/v0/allocation/${itemHash}`, {
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Scheduler allocation request failed: ${response.status}`);
  const payload = await response.json();
  const node = payload.node;
  return {
    source: "scheduler",
    crnUrl: asString(node?.url),
    node: node ? {
      node_id: asString(node.node_id) ?? void 0,
      url: asString(node.url) ?? void 0,
      ipv6: asString(node.ipv6),
      supports_ipv6: typeof node.supports_ipv6 === "boolean" ? node.supports_ipv6 : void 0
    } : null,
    vmIpv6: asString(payload.vm_ipv6),
    period: payload.period ? {
      start_timestamp: asString(payload.period.start_timestamp) ?? void 0,
      duration_seconds: asNumber(payload.period.duration_seconds) ?? void 0
    } : null
  };
}
async function fetchCrnExecutionMap(crnUrl) {
  const normalizedCrnUrl = crnUrl.replace(/\/+$/, "");
  const v2Url = `${normalizedCrnUrl}/v2/about/executions/list`;
  const v1Url = `${normalizedCrnUrl}/about/executions/list`;
  try {
    const v2Response = await fetchWithTimeout(v2Url, { cache: "no-cache" });
    if (v2Response.ok) {
      const payload = await v2Response.json();
      return {
        payload,
        blocked: false,
        requestUrl: v2Url,
        version: "v2"
      };
    }
    if (v2Response.status !== 404) {
      return { payload: null, blocked: false, requestUrl: v2Url, version: "v2" };
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (error instanceof TypeError || message.includes("Failed to fetch")) {
      return { payload: null, blocked: true, requestUrl: v2Url, version: "v2" };
    }
    return { payload: null, blocked: false, requestUrl: v2Url, version: "v2" };
  }
  try {
    const v1Response = await fetchWithTimeout(v1Url, { cache: "no-cache" });
    if (!v1Response.ok) {
      return { payload: null, blocked: false, requestUrl: v1Url, version: "v1" };
    }
    const payload = await v1Response.json();
    return {
      payload,
      blocked: false,
      requestUrl: v1Url,
      version: "v1"
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (error instanceof TypeError || message.includes("Failed to fetch")) {
      return { payload: null, blocked: true, requestUrl: v1Url, version: "v1" };
    }
    return { payload: null, blocked: false, requestUrl: v1Url, version: "v1" };
  }
}
function normalizeExecution(item, crnUrl) {
  const networking = item.networking ?? null;
  const mappedPorts = networking && "mapped_ports" in networking && networking.mapped_ports && typeof networking.mapped_ports === "object" ? Object.fromEntries(
    Object.entries(networking.mapped_ports).map(([port, mapping]) => [
      port,
      {
        host: asNumber(mapping?.host) ?? void 0,
        tcp: typeof mapping?.tcp === "boolean" ? mapping.tcp : void 0,
        udp: typeof mapping?.udp === "boolean" ? mapping.udp : void 0
      }
    ])
  ) : void 0;
  if (networking && ("host_ipv4" in networking || "ipv6_ip" in networking || "ipv4_network" in networking)) {
    const v2Item = item;
    return {
      crnUrl,
      version: "v2",
      running: typeof v2Item.running === "boolean" ? v2Item.running : void 0,
      networking: {
        ipv4_network: asString(networking.ipv4_network),
        host_ipv4: asString(networking.host_ipv4),
        ipv6_network: asString(networking.ipv6_network),
        ipv6_ip: asString(networking.ipv6_ip),
        ipv4_ip: asString(networking.ipv4_ip),
        proxy_url: extractProxyUrl(v2Item, networking),
        mapped_ports: mappedPorts
      },
      status: v2Item.status ? {
        defined_at: asString(v2Item.status.defined_at),
        preparing_at: asString(v2Item.status.preparing_at),
        prepared_at: asString(v2Item.status.prepared_at),
        starting_at: asString(v2Item.status.starting_at),
        started_at: asString(v2Item.status.started_at),
        stopping_at: asString(v2Item.status.stopping_at),
        stopped_at: asString(v2Item.status.stopped_at)
      } : null
    };
  }
  return {
    crnUrl,
    version: "v1",
    networking: {
      ipv4: networking && "ipv4" in networking ? asString(networking.ipv4) : null,
      ipv6: networking && "ipv6" in networking ? asString(networking.ipv6) : null
    },
    status: null
  };
}
async function notifyCrnAllocation(crnUrl, itemHash) {
  const normalizedCrnUrl = crnUrl.replace(/\/+$/, "");
  try {
    const response = await fetchWithTimeout(`${normalizedCrnUrl}/control/allocation/notify`, {
      method: "POST",
      headers: {
        "content-type": "text/plain;charset=UTF-8"
      },
      body: JSON.stringify({ instance: itemHash }),
      mode: "cors"
    });
    if (!response.ok) {
      const responseText = await response.text().catch(() => "");
      throw new Error(`CRN allocation notify failed: ${response.status}${responseText ? ` ${responseText}` : ""}`);
    }
    return { status: "confirmed" };
  } catch (error) {
    if (isUnconfirmedNetworkError(error)) {
      return { status: "unconfirmed" };
    }
    throw error;
  }
}
async function configureOrbitdbRelaySetup(args) {
  const targetUrl = `http://${args.hostIpv4}:${args.setupPort}/configure`;
  try {
    const response = await fetchWithTimeout(
      targetUrl,
      {
        method: "POST",
        headers: {
          "content-type": "text/plain;charset=UTF-8"
        },
        body: JSON.stringify({
          public_ipv4: args.hostIpv4,
          public_ipv6: args.publicIpv6 ?? void 0,
          tcp_port: args.tcpPort,
          ws_port: args.wsPort,
          proxy_url: args.proxyUrl ?? void 0,
          metrics_port: args.metricsPort ?? void 0,
          metrics_https_port: args.metricsHttpsPort ?? void 0,
          webrtc_port: args.webrtcPort ?? void 0,
          quic_port: args.quicPort ?? void 0
        }),
        mode: "cors"
      },
      3e4
    );
    if (!response.ok) {
      const responseText = await response.text().catch(() => "");
      throw new Error(`Relay setup request failed: ${response.status}${responseText ? ` ${responseText}` : ""}`);
    }
    return { status: "configured" };
  } catch (error) {
    if (isUnconfirmedNetworkError(error)) {
      return { status: "unconfirmed" };
    }
    throw error;
  }
}
function messageTypeFromEnvelope(payload) {
  if (!payload) return null;
  const type = payload.type ?? payload.message?.type ?? (Array.isArray(payload.messages) ? payload.messages[0]?.type : void 0);
  return typeof type === "string" ? type.toUpperCase() : null;
}
function extractReferenceHashes(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) return [];
  const errors = details.errors;
  if (!Array.isArray(errors)) return [];
  return errors.filter((value) => typeof value === "string");
}
function extractInsufficientBalanceMessage(details) {
  if (!details || typeof details !== "object" || !("errors" in details)) return null;
  const errors = details.errors;
  const firstError = Array.isArray(errors) && errors[0] && typeof errors[0] === "object" ? errors[0] : null;
  const accountBalance = typeof firstError?.account_balance === "number" || typeof firstError?.account_balance === "string" ? Number(firstError.account_balance) : Number.NaN;
  const requiredBalance = typeof firstError?.required_balance === "number" || typeof firstError?.required_balance === "string" ? Number(firstError.required_balance) : Number.NaN;
  if (!Number.isFinite(accountBalance) || !Number.isFinite(requiredBalance)) {
    return null;
  }
  const shortfall = requiredBalance - accountBalance;
  return shortfall > 0 ? `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required, ${shortfall.toFixed(3)} short` : `insufficient Aleph balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required`;
}
function describeRejectedDeployment(payload, references, rootfsRef) {
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const pendingReferences = references.filter((reference) => reference.status === "pending");
  const missingReferences = references.filter((reference) => reference.status === "missing");
  const rootfsReference = references.find((reference) => reference.itemHash === rootfsRef);
  if (rootfsReference?.status === "pending") {
    return `Aleph rejected this deployment because the referenced rootfs STORE message ${rootfsReference.itemHash} is still pending and cannot yet be used by an instance. Wait for that STORE message to process, then deploy again.`;
  }
  if (pendingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) are still pending: ${pendingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  if (missingReferences.length > 0) {
    return `Aleph rejected this deployment because referenced message(s) were not found on Aleph: ${missingReferences.map((reference) => reference.itemHash).join(", ")}.`;
  }
  const insufficientBalanceMessage = extractInsufficientBalanceMessage(payload.details);
  if (insufficientBalanceMessage) {
    return `Aleph rejected this deployment due to ${insufficientBalanceMessage}.`;
  }
  const referencedHashes = extractReferenceHashes(payload.details);
  if (referencedHashes.length > 0) {
    return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}. Referenced message(s): ${referencedHashes.join(", ")}.`;
  }
  return `Aleph rejected this deployment${errorCode ? ` (error ${errorCode})` : ""}.`;
}
async function fetchMessageEnvelope(itemHash, apiHost = DEFAULT_ALEPH_API_HOST) {
  const response = await fetchWithTimeout(`${apiHost}/api/v0/messages/${itemHash}`, {
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Message lookup failed: ${response.status}`);
  return await response.json();
}
async function fetchReference(itemHash, apiHost) {
  const payload = await fetchMessageEnvelope(itemHash, apiHost);
  if (!payload) {
    return {
      itemHash,
      status: "missing",
      type: null
    };
  }
  return {
    itemHash,
    status: normalizeMessageStatus(payload.status),
    type: messageTypeFromEnvelope(payload)
  };
}
async function inspectDeploymentResult(itemHash, rootfsRef, apiHost = DEFAULT_ALEPH_API_HOST) {
  const payload = await fetchMessageEnvelope(itemHash, apiHost);
  if (!payload) {
    return {
      status: "unknown",
      errorCode: null,
      details: null,
      rejectionReason: `Deployment message ${itemHash} was not found on Aleph.`,
      references: []
    };
  }
  const relatedHashes = new Set(rootfsRef ? [rootfsRef] : []);
  for (const referenceHash of extractReferenceHashes(payload.details)) {
    relatedHashes.add(referenceHash);
  }
  const references = await Promise.all(Array.from(relatedHashes).map((hash) => fetchReference(hash, apiHost)));
  const status = normalizeMessageStatus(payload.status);
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  return {
    status,
    errorCode,
    details,
    rejectionReason: status === "rejected" ? describeRejectedDeployment(payload, references, rootfsRef) : null,
    references
  };
}
async function waitForDeploymentResult(itemHash, rootfsRef, apiHost = DEFAULT_ALEPH_API_HOST, attempts = 15, delayMs = 2e3) {
  let lastResult = await inspectDeploymentResult(itemHash, rootfsRef, apiHost);
  for (let attempt = 1; attempt < attempts; attempt += 1) {
    if (lastResult.status === "processed" || lastResult.status === "rejected") {
      return lastResult;
    }
    await new Promise((resolve) => globalThis.setTimeout(resolve, delayMs));
    lastResult = await inspectDeploymentResult(itemHash, rootfsRef, apiHost);
  }
  return lastResult;
}
function isInvalidMessageFormatResponse(response, payload) {
  if (response.status !== 422) return false;
  const details = payload.details;
  if (typeof details === "string" && details.includes("InvalidMessageFormat")) return true;
  if (details && typeof details === "object") {
    const detailMessage = details.message;
    if (typeof detailMessage === "string" && detailMessage.includes("InvalidMessageFormat")) return true;
  }
  return false;
}
async function postBroadcastPayload(body, apiHost) {
  const rawResponse = await fetchWithTimeout(`${apiHost}/api/v0/messages`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  const response = await rawResponse.json().catch(() => ({}));
  return {
    response,
    httpStatus: rawResponse.status,
    rawResponse
  };
}
async function broadcastInstanceMessage(message, apiHost = DEFAULT_ALEPH_API_HOST, sync = false) {
  const attempts = [{ sync, message }, { ...message, sync }, { ...message }];
  for (let index = 0; index < attempts.length; index += 1) {
    const result = await postBroadcastPayload(attempts[index], apiHost);
    if (result.rawResponse.ok || result.httpStatus === 202) {
      return {
        response: result.response,
        httpStatus: result.httpStatus
      };
    }
    const canRetry = index < attempts.length - 1 && isInvalidMessageFormatResponse(result.rawResponse, result.response);
    if (!canRetry) {
      throw new Error(`Broadcast failed: ${result.httpStatus} ${JSON.stringify(result.response)}`);
    }
  }
  throw new Error("Broadcast failed: no compatible request format was accepted");
}
async function broadcastAlephMessage(message, apiHost = DEFAULT_ALEPH_API_HOST, sync = false) {
  return broadcastInstanceMessage(message, apiHost, sync);
}

// src/client.ts
function createAlephBrowserClient(options = {}) {
  const apiHost = options.apiHost ?? DEFAULT_ALEPH_API_HOST;
  const crnListUrl = options.crnListUrl ?? DEFAULT_CRN_LIST_URL;
  const schedulerApiHost = options.schedulerApiHost ?? DEFAULT_ALEPH_SCHEDULER_API_HOST;
  const twoN6ApiHost = options.twoN6ApiHost ?? DEFAULT_2N6_API_HOST;
  return {
    apiHost,
    crnListUrl,
    schedulerApiHost,
    fetchBalance(address) {
      return fetchBalance(address, apiHost);
    },
    fetchCrns() {
      return fetchCrns(crnListUrl);
    },
    fetchInstances(address) {
      return fetchInstances(address, apiHost);
    },
    fetch2n6WebAccessUrl(itemHash) {
      return fetch2n6WebAccessUrl(itemHash, twoN6ApiHost);
    },
    fetchMessageEnvelope(itemHash) {
      return fetchMessageEnvelope(itemHash, apiHost);
    },
    fetchSchedulerAllocation(itemHash) {
      return fetchSchedulerAllocation(itemHash, schedulerApiHost);
    },
    fetchCrnExecutionMap(crnUrl) {
      return fetchCrnExecutionMap(crnUrl);
    },
    notifyCrnAllocation(crnUrl, itemHash) {
      return notifyCrnAllocation(crnUrl, itemHash);
    },
    configureOrbitdbRelaySetup(args) {
      return configureOrbitdbRelaySetup(args);
    },
    inspectDeploymentResult(itemHash, rootfsRef) {
      return inspectDeploymentResult(itemHash, rootfsRef, apiHost);
    },
    waitForDeploymentResult(itemHash, rootfsRef, attempts, delayMs) {
      return waitForDeploymentResult(itemHash, rootfsRef, apiHost, attempts, delayMs);
    },
    broadcastInstanceMessage(message, sync) {
      return broadcastInstanceMessage(message, apiHost, sync);
    },
    broadcastAlephMessage(message, sync) {
      return broadcastAlephMessage(message, apiHost, sync);
    }
  };
}

// src/evm.ts
function ensureHexQuantity(value) {
  return `0x${value.toString(16)}`;
}
function assertProvider(provider) {
  if (!provider) {
    throw new Error("MetaMask provider not found.");
  }
}
async function ethCall(to, data, provider) {
  assertProvider(provider);
  return provider.request({
    method: "eth_call",
    params: [
      {
        to,
        data
      },
      "latest"
    ]
  });
}
async function sendTransaction(tx, provider) {
  assertProvider(provider);
  return provider.request({
    method: "eth_sendTransaction",
    params: [
      {
        from: tx.from,
        to: tx.to,
        data: tx.data,
        value: tx.value != null ? ensureHexQuantity(tx.value) : void 0
      }
    ]
  });
}
async function personalSign(address, message, provider) {
  assertProvider(provider);
  const hexMessage = `0x${Array.from(new TextEncoder().encode(message)).map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
  return provider.request({
    method: "personal_sign",
    params: [hexMessage, address]
  });
}

// src/prepaid.ts
var ERC20_APPROVE_SELECTOR = "0x095ea7b3";
var DEPOSIT_SELECTOR = "0xb6b55f25";
var RESERVE_SELECTOR = "0x7136e76e";
var CONSUME_SELECTOR = "0x6a2580db";
var REFUND_SELECTOR = "0xcc3e049b";
var TOTAL_DEPOSITED_SELECTOR = "0x53055481";
var AVAILABLE_BALANCE_SELECTOR = "0xa0821be3";
var RESERVED_BALANCE_SELECTOR = "0xe2c61aeb";
var RESERVATION_OF_SELECTOR = "0x0c388a74";
function padWord(value) {
  return value.replace(/^0x/i, "").padStart(64, "0");
}
function encodeAddress(address) {
  return padWord(address.toLowerCase().replace(/^0x/, ""));
}
function encodeUint256(value) {
  return padWord(value.toString(16));
}
function encodeUint64(value) {
  return padWord(BigInt(value).toString(16));
}
function encodeBytes32(value) {
  return padWord(value.replace(/^0x/, ""));
}
function encodeCall(selectorValue, args) {
  return `${selectorValue}${args.join("")}`;
}
function normalizeHex(value) {
  const normalized = value.startsWith("0x") ? value.toLowerCase() : `0x${value.toLowerCase()}`;
  return normalized;
}
function parseUint256Hex(value) {
  const normalized = normalizeHex(value);
  if (!/^0x[0-9a-f]+$/i.test(normalized)) {
    throw new Error(`Invalid uint256 hex value: ${value}`);
  }
  return BigInt(normalized);
}
function paymentChainFromChainId(chainId, chainConfig) {
  if (!chainId) return null;
  const normalized = chainId.toLowerCase();
  return Object.entries(chainConfig).find(([, config]) => config.chainIdHex.toLowerCase() === normalized)?.[0] ?? null;
}
function formatBudgetUnits(value, decimals = 18) {
  const divisor = 10n ** BigInt(decimals);
  const whole = value / divisor;
  const fraction = value % divisor;
  return Number(whole) + Number(fraction) / 10 ** decimals;
}
async function loadPrepaidReservation(args) {
  const encoded = encodeCall(RESERVATION_OF_SELECTOR, [encodeAddress(args.ownerAddress), encodeBytes32(args.intentHash)]);
  const raw = await ethCall(args.vaultAddress, encoded, args.provider);
  const normalized = raw.replace(/^0x/, "").padEnd(256, "0");
  if (!normalized || /^0+$/.test(normalized)) return null;
  const reservedAmount = BigInt(`0x${normalized.slice(0, 64)}`);
  const expiresAt = Number(BigInt(`0x${normalized.slice(64, 128)}`));
  const consumed = BigInt(`0x${normalized.slice(128, 192)}`) !== 0n;
  const owner = `0x${normalized.slice(216, 256)}`;
  if (reservedAmount === 0n) return null;
  return {
    intentHash: args.intentHash,
    ownerAddress: owner.toLowerCase() === args.ownerAddress.toLowerCase() ? args.ownerAddress : owner,
    reservedAmount,
    expiresAt,
    consumed,
    expired: expiresAt <= Math.floor(Date.now() / 1e3)
  };
}
async function readUint256(args) {
  const encoded = encodeCall(args.selector, [encodeAddress(args.ownerAddress)]);
  const raw = await ethCall(args.vaultAddress, encoded, args.provider);
  return parseUint256Hex(raw);
}
async function loadPrepaidVaultSnapshot(args) {
  const [totalDeposited, availableBalance, reservedBalance, currentReservation] = await Promise.all([
    readUint256({
      selector: TOTAL_DEPOSITED_SELECTOR,
      ownerAddress: args.ownerAddress,
      vaultAddress: args.vaultAddress,
      provider: args.provider
    }),
    readUint256({
      selector: AVAILABLE_BALANCE_SELECTOR,
      ownerAddress: args.ownerAddress,
      vaultAddress: args.vaultAddress,
      provider: args.provider
    }),
    readUint256({
      selector: RESERVED_BALANCE_SELECTOR,
      ownerAddress: args.ownerAddress,
      vaultAddress: args.vaultAddress,
      provider: args.provider
    }),
    args.currentIntentHash ? loadPrepaidReservation({
      ownerAddress: args.ownerAddress,
      intentHash: args.currentIntentHash,
      vaultAddress: args.vaultAddress,
      provider: args.provider
    }) : Promise.resolve(null)
  ]);
  return {
    totalDeposited,
    availableBalance,
    reservedBalance,
    currentReservation
  };
}
async function approvePrepaidBudget(args) {
  return sendTransaction(
    {
      from: args.ownerAddress,
      to: args.tokenAddress,
      data: encodeCall(ERC20_APPROVE_SELECTOR, [encodeAddress(args.vaultAddress), encodeUint256(args.amount)])
    },
    args.provider
  );
}
async function depositPrepaidBudget(args) {
  return sendTransaction(
    {
      from: args.ownerAddress,
      to: args.vaultAddress,
      data: encodeCall(DEPOSIT_SELECTOR, [encodeUint256(args.amount)])
    },
    args.provider
  );
}
async function reserveDeploymentBudget(args) {
  return sendTransaction(
    {
      from: args.ownerAddress,
      to: args.vaultAddress,
      data: encodeCall(RESERVE_SELECTOR, [
        encodeBytes32(args.intentHash),
        encodeUint256(args.amount),
        encodeUint64(args.expiresAt)
      ])
    },
    args.provider
  );
}
async function consumeDeploymentReservation(args) {
  return sendTransaction(
    {
      from: args.ownerAddress,
      to: args.vaultAddress,
      data: encodeCall(CONSUME_SELECTOR, [encodeBytes32(args.intentHash), encodeUint256(args.amount)])
    },
    args.provider
  );
}
async function refundExpiredReservation(args) {
  return sendTransaction(
    {
      from: args.ownerAddress,
      to: args.vaultAddress,
      data: encodeCall(REFUND_SELECTOR, [encodeBytes32(args.intentHash)])
    },
    args.provider
  );
}

// src/rootfs.ts
var ITEM_HASH_RE = /^[a-fA-F0-9]{64}$/u;
var DEFAULT_ROOTFS_MANIFEST_URL = "./rootfs-manifest.json";
var DEFAULT_IPFS_GATEWAY_BASE_URL = "https://ipfs.aleph.cloud/ipfs/";
function resolveManifestUrl(input, baseUrl) {
  if (input instanceof URL) return input;
  try {
    return new URL(input, baseUrl ? String(baseUrl) : globalThis.location?.href);
  } catch {
    return input;
  }
}
function validateRootfsManifest(manifest) {
  const errors = [];
  if (!manifest) {
    return { manifest, valid: false, errors: ["Rootfs manifest is missing."] };
  }
  if (!manifest.version) errors.push("Rootfs manifest version is missing.");
  if (manifest.rootfsInstallStrategy != null && manifest.rootfsInstallStrategy !== "thin" && manifest.rootfsInstallStrategy !== "prebaked") {
    errors.push('Rootfs install strategy must be "thin" or "prebaked" when provided.');
  }
  if (manifest.requiresBootstrapNetwork != null && typeof manifest.requiresBootstrapNetwork !== "boolean") {
    errors.push("Rootfs bootstrap network flag must be a boolean when provided.");
  }
  if (manifest.bootstrapSummary != null && !manifest.bootstrapSummary.trim()) {
    errors.push("Rootfs bootstrap summary must be non-empty when provided.");
  }
  if (manifest.requiredPortForwards != null) {
    if (!Array.isArray(manifest.requiredPortForwards)) {
      errors.push("Rootfs required port forwards must be an array when provided.");
    } else {
      manifest.requiredPortForwards.forEach((entry, index) => {
        if (!entry || typeof entry !== "object") {
          errors.push(`Rootfs required port forward #${index + 1} must be an object.`);
          return;
        }
        if (!Number.isInteger(entry.port) || entry.port < 1 || entry.port > 65535) {
          errors.push(`Rootfs required port forward #${index + 1} must use a TCP/UDP port between 1 and 65535.`);
        }
        if (entry.tcp !== true && entry.udp !== true) {
          errors.push(`Rootfs required port forward #${index + 1} must enable TCP or UDP.`);
        }
        if (entry.purpose != null && (typeof entry.purpose !== "string" || !entry.purpose.trim())) {
          errors.push(`Rootfs required port forward #${index + 1} purpose must be non-empty when provided.`);
        }
      });
    }
  }
  if (!ITEM_HASH_RE.test(manifest.rootfsItemHash || "")) {
    errors.push("Rootfs ItemHash must be a 64 character hex value.");
  }
  if (!Number.isInteger(manifest.rootfsSizeMiB) || manifest.rootfsSizeMiB <= 0) {
    errors.push("Rootfs size must be a positive MiB integer.");
  }
  if (manifest.rootfsSourceSizeBytes != null && (!Number.isInteger(manifest.rootfsSourceSizeBytes) || manifest.rootfsSourceSizeBytes <= 0)) {
    errors.push("Rootfs source size must be a positive byte integer when provided.");
  }
  if (!manifest.createdAt || Number.isNaN(new Date(manifest.createdAt).getTime())) {
    errors.push("Rootfs creation date is missing or invalid.");
  }
  return { manifest, valid: errors.length === 0, errors };
}
async function loadRootfsManifest(url = DEFAULT_ROOTFS_MANIFEST_URL, options = {}) {
  const response = await fetchWithTimeout(resolveManifestUrl(url, options.baseUrl), { cache: "no-cache" });
  if (!response.ok) {
    throw new Error(`Rootfs manifest request failed: ${response.status}`);
  }
  return validateRootfsManifest(await response.json());
}
async function verifyRootfsExists(itemHash, apiHost = DEFAULT_ALEPH_API_HOST) {
  if (!ITEM_HASH_RE.test(itemHash)) return false;
  const response = await fetchWithTimeout(`${apiHost}/api/v0/messages/${itemHash}`, {
    method: "GET",
    cache: "no-cache"
  });
  if (response.status === 404) return false;
  if (!response.ok) throw new Error(`Rootfs lookup failed: ${response.status}`);
  const payload = await response.json();
  const firstMessage = Array.isArray(payload.messages) ? payload.messages[0] : void 0;
  const type = String(payload.type || payload.message?.type || firstMessage?.type || "").toUpperCase();
  return type === "STORE";
}
function normalizeStatus(status) {
  if (typeof status !== "string") return "unknown";
  const normalized = status.toLowerCase();
  if (normalized === "processed" || normalized === "pending" || normalized === "rejected") {
    return normalized;
  }
  return "unknown";
}
function parseCidFromPayload(payload) {
  const firstMessage = Array.isArray(payload.messages) && payload.messages[0] && typeof payload.messages[0] === "object" ? payload.messages[0] : null;
  const directContent = firstMessage?.content && typeof firstMessage.content === "object" ? firstMessage.content : null;
  if (typeof directContent?.item_hash === "string") {
    return directContent.item_hash;
  }
  if (typeof firstMessage?.item_content === "string") {
    try {
      const itemContent = JSON.parse(firstMessage.item_content);
      if (typeof itemContent.item_hash === "string") {
        return itemContent.item_hash;
      }
    } catch {
      return null;
    }
  }
  return null;
}
function parseRejectionReason(payload) {
  const errorCode = typeof payload.error_code === "number" ? payload.error_code : null;
  const details = payload.details && typeof payload.details === "object" ? payload.details : null;
  const rawErrors = Array.isArray(details?.errors) ? details.errors : [];
  const firstError = rawErrors[0] && typeof rawErrors[0] === "object" ? rawErrors[0] : null;
  if (firstError) {
    const accountBalance = Number(firstError.account_balance);
    const requiredBalance = Number(firstError.required_balance);
    if (Number.isFinite(accountBalance) && Number.isFinite(requiredBalance)) {
      const shortfall = requiredBalance - accountBalance;
      return {
        rejectionErrorCode: errorCode,
        rejectionReason: shortfall > 0 ? `Rejected by Aleph for insufficient hold balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required, ${shortfall.toFixed(3)} short.` : `Rejected by Aleph for insufficient hold balance: ${accountBalance.toFixed(3)} available, ${requiredBalance.toFixed(3)} required.`
      };
    }
  }
  return {
    rejectionErrorCode: errorCode,
    rejectionReason: errorCode != null ? `Rejected by Aleph (error code ${errorCode}).` : null
  };
}
async function probeGateway(cid, gatewayBaseUrl = DEFAULT_IPFS_GATEWAY_BASE_URL) {
  const gatewayUrl = new URL(cid, gatewayBaseUrl).toString();
  try {
    const response = await fetchWithTimeout(gatewayUrl, { method: "HEAD", cache: "no-store" }, 5e3);
    return {
      gatewayUrl,
      gatewayStatus: response.ok ? "reachable" : "error",
      gatewayError: response.ok ? null : `Gateway responded with ${response.status}.`
    };
  } catch (error) {
    if (error instanceof Error && error.message.includes("timed out")) {
      return {
        gatewayUrl,
        gatewayStatus: "timeout",
        gatewayError: error.message
      };
    }
    return {
      gatewayUrl,
      gatewayStatus: "unavailable",
      gatewayError: error instanceof Error ? error.message : String(error)
    };
  }
}
async function resolveRootfsReference(itemHash, apiHost = DEFAULT_ALEPH_API_HOST, gatewayBaseUrl = DEFAULT_IPFS_GATEWAY_BASE_URL) {
  if (!ITEM_HASH_RE.test(itemHash)) return null;
  const response = await fetchWithTimeout(`${apiHost}/api/v0/messages/${itemHash}`, {
    method: "GET",
    cache: "no-cache"
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Rootfs lookup failed: ${response.status}`);
  const payload = await response.json();
  const firstMessage = Array.isArray(payload.messages) && payload.messages[0] && typeof payload.messages[0] === "object" ? payload.messages[0] : null;
  const messageObject = payload.message && typeof payload.message === "object" ? payload.message : null;
  const cid = parseCidFromPayload(payload);
  const rejection = normalizeStatus(payload.status) === "rejected" ? parseRejectionReason(payload) : { rejectionErrorCode: null, rejectionReason: null };
  const gateway = cid ? await probeGateway(cid, gatewayBaseUrl) : { gatewayUrl: null, gatewayStatus: "unknown", gatewayError: null };
  return {
    itemHash,
    messageStatus: normalizeStatus(payload.status),
    messageType: String(payload.type || messageObject?.type || firstMessage?.type || "").toUpperCase() || null,
    cid,
    receptionTime: typeof payload.reception_time === "string" ? payload.reception_time : null,
    rejectionErrorCode: rejection.rejectionErrorCode,
    rejectionReason: rejection.rejectionReason,
    gatewayUrl: gateway.gatewayUrl,
    gatewayStatus: gateway.gatewayStatus,
    gatewayError: gateway.gatewayError
  };
}

// src/pricing.ts
var DEFAULT_ALEPH_AGGREGATE_ADDRESS = "0xFba561a84A537fCaa567bb7A2257e7142701ae2A";
function parseInstancePricing(payload) {
  const data = payload;
  const pricing = data.data?.pricing ?? data.pricing;
  const instance = pricing?.instance;
  if (!instance?.price?.compute_unit || !instance.compute_unit || !Array.isArray(instance.tiers)) {
    throw new Error("Aleph pricing aggregate does not contain instance pricing.");
  }
  return instance;
}
async function fetchInstancePricing(apiHost = DEFAULT_ALEPH_API_HOST, aggregateAddress = DEFAULT_ALEPH_AGGREGATE_ADDRESS) {
  const response = await fetchWithTimeout(`${apiHost}/api/v0/aggregates/${aggregateAddress}.json?keys=pricing`, {
    cache: "no-cache"
  });
  if (!response.ok) {
    throw new Error(`Pricing aggregate request failed: ${response.status}`);
  }
  const payload = await response.json();
  const pricingAggregate = payload.data?.pricing;
  if (!pricingAggregate) {
    throw new Error("Pricing aggregate response did not include a pricing key.");
  }
  return {
    pricing: parseInstancePricing({ pricing: pricingAggregate }),
    fetchedAt: Date.now()
  };
}
export {
  BROWSER_PACKAGE_PLAN,
  DEFAULT_2N6_API_HOST,
  DEFAULT_ALEPH_AGGREGATE_ADDRESS,
  DEFAULT_ALEPH_API_HOST,
  DEFAULT_ALEPH_SCHEDULER_API_HOST,
  DEFAULT_CRN_LIST_URL,
  DEFAULT_IPFS_GATEWAY_BASE_URL,
  DEFAULT_ROOTFS_MANIFEST_URL,
  ITEM_HASH_RE,
  approvePrepaidBudget,
  broadcastAlephMessage,
  broadcastInstanceMessage,
  configureOrbitdbRelaySetup,
  consumeDeploymentReservation,
  createAlephBrowserClient,
  depositPrepaidBudget,
  ethCall,
  fetch2n6WebAccessUrl,
  fetchBalance,
  fetchCrnExecutionMap,
  fetchCrns,
  fetchInstancePricing,
  fetchInstances,
  fetchMessageEnvelope,
  fetchSchedulerAllocation,
  fetchWithTimeout,
  formatBudgetUnits,
  inspectDeploymentResult,
  loadPrepaidReservation,
  loadPrepaidVaultSnapshot,
  loadRootfsManifest,
  normalizeExecution,
  normalizeMessageStatus,
  notifyCrnAllocation,
  parseInstancePricing,
  paymentChainFromChainId,
  personalSign,
  refundExpiredReservation,
  reserveDeploymentBudget,
  resolveRootfsReference,
  sendTransaction,
  validateRootfsManifest,
  verifyRootfsExists,
  waitForDeploymentResult
};
